//! Emitter-aware **structural detour audit**.
//!
//! `create --json` says a lever was `Applied`, and the image self-verifies (CMAC),
//! but neither proves the detour actually landed where it must. This audit closes
//! that gap: for every `Applied` lever it recomputes the **exact** expected hook
//! bytes with the emitter's own [`thumb_asm::encode_bl`] and asserts they are
//! present in the produced image at the emitter's real hook site (`speed_gate+4`,
//! `region_emitter+6`, the AKE/Gate-A/deny `bl` sites), that the injected stub is
//! not blank flash, that the hijacked record was repointed to the injected handler,
//! that the DE byte is `0xDE`, and that the CMAC tables verify.
//!
//! It works off the lever `facts` (the addresses the emitter recorded), NOT the
//! finder anchor addresses — those are where a signature *matched*, not where the
//! `bl` was written, which is why a by-hand anchor check is misleading.

use crate::engine::core::is_freemkv_patched;
use crate::engine::lever::{LeverId, LeverOutcome, ModifyReport};
use freemkv_flash::cmac;
use thumb_asm as thumb;

/// One structural check with its verdict.
#[derive(Debug, Clone)]
pub struct AuditCheck {
    /// The lever this check belongs to.
    pub lever: &'static str,
    /// What was checked.
    pub what: String,
    /// Whether it passed.
    pub ok: bool,
    /// Human detail (addresses, expected vs found).
    pub detail: String,
}

/// The result of a structural audit: one check per verified property.
#[derive(Debug, Clone)]
pub struct AuditResult {
    /// All checks run, in order.
    pub checks: Vec<AuditCheck>,
}

impl AuditResult {
    /// True if every check passed.
    pub fn ok(&self) -> bool {
        self.checks.iter().all(|c| c.ok)
    }
    /// The checks that failed.
    pub fn failures(&self) -> impl Iterator<Item = &AuditCheck> {
        self.checks.iter().filter(|c| !c.ok)
    }
}

/// Look up a grounded fact value by key on a lever report.
fn fact(l: &crate::engine::lever::LeverReport, key: &str) -> Option<u32> {
    l.facts.iter().find(|(k, _)| *k == key).map(|(_, v)| *v)
}

/// True if the 16 bytes at `va` are not all erased flash (`0xFF`) — i.e. a stub
/// was actually written there.
fn stub_present(img: &[u8], va: u32) -> bool {
    let a = va as usize;
    a + 16 <= img.len() && img[a..a + 16].iter().any(|&b| b != 0xFF)
}

/// A failing check for an Applied lever whose facts are absent: we can't prove
/// the detour landed, so it must be caught, not accepted vacuously.
fn missing_facts(lever: &'static str, detail: &str) -> AuditCheck {
    AuditCheck {
        lever,
        what: "detour facts present".into(),
        ok: false,
        detail: detail.to_string(),
    }
}

/// Assert the 4 bytes at `site` are exactly the `bl` the emitter would write to
/// reach `stub` (recomputed via [`thumb::encode_bl`]).
fn check_bl(
    checks: &mut Vec<AuditCheck>,
    lever: &'static str,
    what: &str,
    img: &[u8],
    site: u32,
    stub: u32,
) {
    check_branch_impl(
        checks,
        lever,
        what,
        img,
        BranchInstall {
            site,
            stub,
            expected: thumb::encode_bl(site as usize, stub),
            kind: "bl",
        },
    );
}

/// AKE-detour install check: passes if the 4 bytes at `site` are either the
/// Thumb-2 wide `B.W` (BU40N/desktop tail-call install) OR the wide `BL`
/// (NB-class shared-call install) targeting `stub`. See `AkeInstallShape` in
/// `crate::engine::core` for which variant each gate resolution produces.
fn check_ake_detour(
    checks: &mut Vec<AuditCheck>,
    lever: &'static str,
    img: &[u8],
    site: u32,
    stub: u32,
) {
    let s = site as usize;
    let expected_bw = thumb::encode_b_wide(s, stub);
    let expected_bl = thumb::encode_bl(s, stub);
    if s + 4 > img.len() {
        checks.push(AuditCheck {
            lever,
            what: "AKE detour branch".to_string(),
            ok: false,
            detail: format!("hook site 0x{site:08x} past end of image"),
        });
        return;
    }
    let found = &img[s..s + 4];
    let ok = expected_bw.as_ref().is_some_and(|e| found == e)
        || expected_bl.as_ref().is_some_and(|e| found == e);
    let kind_matched = if expected_bw.as_ref().is_some_and(|e| found == e) {
        "b.w"
    } else if expected_bl.as_ref().is_some_and(|e| found == e) {
        "bl"
    } else {
        "neither"
    };
    let (ok, detail) = if ok && !stub_present(img, stub) {
        (
            false,
            format!("AKE branch present ({kind_matched}) but stub at 0x{stub:08x} is blank (0xFF)"),
        )
    } else {
        (
            ok,
            format!(
                "site 0x{site:08x} -> stub 0x{stub:08x} ({kind_matched}): b.w={:02x?}, bl={:02x?}, found {:02x?}",
                expected_bw, expected_bl, found
            ),
        )
    };
    checks.push(AuditCheck {
        lever,
        what: "AKE detour branch".to_string(),
        ok,
        detail,
    });
}

/// One branch install to verify: where the emitter wrote it, where it should
/// reach, the exact 4 bytes it should have produced (`None` when the target was
/// out of branch range), and the mnemonic for the failure text.
struct BranchInstall {
    site: u32,
    stub: u32,
    expected: Option<[u8; 4]>,
    kind: &'static str,
}

fn check_branch_impl(
    checks: &mut Vec<AuditCheck>,
    lever: &'static str,
    what: &str,
    img: &[u8],
    branch: BranchInstall,
) {
    let BranchInstall {
        site,
        stub,
        expected,
        kind,
    } = branch;
    let s = site as usize;
    let (ok, detail) = match expected {
        None => (
            false,
            format!("{kind} 0x{site:08x} -> 0x{stub:08x} out of range"),
        ),
        Some(exp) => {
            if s + 4 > img.len() {
                (false, format!("hook site 0x{site:08x} past end of image"))
            } else {
                let found = &img[s..s + 4];
                (
                    found == exp,
                    format!(
                        "site 0x{site:08x} -> stub 0x{stub:08x} ({kind}): expected {:02x?}, found {:02x?}",
                        exp, found
                    ),
                )
            }
        }
    };
    let mut ok = ok;
    let mut detail = detail;
    if ok && !stub_present(img, stub) {
        ok = false;
        detail = format!("{kind} present but stub at 0x{stub:08x} is blank (0xFF)");
    }
    checks.push(AuditCheck {
        lever,
        what: what.to_string(),
        ok,
        detail,
    });
}

/// Structurally audit that a `ModifyReport`'s Applied levers actually landed in
/// its produced image. `original` is the pre-modify image (for reference); all
/// structural assertions are against `report.image`.
pub fn audit_image(original: &[u8], report: &ModifyReport) -> AuditResult {
    let img = &report.image;
    let mut checks = Vec::new();
    // Re-signing may change digests. Geometry may change only according to the
    // independently re-derived coverage plan; erased records remain untouched.
    let descriptors_preserved = super::code_space::metadata_preserved(original, img);
    checks.push(AuditCheck {
        lever: "integrity",
        what: "integrity metadata matches original or proven coverage plan".into(),
        ok: descriptors_preserved,
        detail: "Unused records and unplanned descriptor changes are forbidden".into(),
    });

    for l in &report.levers {
        if l.outcome != LeverOutcome::Applied {
            continue; // AlreadyPresent has no fresh detour to check; N/A + skipped emit nothing.
        }
        let name = l.id.label();
        match l.id {
            LeverId::BootSettings => {
                let verified = crate::boot::inspect(img);
                checks.push(AuditCheck {
                    lever: name,
                    what: "boot and reset settings match the signed record".into(),
                    ok: matches!(verified, Ok(Some(_))),
                    detail: match verified {
                        Ok(Some(_)) => "versioned boot settings verified".into(),
                        Ok(None) => "missing boot settings record".into(),
                        Err(e) => format!("{e:#}"),
                    },
                });
            }
            LeverId::Identity => {
                // The hijacked record's handler pointer must now target the
                // injected handler (VA | thumb-bit), and the injected handler
                // carries the RESP_MAGIC identity string.
                match (fact(l, "handler_va"), fact(l, "record_off")) {
                    (Some(hva), Some(roff)) => {
                        // Read the record's handler pointer once, bounds-guarded — the
                        // audit must never panic, even on a report whose record_off is
                        // near EOF. Out of bounds reads as 0 (ok_ptr stays false).
                        let got = ((roff as usize) + 8 <= img.len())
                            .then(|| thumb::read_u32(img, roff as usize + 4));
                        let ok_ptr = got == Some(hva | 1);
                        checks.push(AuditCheck {
                            lever: name,
                            what: "record repointed to injected handler".into(),
                            ok: ok_ptr,
                            detail: format!(
                                "record 0x{roff:08x}+4 -> 0x{:08x} (want 0x{:08x})",
                                got.unwrap_or(0),
                                hva | 1
                            ),
                        });
                        checks.push(AuditCheck {
                            lever: name,
                            what: "handler injected (RESP_MAGIC present)".into(),
                            ok: is_freemkv_patched(img) && stub_present(img, hva),
                            detail: format!("handler_va 0x{hva:08x}"),
                        });
                        // Debug-knock Reboot arm: when the build resolved a boot
                        // function entry (modern MT1959 geometry), the emitted
                        // handler MUST carry that entry as a Thumb-tagged 32-bit
                        // literal — the `ldr r6,[pc,#imm]` load feeding the `blx r6`.
                        // Missing it means the wire verb dispatches but the actual
                        // reboot never happens. Classic reports `boot_function_entry
                        // == 0` (Reboot arm inert on purpose) → no assertion.
                        if let Some(entry) = fact(l, "boot_function_entry") {
                            if entry != 0 {
                                let want = entry | 1;
                                // Handler is <2 KiB; scan a 4-KiB window from handler_va
                                // — bounded and cheap. Never panics on short images.
                                let start = hva as usize;
                                let end = start.saturating_add(0x1000).min(img.len());
                                let found = if start < end {
                                    img[start..end].windows(4).any(|w| {
                                        u32::from_le_bytes([w[0], w[1], w[2], w[3]]) == want
                                    })
                                } else {
                                    false
                                };
                                checks.push(AuditCheck {
                                    lever: name,
                                    what: "Reboot boot-function-entry literal baked".into(),
                                    ok: found,
                                    detail: format!(
                                        "want u32 0x{want:08x} in handler at 0x{hva:08x} (window +0x1000)"
                                    ),
                                });
                            }
                        }
                    }
                    _ => checks.push(AuditCheck {
                        lever: name,
                        what: "handler facts present".into(),
                        ok: false,
                        detail: "missing handler_va/record_off".into(),
                    }),
                }
            }
            LeverId::Speed => {
                if let (Some(site), Some(stub)) =
                    (fact(l, "speed_tail_site"), fact(l, "speed_stub_va"))
                {
                    let mut entry = thumb::Asm::new();
                    entry.push(0x100);
                    let entry = entry.finish().expect("PUSH LR is encodable");
                    checks.push(AuditCheck {
                        lever: name,
                        what: "classic speed saved return".into(),
                        ok: img.get(site as usize..site as usize + 2) == Some(&entry[..2]),
                        detail: format!("PUSH LR before the classic speed call at 0x{site:08x}"),
                    });
                    check_branch_impl(
                        &mut checks,
                        name,
                        "classic speed tail",
                        img,
                        BranchInstall {
                            site: site + 2,
                            stub,
                            expected: thumb::encode_bl(site as usize + 2, stub),
                            kind: "bl",
                        },
                    );
                } else if let (Some(gate), Some(stub)) =
                    (fact(l, "speed_gate"), fact(l, "speed_stub_va"))
                {
                    check_bl(&mut checks, name, "speed detour bl", img, gate + 4, stub);
                } else {
                    checks.push(missing_facts(name, "missing speed_gate/speed_stub_va"));
                }
            }
            LeverId::RegionFree => {
                if let (Some(emitter), Some(stub)) =
                    (fact(l, "region_emitter"), fact(l, "region_stub_va"))
                {
                    check_bl(
                        &mut checks,
                        name,
                        "region detour bl",
                        img,
                        emitter + 6,
                        stub,
                    );
                } else {
                    checks.push(missing_facts(name, "missing region_emitter/region_stub_va"));
                }
            }
            LeverId::RawRead => {
                let classic = report.engine == "MT1939"
                    && original
                        .get(0x3000..0x3010)
                        .is_some_and(|b| b.starts_with(b"MT1939 Boot"));
                if l.hooks
                    .iter()
                    .any(|h| h.id == "uhd-conversion" && (!classic || h.variant.is_some()))
                {
                    let classic_conversion = l.hooks.iter().any(|h| {
                        h.id == "uhd-conversion"
                            && h.variant
                                .as_deref()
                                .is_some_and(|v| v.starts_with("complete media group: classic "))
                    });
                    let check = if classic || classic_conversion {
                        let flags = report.levers.iter().find_map(|v| fact(v, "flag_base"));
                        flags
                            .ok_or_else(|| anyhow::anyhow!("missing classic conversion flag base"))
                            .and_then(|flags| {
                                super::mt1939_uhd::UhdConversionPlan::inspect(original)
                                    .and_then(|p| p.verify(original, img, flags))
                            })
                    } else {
                        super::mt1959_uhd::Plan::inspect(original, super::core::FLAG_TABLE_BASE)
                            .and_then(|p| p.verify(img))
                    };
                    checks.push(AuditCheck {
                        lever: name,
                        what: "UHD conversion atomic group".into(),
                        ok: check.is_ok(),
                        detail: match check {
                            Ok(()) => "complete group or unchanged conversion sites".into(),
                            Err(e) => format!("{e:#}"),
                        },
                    });
                }
                let before = checks.len();
                if let (Some(site), Some(stub)) = (fact(l, "ake_site"), fact(l, "ake_stub_va")) {
                    // AKE install shape depends on the resolved gate variant:
                    // BU40N/desktop uses `B.W` (tail-call preservation); NB
                    // variants use `BL`. Try `B.W` first, fall back to `BL`; a
                    // valid install must be one of the two encodings targeting
                    // the AKE stub.
                    check_ake_detour(&mut checks, name, img, site, stub);
                }
                if let (Some(site), Some(stub)) = (fact(l, "gatea_gate"), fact(l, "gatea_stub_va"))
                {
                    check_bl(&mut checks, name, "Gate-A detour bl", img, site, stub);
                }
                if let (Some(site), Some(stub)) = (fact(l, "deny_site"), fact(l, "deny_stub_va")) {
                    check_bl(&mut checks, name, "deny-reset detour bl", img, site, stub);
                }
                // `Feature::Unrestricted` UHD media accept/refuse detour (REPORT KEY class-3 arm
                // on the SAME accept gate as BD). Present only when wired (explicit
                // REPORT KEY gate shape); optional, like the bus-enc detour above.
                // Proves the UHD arm's `bl` + stub landed at the class-3 check.
                if let (Some(site), Some(stub)) = (fact(l, "uhd_site"), fact(l, "uhd_stub_va")) {
                    check_bl(
                        &mut checks,
                        name,
                        "UHD media-gate detour bl",
                        img,
                        site,
                        stub,
                    );
                }
                // `Feature::Bd` BD-refuse detour (REPORT KEY mode-0 class gate).
                // Present only when wired (gate is a known MT1959 shape); optional,
                // like the bus-enc/UHD detours above. Proves the BD-refuse `bl` + stub
                // landed at the mode-0 class check.
                if let (Some(site), Some(stub)) = (fact(l, "bd_site"), fact(l, "bd_stub_va")) {
                    check_bl(&mut checks, name, "BD-refuse detour bl", img, site, stub);
                }
                // `Feature::Unrestricted` auth-cell state-band widen detour
                // (`AUTH_CELL_SIG` `anchor+10`, the post-classification
                // `cmp (state>>4),#0xC; bne <6F/02>`). Present only when wired
                // (image carries the extended `ldr r4,[pc,...] = 0x01FF9E04` prefix);
                // optional. Proves the widen `bl` + stub landed at the state-band
                // check.
                if let (Some(site), Some(stub)) =
                    (fact(l, "auth_cell_site"), fact(l, "auth_cell_stub_va"))
                {
                    check_bl(
                        &mut checks,
                        name,
                        "auth-cell widen detour bl",
                        img,
                        site,
                        stub,
                    );
                }
                // HRL skip (`flag[Feature::Hrl]==STATE_ON`): one shared stub reached
                // by a `bl` at each of the three cert-path check sites. Present only
                // when wired (HRL cert path is the known shape); optional, like the
                // bus-enc/UHD detours above. Each `bl` is recomputed and re-checked.
                if let Some(stub) = fact(l, "hrl_stub_va") {
                    for key in ["hrl_site", "hrl_site2", "hrl_site3"] {
                        if let Some(site) = fact(l, key) {
                            check_bl(&mut checks, name, "HRL-skip detour bl", img, site, stub);
                        }
                    }
                }
                // Classic (`04 01`/`04 02`) emits NO deny-reset detour: the `deny`
                // block must be byte-identical to OEM (a wrong reply desyncs the
                // SCSI FIFO). When a `deny` address fact is present, assert the
                // 0x40 bytes at it are untouched vs the original image.
                if let Some(deny) = fact(l, "deny") {
                    let a = deny as usize;
                    let ok = a + 0x40 <= img.len()
                        && a + 0x40 <= original.len()
                        && img[a..a + 0x40] == original[a..a + 0x40];
                    checks.push(AuditCheck {
                        lever: name,
                        what: "deny block byte-identical to OEM".into(),
                        ok,
                        detail: format!("deny 0x{deny:08x}..+0x40 untouched"),
                    });
                }
                // The clear-VID scratch buffer is audit-only (no stub consumes it);
                // assert it is the unique runtime RAM cell it must be.
                if let Some(scratch) = fact(l, "scratch") {
                    let ok = (0x0020_1000..0x0030_0000).contains(&scratch);
                    checks.push(AuditCheck {
                        lever: name,
                        what: "scratch buffer in runtime RAM window".into(),
                        ok,
                        detail: format!("scratch 0x{scratch:08x} in [0x201000,0x300000)"),
                    });
                }
                if checks.len() == before {
                    checks.push(missing_facts(name, "missing AKE/Gate-A/deny detour facts"));
                }
            }
            LeverId::DowngradeEnable => {
                let Some(de) = fact(l, "de_off") else {
                    checks.push(missing_facts(name, "missing de_off"));
                    continue;
                };
                let a = de as usize;
                let ok = a < img.len() && img[a] == 0xDE;
                checks.push(AuditCheck {
                    lever: name,
                    what: "DE byte set".into(),
                    ok,
                    detail: format!(
                        "0x{de:08x} = 0x{:02x} (want 0xDE)",
                        img.get(a).copied().unwrap_or(0)
                    ),
                });
            }
        }
    }

    // Integrity: the produced image must carry valid CMAC tables.
    checks.push(AuditCheck {
        lever: "integrity",
        what: "CMAC tables verify".into(),
        ok: cmac::verify(img),
        detail: "AES-CMAC over active regions".into(),
    });

    AuditResult { checks }
}

#[cfg(test)]
#[path = "audit_tests.rs"]
mod tests;
