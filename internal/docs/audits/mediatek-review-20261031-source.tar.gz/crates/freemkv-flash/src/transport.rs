//! The ONE bridge between freemkv-flash's [`ScsiDevice`] and the protocol
//! crates' `Transport` traits: [`pioneer_optical::drive::Transport`] and
//! [`mediatek_optical::drive::Transport`].
//!
//! Every vendor command sequence (Pioneer identity, read-unlock knock, memory
//! reads, OEM update entry / transfer / finish, the DVR handshake; the MediaTek
//! flash session) is issued by `pioneer_optical::drive::*` or
//! `mediatek_optical::drive::*`; the rest of the flasher never builds a vendor
//! CDB. This adapter passes the crate's CDBs straight through to the SCSI layer
//! and adds the one policy the flasher owns: **strictness** — a flash transport
//! sends every data-out through [`ScsiDevice::command_out_strict`] (abort on any
//! nonzero status, no retry), exactly as the OEM host loop does; a read
//! transport uses the lenient path.
//!
//! Invariant (checked by `tests/no_cdbs.rs`): no Pioneer or MediaTek backend
//! source file, this one included, contains a WRITE BUFFER / READ BUFFER opcode
//! literal.

use std::cell::RefCell;

use anyhow::{anyhow, Result};
use pioneer_optical::drive::{Data, Error, Transport};
use pioneer_optical::Identity;

use crate::platform::{sense_triplet, ScsiDevice, ScsiSenseError};

/// A [`ScsiDevice`] that can be lent to a [`ScsiTransport`] while the caller
/// keeps issuing its own commands between session calls (the flash session
/// borrows the transport for its whole lifetime).
pub struct SharedDevice<'a>(RefCell<&'a mut dyn ScsiDevice>);

impl<'a> SharedDevice<'a> {
    /// Wrap `dev`.
    pub fn new(dev: &'a mut dyn ScsiDevice) -> Self {
        Self(RefCell::new(dev))
    }

    /// Run `f` with exclusive access to the device.
    pub fn with<R>(&self, f: impl FnOnce(&mut dyn ScsiDevice) -> R) -> R {
        f(&mut **self.0.borrow_mut())
    }
}

/// Adapter implementing [`Transport`] over a [`SharedDevice`].
pub struct ScsiTransport<'a, 'd> {
    dev: &'a SharedDevice<'d>,
    strict: bool,
    sense: Option<(u8, u8, u8)>,
    read_counts: [usize; 3],
    last_read_problem: Option<String>,
    empty_write_attempted: bool,
    payload_write_attempted: bool,
}

impl<'a, 'd> ScsiTransport<'a, 'd> {
    /// Read-path transport: lenient data-out (the read-unlock knock tolerates a
    /// self-clearing UNIT ATTENTION).
    pub fn reads(dev: &'a SharedDevice<'d>) -> Self {
        Self {
            dev,
            strict: false,
            sense: None,
            read_counts: [0; 3],
            last_read_problem: None,
            empty_write_attempted: false,
            payload_write_attempted: false,
        }
    }

    /// Flash-path transport: strict data-out.
    pub fn flash(dev: &'a SharedDevice<'d>) -> Self {
        Self {
            dev,
            strict: true,
            sense: None,
            read_counts: [0; 3],
            last_read_problem: None,
            empty_write_attempted: false,
            payload_write_attempted: false,
        }
    }

    /// Summarize actual input requests, without hiding short transfers or errors.
    pub(crate) fn read_summary(&self) -> String {
        format!(
            "Receiver probe reads: {} complete, {} short, {} failed{}",
            self.read_counts[0],
            self.read_counts[1],
            self.read_counts[2],
            self.last_read_problem
                .as_ref()
                .map(|s| format!("; last read problem: {s}"))
                .unwrap_or_default()
        )
    }

    /// Whether a strict, zero-payload command reached the transport.
    pub(crate) fn empty_write_attempted(&self) -> bool {
        self.empty_write_attempted
    }

    /// Whether a strict nonempty write was attempted, including a failed send.
    pub(crate) fn payload_write_attempted(&self) -> bool {
        self.payload_write_attempted
    }
}

impl Transport for ScsiTransport<'_, '_> {
    type Error = anyhow::Error;

    fn exec(&mut self, cdb: &[u8], data: Data<'_>) -> Result<usize> {
        let strict = self.strict;
        let result = self.dev.with(|d| match data {
            Data::In(buf) => {
                let got = d.command_in(cdb, buf.len())?;
                let n = got.len();
                anyhow::ensure!(
                    n <= buf.len(),
                    "Pioneer transport returned {n} bytes for a {}-byte buffer",
                    buf.len()
                );
                buf[..n].copy_from_slice(&got[..n]);
                Ok(n)
            }
            Data::None | Data::Out(_) => {
                let payload: &[u8] = match data {
                    Data::Out(bytes) => bytes,
                    _ => &[],
                };
                if strict && payload.is_empty() {
                    self.empty_write_attempted = true;
                }
                if strict && !payload.is_empty() {
                    self.payload_write_attempted = true;
                }
                let sent = if strict {
                    d.command_out_strict(cdb, payload)
                } else {
                    d.command_out(cdb, payload)
                };
                // Flash-path WRITE BUFFER chunks: log each so the saved
                // diagnostic shows the sequence up to the failing chunk.
                if strict && !payload.is_empty() {
                    match &sent {
                        Ok(()) => crate::diagnostics::record(format!(
                            "Flash WRITE BUFFER chunk: cdb={cdb:02x?} length={} result=ok",
                            payload.len()
                        )),
                        Err(error) => crate::diagnostics::record(format!(
                            "Flash WRITE BUFFER chunk: cdb={cdb:02x?} length={} result=FAILED sense={:?}: {error:#}",
                            payload.len(),
                            sense_triplet(error)
                        )),
                    }
                }
                sent?;
                Ok(payload.len())
            }
        });
        self.sense = result.as_ref().err().and_then(sense_triplet);
        result
    }

    fn sense(&self) -> Option<(u8, u8, u8)> {
        self.sense
    }
}

/// The MediaTek transport: identical policy, with one wire difference kept
/// from the MediaTek backend's history — a no-data command (TEST UNIT READY)
/// is issued as a zero-length data-in, as the OEM tool does.
impl mediatek_optical::drive::Transport for ScsiTransport<'_, '_> {
    type Error = anyhow::Error;

    fn exec(&mut self, cdb: &[u8], data: mediatek_optical::drive::Data<'_>) -> Result<usize> {
        use mediatek_optical::drive::Data as MtkData;
        let requested = match &data {
            MtkData::In(buf) => Some(buf.len()),
            _ => None,
        };
        let strict = self.strict;
        let result = self.dev.with(|d| match data {
            MtkData::In(buf) => {
                let got = d.command_in(cdb, buf.len())?;
                let n = got.len();
                anyhow::ensure!(
                    n <= buf.len(),
                    "MediaTek transport returned {n} bytes for a {}-byte buffer",
                    buf.len()
                );
                buf[..n].copy_from_slice(&got[..n]);
                Ok(n)
            }
            MtkData::None => d.command_in(cdb, 0).map(|_| 0),
            MtkData::Out(bytes) => {
                if strict && bytes.is_empty() {
                    self.empty_write_attempted = true;
                }
                if strict && !bytes.is_empty() {
                    self.payload_write_attempted = true;
                }
                if strict {
                    d.command_out_directed(cdb, bytes)?;
                } else {
                    d.command_out(cdb, bytes)?;
                }
                Ok(bytes.len())
            }
        });
        self.sense = result.as_ref().err().and_then(sense_triplet);
        if let Some(requested) = requested {
            match &result {
                Ok(n) if *n == requested => self.read_counts[0] += 1,
                Ok(n) => {
                    self.read_counts[1] += 1;
                    self.last_read_problem =
                        Some(format!("CDB {cdb:02x?}: received {n}/{requested} bytes"));
                }
                Err(error) => {
                    self.read_counts[2] += 1;
                    self.last_read_problem =
                        Some(format!("CDB {cdb:02x?}: {error:#}; sense={:?}", self.sense));
                }
            }
        }
        result
    }

    fn sense(&self) -> Option<(u8, u8, u8)> {
        self.sense
    }
}

/// Fold a MediaTek sequence error back into `anyhow`, keeping the transport's
/// own error (and with it any structured sense) intact.
pub fn mtk_err(error: mediatek_optical::drive::Error<anyhow::Error>) -> anyhow::Error {
    match error {
        mediatek_optical::drive::Error::Transport(e) => e,
        other => anyhow!("{other}"),
    }
}

/// Fold a high-level flash error back into `anyhow`, keeping the structured
/// sense (so `sense_triplet` still works on a `Locked` refusal).
pub fn flash_err(error: Error<anyhow::Error>) -> anyhow::Error {
    match error {
        Error::Transport(e) => e,
        Error::Locked => anyhow::Error::new(ScsiSenseError::new(
            5,
            0x24,
            0,
            "drive refused the command (sense 05/24/00: locked / invalid field)",
        )),
        other => anyhow!("{other}"),
    }
}

/// One vendor firmware read: exactly `len` bytes at `off`. The crate issues the
/// read-unlock knock itself before every read.
pub fn read_memory_exact(dev: &mut dyn ScsiDevice, off: u32, len: u32) -> Result<Vec<u8>> {
    let shared = SharedDevice::new(dev);
    let mut transport = ScsiTransport::reads(&shared);
    let mut buf = vec![0u8; len as usize];
    let n =
        pioneer_optical::drive::read_memory(&mut transport, off, &mut buf).map_err(flash_err)?;
    buf.truncate(n);
    Ok(buf)
}

/// Capture uses the same validated CDB response contract as discovery.
pub fn identify_protocol(dev: &mut dyn ScsiDevice) -> Result<Identity> {
    let shared = SharedDevice::new(dev);
    let mut transport = ScsiTransport::reads(&shared);
    pioneer_optical::drive::identify_protocol(&mut transport).map_err(flash_err)
}

/// INQUIRY + vendor identity via `drive::identify`, on an already-shared device.
/// Makes no state-changing call.
pub fn identify_on(shared: &SharedDevice<'_>) -> Result<Identity> {
    let mut transport = ScsiTransport::reads(shared);
    pioneer_optical::drive::identify(&mut transport).map_err(flash_err)
}

/// [`identify_on`] for a bare device.
pub fn identify(dev: &mut dyn ScsiDevice) -> Result<Identity> {
    identify_on(&SharedDevice::new(dev))
}

#[cfg(test)]
#[path = "transport_tests.rs"]
mod tests;
