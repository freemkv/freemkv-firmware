//! Unit tests for [`super`] (the generic engine: flash flow + safety gate).

use super::*;

#[test]
fn required_info_identity_failure_is_not_presented_as_an_unsupported_drive() {
    let mut dev =
        MockScsiDevice::new().on_fail(|c| c.first() == Some(&0x12), "private INQUIRY failure");
    let error = crate::user_error::read_only(super::info(&mut dev, None)).unwrap_err();
    let issue = crate::workflow::user_error(&error);
    assert_eq!(issue.id, "errors.connection");
    assert_eq!(issue.consequence, Some("errors.no_firmware_write"));
    assert!(format!("{error:#}").contains("private INQUIRY failure"));
    assert_eq!(
        dev.reads.len(),
        1,
        "stop before presenting guessed identity/capability rows"
    );
    assert!(dev.writes.is_empty());
}

#[test]
fn backup_failure_question_retains_localized_cause_and_no_write_evidence() {
    struct Decline(bool);
    impl Confirm for Decline {
        fn confirm(&mut self, _: &crate::backend::AuthorizedPlan) -> Result<bool> {
            panic!("no final write consent")
        }
        fn proceed_without_backup(&mut self, reason: &str) -> Result<bool> {
            self.0 = true;
            assert!(
                reason.starts_with('\u{1e}'),
                "retain stable message IDs through the confirmation boundary"
            );
            for language in crate::localization::Language::ALL {
                let text = crate::localization::render(language, reason);
                assert!(text.contains(crate::localization::get(language, "errors.backup_failed")));
                assert!(text.contains(crate::localization::get(
                    language,
                    "errors.no_firmware_write"
                )));
                assert!(!text.contains("private status 0x1234"));
            }
            Ok(false)
        }
    }
    let mut confirmation = Decline(false);
    let error = offer_flash_without_backup(
        &mut confirmation,
        true,
        anyhow::anyhow!("private status 0x1234")
            .context(crate::user_error::IssueCode::BackupFailed),
    )
    .err()
    .expect("declining must refuse the update");
    assert!(
        confirmation.0,
        "the localized backup question must actually be asked"
    );
    assert_eq!(
        crate::workflow::user_error(&error).id,
        "errors.backup_failed"
    );
}

#[test]
fn a_backend_requiring_backup_never_offers_an_unusable_bypass() {
    struct NoBypass;
    impl Confirm for NoBypass {
        fn confirm(&mut self, _: &crate::backend::AuthorizedPlan) -> Result<bool> {
            panic!("no write consent");
        }
        fn proceed_without_backup(&mut self, _: &str) -> Result<bool> {
            panic!("must not offer an impossible bypass");
        }
    }
    assert!(!Pioneer::new().flash().unwrap().can_proceed_without_backup());
    assert!(Mtk.flash().unwrap().can_proceed_without_backup());
    let error = offer_flash_without_backup(
        &mut NoBypass,
        false,
        anyhow::anyhow!("private capture error"),
    )
    .err()
    .expect("a required backup cannot be waived");
    let issue = crate::workflow::user_error(&error);
    assert_eq!(issue.id, "errors.backup_required");
    assert_eq!(issue.consequence, Some("errors.no_firmware_write"));
}
use crate::backend::{BackupFacet, DumpFacet, FileFacet};
use crate::backends::mtk::crossflash::{decide_model, ensure_image_matches_drive};
use crate::backends::mtk::file_info::{classify_file, CmacSummary};
use crate::backends::mtk::{
    Mtk, CHUNK, IMAGE_SIZE, ROM_003000_LEN, ROM_1EC000_LEN, ROM_1EC000_OFFSET, ROM_1F0000_LEN,
    ROM_1F0000_OFFSET,
};
use crate::backends::mtk::{UserDump, IMAGE, LEGACY_TAR};
use crate::backends::pioneer::Pioneer;
use crate::manifest::FlashMode;
use crate::platform::{MockScsiDevice, ScsiDevice};

/// The engine's flash with consent already given (the confirmation is the
/// front-end's; these tests exercise the gates around it).
fn flash(dev: &mut dyn ScsiDevice, drive: &dyn Backend, req: &FlashRequest) -> Result<()> {
    super::flash(dev, drive, req, &mut crate::workflow::Preconfirmed).map(drop)
}

/// Observe the very first data-out command and prove the rollback file is
/// already present, readable, and accepted by the same backend's flash path.
struct BackupBeforeWriteDevice {
    inner: MockScsiDevice,
    backup_path: std::path::PathBuf,
    checked: bool,
}

impl ScsiDevice for BackupBeforeWriteDevice {
    fn command_in(&mut self, cdb: &[u8], len: usize) -> Result<Vec<u8>> {
        self.inner.command_in(cdb, len)
    }

    fn command_out(&mut self, cdb: &[u8], bytes: &[u8]) -> Result<()> {
        if !self.checked {
            let archive = std::fs::read(&self.backup_path)
                .context("first write preceded the durable rollback file")?;
            BackupFacet::validate(&Mtk, &archive, "BD-RE BU40N")?;
            self.checked = true;
        }
        self.inner.command_out(cdb, bytes)
    }

    fn describe(&self) -> String {
        self.inner.describe()
    }

    fn medium_status(&mut self) -> Result<MediumStatus> {
        self.inner.medium_status()
    }
}

/// A non-zero, byte-position-dependent pattern (distinguishable from an
/// all-zero or all-constant image, and from its own AES-encrypted form).
fn patterned_image(len: usize) -> Vec<u8> {
    (0..len).map(|i| (i % 251) as u8).collect()
}

/// Stamp a valid MT19xx drive descriptor at 0x1EC000: `model` at +0x08 and the
/// `MTEKMT1959` family tag at +0x34, so the write-path model gate recognizes it.
fn stamp_descriptor(img: &mut [u8], model: &str) {
    let d = ROM_1EC000_OFFSET as usize;
    img[d..d + 0x58].fill(0);
    img[d..d + 28].fill(b' ');
    img[d..d + 8].copy_from_slice(b"HL-DT-ST");
    img[d + 0x18..d + 0x1c].copy_from_slice(b"1.00");
    img[d + 0x08..d + 0x08 + model.len()].copy_from_slice(model.as_bytes());
    img[d + 0x34..d + 0x34 + 10].copy_from_slice(b"MTEKMT1959");
}

/// Turn a full-size image into one the write-path gates accept: stamp a matching
/// descriptor + one active CMAC range, then sign it so `cmac::verify` passes.
fn make_flashable(mut img: Vec<u8>, model: &str) -> Vec<u8> {
    assert_eq!(img.len(), IMAGE_SIZE);
    img[..0x400].copy_from_slice(stored_boot_page());
    stamp_descriptor(&mut img, model);
    crate::backends::mtk::fixture::stamp(&mut img, &crate::backends::mtk::fixture::BU3);
    let img = with_active_cmac_range(img, 0x11000, 0x1FFFF);
    crate::cmac::resign(&img).expect("resign a well-formed image")
}

/// A flashable MT1959 image of `model` on a different board line than BU3: the
/// same chip as a BU40N drive, but a different hardware family, so the family
/// gate (not the chip gate) refuses a crossflash onto a BU40N.
fn make_flashable_other_family(model: &str) -> Vec<u8> {
    let board = crate::backends::mtk::fixture::Board {
        platform: "BU9",
        ..crate::backends::mtk::fixture::BU3
    };
    let mut img = vec![0u8; IMAGE_SIZE];
    img[..0x400].copy_from_slice(stored_boot_page());
    stamp_descriptor(&mut img, model);
    crate::backends::mtk::fixture::stamp(&mut img, &board);
    let img = with_active_cmac_range(img, 0x11000, 0x1FFFF);
    crate::cmac::resign(&img).expect("resign a well-formed image")
}

/// The stored boot page every cataloged MT1959 build shares.
pub(crate) fn stored_boot_page() -> &'static [u8] {
    crate::backends::mtk::oem::catalog()
        .default_for(mediatek_optical::Chip::Mt1959)
        .expect("MT1959 default")
        .boot_page()
}

/// Big-endian 24-bit offset bytes, as they appear at `cdb[3..6]`.
fn offset_bytes(offset: u32) -> [u8; 3] {
    [(offset >> 16) as u8, (offset >> 8) as u8, offset as u8]
}

fn is_stream_write(cdb: &[u8]) -> bool {
    cdb.first() == Some(&0x3B) && cdb.get(1).map(|m| m & 0x1f) == Some(0x06)
}

/// The READ BUFFER length, big-endian 24-bit at `cdb[6..9]`.
fn read_len(cdb: &[u8]) -> Option<u32> {
    let b = cdb.get(6..9)?;
    Some(u32::from_be_bytes([0, b[0], b[1], b[2]]))
}

/// A banner or descriptor read at its exact identity length: the only reads
/// the chip gate issues. A firmware chunk at the same offset does not match.
fn is_identity_read(cdb: &[u8]) -> bool {
    is_mode6_read(cdb)
        && ((cdb.get(3..6) == Some(&offset_bytes(ROM_1EC000_OFFSET)[..])
            && read_len(cdb) == Some(ROM_1EC000_LEN))
            || (cdb.get(3..6) == Some(&offset_bytes(0x3000)[..])
                && read_len(cdb) == Some(ROM_003000_LEN)))
}

fn is_mode6_read(cdb: &[u8]) -> bool {
    cdb.first() == Some(&0x3C) && cdb.get(1).map(|m| m & 0x1f) == Some(0x06)
}

/// A `UserDump` with distinct, non-zero patterns in the two restorable regions
/// (rom_1EC000 / rom_1F0000), so a restore test can assert on real content.
fn sample_user_dump() -> UserDump {
    UserDump {
        rom_003000: vec![0u8; ROM_003000_LEN as usize],
        rom_1ec000: patterned_image(ROM_1EC000_LEN as usize),
        rom_1f0000: (0..ROM_1F0000_LEN as usize)
            .map(|i| ((i * 7 + 3) % 251) as u8)
            .collect(),
        inq: {
            let mut data = vec![0u8; 96];
            data[4] = 91;
            data
        },
        fd_fwdate: descriptor(0x010C, 16),
        fd_sn: descriptor(0x0108, 16),
    }
}

static BACKUP_COUNTER: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

fn backup_firmware() -> Vec<u8> {
    make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N")
}

fn coherent_backup() -> BackupArtifact {
    let firmware = backup_firmware();
    let mut per_unit = sample_user_dump();
    let d = ROM_1EC000_OFFSET as usize;
    let n = ROM_1F0000_OFFSET as usize;
    per_unit
        .rom_1ec000
        .copy_from_slice(&firmware[d..d + ROM_1EC000_LEN as usize]);
    per_unit
        .rom_1f0000
        .copy_from_slice(&firmware[n..n + ROM_1F0000_LEN as usize]);
    BackupArtifact {
        firmware,
        per_unit,
        drive_product: "BD-RE BU40N".into(),
    }
}

fn fresh_backup_path() -> std::path::PathBuf {
    std::env::temp_dir().join(format!(
        "freemkv-backup-{}-{}.tar",
        std::process::id(),
        BACKUP_COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
            ^ std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos() as u64
    ))
}

fn bin_req(image: Vec<u8>, execute: bool) -> FlashRequest {
    FlashRequest {
        current: None,
        input: image,
        input_format: &IMAGE,
        mode: FlashMode::Full,
        execute,
        acknowledged_risk: execute,
        enc_override: None,
        drive_model: "BU40N".into(),
        verbose: false,
        predump_out: execute.then(fresh_backup_path),
    }
}

#[test]
fn pioneer_real_ud04_envelope_is_offline_only() {
    let Ok(path) = std::env::var("PIONEER_UD04_ENC_FIXTURE") else {
        return; // Local OEM fixture is not checked into the source repository.
    };
    let image = std::fs::read(path).unwrap();
    assert_eq!(image.len(), 0x1d7000);
    assert_eq!(
        format!("{:x}", Sha256::digest(&image)),
        "a5aa757081478620637ed2950b540f35f1cbb969598532cfc872daba0a0366e6"
    );
    let mut req = bin_req(image, false);
    req.input_format = &crate::backends::pioneer::ENVELOPE;
    req.drive_model = "BDR-UD04".into();
    let mut dev = MockScsiDevice::pioneer();
    flash(&mut dev, &Pioneer::new(), &req).unwrap();
    assert!(dev.writes.is_empty());
    assert!(dev.reads.is_empty());
    req.execute = true;
    assert!(flash(&mut dev, &Pioneer::new(), &req).is_err());
    assert!(dev.writes.is_empty());
    assert!(dev.reads.is_empty());
}

#[test]
fn pioneer_offline_plan_does_not_gate_on_marketing_model() {
    let Ok(path) = std::env::var("PIONEER_UD04_ENC_FIXTURE") else {
        return;
    };
    let image = std::fs::read(path).unwrap();
    let mut req = bin_req(image, false);
    req.input_format = &crate::backends::pioneer::ENVELOPE;
    req.drive_model = "BDR-UD040".into();
    let mut dev = MockScsiDevice::pioneer();
    flash(&mut dev, &Pioneer::new(), &req).unwrap();
    assert!(dev.reads.is_empty());
    assert!(dev.writes.is_empty());
}

#[test]
fn pioneer_offline_plan_rejects_malformed_envelope_without_device_io() {
    let mut image = vec![0u8; crate::backends::pioneer::IMAGE_MIN];
    let header = b"********  Copyright(c) 2000 Pioneer Corporation  ********\r\nThis is microcode file.\r\nID : PIONEER BD-RW   BDR-212.\r\nRevision Level : 1.05 .\r\n";
    image[..header.len()].copy_from_slice(header);
    let mut req = bin_req(image, false);
    req.input_format = &crate::backends::pioneer::ENVELOPE;
    req.drive_model = "BDR-212".into();
    let mut dev = MockScsiDevice::pioneer();
    let err = flash(&mut dev, &Pioneer::new(), &req).unwrap_err();
    assert!(format!("{err:#}").contains("malformed bundle"));
    assert!(dev.reads.is_empty());
    assert!(dev.writes.is_empty());
}

#[test]
fn pioneer_template_free_backup_rejects_missing_hardware_identity_without_service_io() {
    let mut inquiry = vec![b' '; 36];
    inquiry[0] = 0x05;
    inquiry[8..16].copy_from_slice(b"PIONEER ");
    inquiry[16..32].copy_from_slice(b"BD-RW   BDR-UD04");
    let mut dev = MockScsiDevice::new()
        .on(|cdb| cdb.first() == Some(&0x12), inquiry)
        .on(
            |cdb| cdb.first() == Some(&0x3C) && cdb.get(2) == Some(&0xF1),
            vec![0xA5; 8],
        );
    let out = std::env::temp_dir().join(format!("pioneer-not-backup-{}.tar", std::process::id()));
    let err = backup(&mut dev, &Pioneer::new(), &out, false).unwrap_err();
    assert!(format!("{err:#}").contains("complete hardware identity"));
    assert!(dev.reads.iter().all(|cdb| {
        cdb.first() == Some(&0x12) || (cdb.first() == Some(&0x3C) && cdb.get(2) == Some(&0xF1))
    }));
    assert!(dev.writes.is_empty());
    assert!(!out.exists());
}

#[test]
fn pioneer_execute_without_risk_ack_is_safety_gated_and_issues_no_writes() {
    // A package whose pre-backup plan passes, so the safety gate decides.
    let envelope = |kind: &str| {
        let mut bytes = vec![0u8; 0x1000];
        let header = format!("********  Copyright(c) 2000 Pioneer Corporation  ********\r\nID : PIONEER BD-RW   BDR-UD04\r\nRevision Level : 1.00\r\nHardware Version : SAT 8800\r\nKernel Version : ID60\r\nDestination : GENERAL\r\nFile Type : {kind}\r\n");
        bytes[..header.len()].copy_from_slice(header.as_bytes());
        bytes
    };
    let mut tar = tar::Builder::new(Vec::new());
    for (name, bytes) in [
        ("kernel.enc", envelope("Kernel")),
        ("normal.enc", envelope("Normal")),
    ] {
        let mut header = tar::Header::new_gnu();
        header.set_size(bytes.len() as u64);
        header.set_mode(0o644);
        header.set_cksum();
        tar.append_data(&mut header, name, bytes.as_slice())
            .unwrap();
    }
    let mut req = bin_req(tar.into_inner().unwrap(), true);
    req.input_format = &crate::backends::pioneer::PACKAGE;
    req.acknowledged_risk = false;
    req.drive_model = "BD-RW   BDR-UD04".into();
    let mut dev = MockScsiDevice::pioneer();
    let err = flash(&mut dev, &Pioneer::new(), &req).unwrap_err();
    // The shared safety gate fires before any backup or write.
    assert!(format!("{err:#}").contains("SAFETY GATE"), "{err:#}");
    assert!(dev.writes.is_empty());
    assert!(dev.reads.is_empty());
}

#[test]
fn flash_dry_run_writes_nothing_but_reads_for_backup() {
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let req = bin_req(
        make_flashable(vec![0x11u8; IMAGE_SIZE], "BD-RE BU40N"),
        false,
    );
    flash(&mut dev, &Mtk, &req).unwrap();
    assert!(dev.writes.is_empty(), "dry-run must not write");
    assert!(
        !dev.reads.is_empty(),
        "dry-run still reads for the backup + plan"
    );
}

#[test]
fn flash_dry_run_rejects_bad_cmac_without_writes() {
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let mut image = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    image[0x11000] ^= 1; // inside the active authenticated range
    let err = flash(&mut dev, &Mtk, &bin_req(image, false)).unwrap_err();
    assert!(format!("{err:#}").contains("AES-CMAC"), "got: {err}");
    assert!(dev.writes.is_empty());
}

#[test]
fn flash_dry_run_rejects_a_different_family_without_writes() {
    // A different-model image of another hardware family is refused at the dry
    // run, before any write. (A same-family image is a crossflash; see the
    // crossflash tests.)
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let image = make_flashable_other_family("WH16NS60");
    let err = flash(&mut dev, &Mtk, &bin_req(image, false)).unwrap_err();
    assert!(
        format!("{err:#}").contains("different hardware family"),
        "got: {err}"
    );
    assert!(dev.writes.is_empty());
}

#[test]
fn flash_rejects_wrong_size_bin() {
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let req = bin_req(vec![0u8; 1024], false);
    assert!(flash(&mut dev, &Mtk, &req).is_err());
}

#[test]
fn flash_execute_streams_verbatim_and_verifies() {
    // A signed, model-matching image (mostly zero); the mock's zero-fill
    // read-back matches inside the CMAC-protected range (also zero).
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let image = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    let req = bin_req(image.clone(), true);
    flash(&mut dev, &Mtk, &req).unwrap();
    // 1 PREPARE + 128 STREAM + 1 COMMIT, all WRITE_BUFFER (0x3B).
    assert_eq!(dev.writes.len(), 1 + IMAGE_SIZE / CHUNK + 1);
    assert!(dev.writes.iter().all(|(cdb, _)| cdb[0] == 0x3B));
    // Bytes streamed are the verbatim image.
    let streamed: Vec<u8> = dev
        .writes
        .iter()
        .filter(|(cdb, _)| is_stream_write(cdb))
        .flat_map(|(_, data)| data.clone())
        .collect();
    assert_eq!(streamed, image);
}

#[test]
fn validated_rollback_file_exists_before_first_device_write() {
    let mut req = bin_req(backup_firmware(), true);
    let backup_path = fresh_backup_path();
    req.predump_out = Some(backup_path.clone());
    let mut dev = BackupBeforeWriteDevice {
        inner: MockScsiDevice::echoing().with_firmware_image(backup_firmware()),
        backup_path: backup_path.clone(),
        checked: false,
    };
    flash(&mut dev, &Mtk, &req).unwrap();
    assert!(dev.checked);
    assert!(!dev.inner.writes.is_empty());
    std::fs::remove_file(backup_path).unwrap();
}

#[test]
fn failed_middle_stream_chunk_never_sends_commit_or_reports_success() {
    let failing_offset = offset_bytes((2 * CHUNK) as u32);
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on_fail(
            move |cdb| is_stream_write(cdb) && cdb.get(3..6) == Some(&failing_offset[..]),
            "injected stream failure",
        );
    let req = bin_req(backup_firmware(), true);
    let err = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(format!("{err:#}").contains("injected stream failure"));
    let stream_count = dev
        .writes
        .iter()
        .filter(|(cdb, _)| is_stream_write(cdb))
        .count();
    assert_eq!(stream_count, 2);
    assert_eq!(
        dev.writes.len(),
        3,
        "prepare and two chunks only; no commit"
    );
}

#[test]
fn failed_backup_persistence_prevents_first_device_write() {
    let mut req = bin_req(backup_firmware(), true);
    let nonexistent_parent = fresh_backup_path();
    req.predump_out = Some(nonexistent_parent.join("rollback.tar"));
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    let err = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(format!("{err:#}").contains("creating temporary backup"));
    assert!(dev.writes.is_empty());
    assert!(!nonexistent_parent.exists());
}

#[test]
fn flash_execute_requires_ack() {
    // A valid, model-matching image so the flow reaches the ACK gate (not the
    // CMAC/model gates) — the refusal here must be the missing acknowledgement.
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let mut req = bin_req(make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N"), true);
    req.acknowledged_risk = false;
    let err = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(format!("{err:#}").contains("SAFETY GATE"), "got: {err}");
}

#[test]
fn safety_requires_ack() {
    // The irreversible write path refuses without --i-understand-risk.
    assert!(check_safety(false).is_err());
    assert!(check_safety(true).is_ok());
}

// ---- non-tautological read-back verify: real content, echoed by the mock --

#[test]
fn flash_execute_streams_patterned_image_verbatim() {
    // A non-zero, position-dependent image against an ECHOING mock: the
    // streamed bytes must equal the original image, not merely "whatever the
    // mock happens to read back."
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    let image = make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N");
    let req = bin_req(image.clone(), true);
    flash(&mut dev, &Mtk, &req).unwrap();

    let streamed: Vec<u8> = dev
        .writes
        .iter()
        .filter(|(cdb, _)| is_stream_write(cdb))
        .flat_map(|(_, data)| data.clone())
        .collect();
    assert_eq!(streamed, image);
}

/// Stamp one ACTIVE CMAC entry at the integrity table so `[start, end]` is a
/// protected range (enabled=1, start, end). Mirrors the on-file layout the drive
/// authenticates: `[enabled(4) | start(4) | end(4) | tag(16)]` at 0x10400.
fn with_active_cmac_range(mut image: Vec<u8>, start: u32, end: u32) -> Vec<u8> {
    let off = 0x10400usize; // cmac::TABLE_OFFSET
                            // Other slots are erased metadata, not bytes from the payload pattern.
    image[off..off + crate::cmac::ENTRY_COUNT * crate::cmac::ENTRY_SIZE].fill(0xff);
    image[off..off + 4].copy_from_slice(&1u32.to_le_bytes()); // enabled
    image[off + 4..off + 8].copy_from_slice(&start.to_le_bytes());
    image[off + 8..off + 12].copy_from_slice(&end.to_le_bytes());
    image
}

#[test]
fn flash_execute_fails_on_mismatch_inside_a_cmac_protected_range() {
    // A read-back mismatch INSIDE a CMAC-protected range is genuine corruption
    // (those bytes the drive authenticates), so verify must FAIL. The mock answers
    // one chunk's READ BUFFER with wrong bytes inside the active protected range.
    let bad_offset = (CHUNK * 5) as u32; // 0x14000
    let image = make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N");
    assert!((0x11000..=0x1FFFF).contains(&bad_offset));
    let want = offset_bytes(bad_offset);
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on_after_stream(
            move |cdb| is_mode6_read(cdb) && cdb.get(3..6) == Some(&want[..]),
            vec![0xFFu8; CHUNK],
        );
    let req = bin_req(image, true);
    let err = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(
        matches!(err.downcast_ref::<mediatek_optical::update::FlashError<anyhow::Error>>(), Some(mediatek_optical::update::FlashError::Mismatch { differing, .. }) if *differing > 0),
        "unexpected error: {err}"
    );
}

/// Unreadable protected bytes must never become an unqualified success. If
/// startup also cannot prove the selected target, the update remains a failure.
#[test]
fn flash_execute_requires_target_startup_when_protected_readback_is_unavailable() {
    let bad_offset = (CHUNK * 5) as u32;
    let image = make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N");
    let want = offset_bytes(bad_offset);
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on_after_stream(|cdb| cdb.first() == Some(&0x12), vec![0; 36])
        .on_fail_after_stream(
            move |cdb| is_mode6_read(cdb) && cdb.get(3..6) == Some(&want[..]),
            "simulated read-back transport error",
        );
    let req = bin_req(image, true);
    let err = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(
        matches!(
            err.downcast_ref::<mediatek_optical::update::FlashError<anyhow::Error>>(),
            Some(mediatek_optical::update::FlashError::Startup(_))
        ),
        "{err:#}"
    );
    assert!(dev.writes.iter().any(|(cdb, _)| is_stream_write(cdb)));
}

#[test]
fn flash_execute_qualifies_unreadable_protected_bytes_after_exact_target_startup() {
    let want = offset_bytes((CHUNK * 5) as u32);
    let image = make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N");
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on_fail_after_stream(
            move |cdb| is_mode6_read(cdb) && cdb.get(3..6) == Some(&want[..]),
            "simulated read-back transport error",
        );
    let req = bin_req(image, true);
    let outcome = super::flash(&mut dev, &Mtk, &req, &mut crate::workflow::Preconfirmed).unwrap();
    assert!(!outcome.fully_verified());
    assert!(outcome.safe_to_probe());
    let crate::backend::UpdateOutcome::Completed(evidence) = outcome else {
        panic!("actual update must carry evidence")
    };
    assert!(evidence.target_started && !evidence.target_identity.is_empty());
    assert!(!evidence.unverified_regions.is_empty());
    assert!(!evidence.verified_regions.is_empty());
}

#[test]
fn flash_execute_tolerates_readback_mismatch_outside_protected_ranges() {
    // A mismatch OUTSIDE every CMAC-protected range — here the per-unit NVRAM/
    // calibration region, owned and rewritten by the drive — legitimately differs
    // on a perfect flash, so verify must PASS. Protected range placed away from it.
    let bad_offset = ROM_1F0000_OFFSET + CHUNK as u32; // inside per-unit NVRAM
    assert!((bad_offset as usize) < ROM_1F0000_OFFSET as usize + ROM_1F0000_LEN as usize);
    let image = make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N");
    assert!(
        bad_offset > 0x1FFFF,
        "mismatch must be outside the protected range"
    );
    let want = offset_bytes(bad_offset);
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on_after_stream(
            move |cdb| is_mode6_read(cdb) && cdb.get(3..6) == Some(&want[..]),
            vec![0xFFu8; CHUNK],
        );
    let req = bin_req(image, true);
    flash(&mut dev, &Mtk, &req)
        .expect("mismatch outside every CMAC-protected range must pass verify");
}

#[test]
fn flash_execute_streams_enc_payload_not_plaintext() {
    // The live receiver signature, without an override, selects AES transfer.
    let mut image = make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N");
    crate::backends::mtk::bulk_receiver_fixture::stamp(&mut image);
    // The device exposes decoded firmware, not the encrypted wire envelope.
    let mut dev = MockScsiDevice::new().with_firmware_image(image.clone());
    let req = bin_req(image.clone(), true);
    flash(&mut dev, &Mtk, &req).unwrap();

    let mut transferred: Vec<u8> = dev
        .writes
        .iter()
        .filter(|(cdb, _)| is_stream_write(cdb))
        .flat_map(|(_, data)| data.iter().copied())
        .collect();
    assert_eq!(transferred.len(), image.len(), "every image byte is sent");
    assert_ne!(transferred, image, "receiver requires encrypted bytes");
    // Decode the complete observed wire stream independently of preparation.
    use aes::cipher::{BlockDecrypt, KeyInit};
    let cipher = aes::Aes128::new_from_slice(&[
        0x5e, 0x9e, 0x4f, 0x00, 0x94, 0xef, 0x20, 0xab, 0x52, 0xe3, 0x5e, 0x73, 0x6a, 0xcb, 0x23,
        0x24,
    ])
    .unwrap();
    for block in transferred.as_chunks_mut::<16>().0 {
        cipher.decrypt_block(aes::cipher::Block::<aes::Aes128>::from_mut_slice(block));
    }
    assert_eq!(
        transferred, image,
        "every encrypted chunk decodes to the target"
    );
}

#[test]
fn flash_restore_tar_reflashes_complete_firmware_only() {
    let tar = coherent_backup().to_tar_bytes().unwrap();
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    let mut req = bin_req(vec![], true);
    req.input = tar;
    req.input_format = &LEGACY_TAR;
    req.drive_model = "BD-RE BU40N".into();
    flash(&mut dev, &Mtk, &req).unwrap();

    let streamed: Vec<u8> = dev
        .writes
        .iter()
        .filter(|(cdb, _)| is_stream_write(cdb))
        .flat_map(|(_, bytes)| bytes.clone())
        .collect();
    // A 0.10.x archive restores as its OEM-format rebuild, never the raw capture.
    let expected =
        mediatek_optical::oem::rebuild(&backup_firmware(), crate::backends::mtk::oem::catalog())
            .unwrap()
            .image;
    assert_eq!(streamed, expected);
    assert!(!dev.writes.iter().any(|(cdb, data)| cdb.get(3..6)
        == Some(&offset_bytes(ROM_1EC000_OFFSET)[..])
        && data.len() == ROM_1EC000_LEN as usize));
}

/// A fixed-format REQUEST SENSE reply carrying `key`, as the 16-byte
/// allocation the OEM sequence uses returns it.
fn fixed_sense(key: u8) -> Vec<u8> {
    let mut s = vec![0u8; 16];
    s[0] = 0x70; // fixed-format response code
    s[2] = key & 0x0F; // sense key
    s[7] = 10; // additional sense length
    s
}

#[test]
fn flash_close_tolerates_benign_unit_attention() {
    // The near-certain state after a microcode program is UNIT ATTENTION (0x6);
    // a successful, already-burned flash must NOT be reported as a failure.
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on(|cdb| cdb.first() == Some(&0x03), fixed_sense(0x06));
    let req = bin_req(
        make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N"),
        true,
    );
    flash(&mut dev, &Mtk, &req).expect("benign UNIT ATTENTION must not fail the flash");
}

#[test]
fn flash_close_tolerates_benign_not_ready() {
    // NOT READY (0x2) is a benign mid-transition state after a program; it must
    // not fail the flash either.
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on(|cdb| cdb.first() == Some(&0x03), fixed_sense(0x02));
    let req = bin_req(
        make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N"),
        true,
    );
    flash(&mut dev, &Mtk, &req).expect("benign NOT READY must not fail the flash");
}

#[test]
fn flash_execute_refuses_when_disc_loaded() {
    // A disc in the tray must hard-abort a --execute flash BEFORE any write —
    // reprogramming while the drive services a medium can wedge the controller.
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .with_medium_loaded();
    let req = bin_req(
        make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N"),
        true,
    );
    let err = flash(&mut dev, &Mtk, &req).expect_err("disc-loaded flash must be refused");
    assert!(
        format!("{err:#}").contains("refusing to flash"),
        "unexpected error: {err}"
    );
    assert!(
        dev.writes.is_empty(),
        "no WRITE BUFFER may be issued when a disc is loaded"
    );
}

#[test]
fn flash_dryrun_warns_but_proceeds_when_disc_loaded() {
    // A dry run only WARNS on a loaded disc (no writes happen anyway), so the
    // operator still sees the full plan before committing.
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .with_medium_loaded();
    let req = bin_req(
        make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N"),
        false,
    );
    flash(&mut dev, &Mtk, &req).expect("dry run must not fail on a loaded disc");
    assert!(dev.writes.is_empty(), "dry run issues no writes");
}

#[test]
fn flash_execute_refuses_when_tray_open() {
    // An OPEN tray is not a settled flash state — refuse a --execute flash with a
    // distinct "close the tray" message, before any write.
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .with_tray_open();
    let req = bin_req(
        make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N"),
        true,
    );
    let err = flash(&mut dev, &Mtk, &req).expect_err("tray-open flash must be refused");
    assert!(
        format!("{err:#}").contains("tray is OPEN"),
        "unexpected error: {err}"
    );
    assert!(
        dev.writes.is_empty(),
        "no WRITE BUFFER may be issued with the tray open"
    );
}

#[test]
fn flash_execute_proceeds_when_closed_empty() {
    // The default mock is a closed, empty tray (the only flash-safe state): the
    // medium guard must NOT block it, and the flash streams to completion.
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    let req = bin_req(
        make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N"),
        true,
    );
    flash(&mut dev, &Mtk, &req).expect("closed-empty tray must flash");
    assert!(
        !dev.writes.is_empty(),
        "a closed-empty flash must issue WRITE BUFFERs"
    );
}

#[test]
fn flash_close_fails_on_hardware_error_sense() {
    // A genuine HARDWARE ERROR (0x4) after the burn IS a real failure.
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on(|cdb| cdb.first() == Some(&0x03), fixed_sense(0x04));
    let req = bin_req(
        make_flashable(patterned_image(IMAGE_SIZE), "BD-RE BU40N"),
        true,
    );
    let err = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(
        matches!(err.downcast_ref::<mediatek_optical::update::FlashError<anyhow::Error>>(), Some(mediatek_optical::update::FlashError::Fault { sense, .. }) if sense.0 == 4),
        "unexpected error: {err}"
    );
}

#[test]
fn flash_restore_tar_detects_readback_mismatch() {
    let tar = coherent_backup().to_tar_bytes().unwrap();
    let want = offset_bytes((CHUNK * 5) as u32);
    let mut dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on_after_stream(
            move |cdb| is_mode6_read(cdb) && cdb.get(3..6) == Some(&want[..]),
            vec![0xFFu8; CHUNK],
        );
    let mut req = bin_req(vec![], true);
    req.input = tar;
    req.input_format = &LEGACY_TAR;
    req.drive_model = "BD-RE BU40N".into();
    let err = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(
        matches!(err.downcast_ref::<mediatek_optical::update::FlashError<anyhow::Error>>(), Some(mediatek_optical::update::FlashError::Mismatch { differing, .. }) if *differing > 0),
        "unexpected error: {err}"
    );
}

// ---- write-path integrity + model gates (never write a bad image) ----------

#[test]
fn model_gate_accepts_a_matching_image() {
    let img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    assert!(ensure_image_matches_drive(&img, "BU40N").is_ok());
}

#[test]
fn model_gate_refuses_a_wrong_model_image() {
    // A valid MT19xx image built for a DIFFERENT model than the drive reports.
    let img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE WH16NS60");
    let err = ensure_image_matches_drive(&img, "BU40N").unwrap_err();
    assert!(format!("{err:#}").contains("wrong-model"), "got: {err}");
}

#[test]
fn model_gate_refuses_a_non_mt19xx_image() {
    // No MTEKMT19 family tag at the descriptor → not a recognizable image.
    assert!(ensure_image_matches_drive(&vec![0u8; IMAGE_SIZE], "BU40N").is_err());
}

#[test]
fn model_gate_refuses_an_unknown_drive_product() {
    let img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    assert!(ensure_image_matches_drive(&img, "   ").is_err());
}

#[test]
fn model_gate_refuses_a_truncated_image() {
    assert!(ensure_image_matches_drive(&[0u8; 0x1000], "BU40N").is_err());
}

// ---- model gate ------------------------------------------------------------

#[test]
fn model_mismatch_is_refused() {
    let err = decide_model("BD-RE BU40N", "WH16NS60").unwrap_err();
    assert!(format!("{err:#}").contains("wrong-model"), "got: {err}");
    assert!(
        format!("{err:#}").contains("compatible image"),
        "got: {err}"
    );
    assert!(decide_model("BD-RE BU40N", "BU40N").is_ok());
}

/// The chip gate as the plan runs it: every pre-backup gate against `dev`.
fn ensure_same_chip(dev: &mut MockScsiDevice, image: &[u8]) -> Result<()> {
    Mtk.validate_image(&mut ReadDevice::without_unlocks(dev), image, "BD-RE BU40N")
        .map(drop)
}

#[test]
fn different_family_flash_is_refused_without_writes() {
    // A different-model image of another hardware family is refused with no
    // writes. (A same-family image of another model is a crossflash.)
    let image = make_flashable_other_family("BD-RE WH16NS60");
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    assert!(flash(&mut dev, &Mtk, &bin_req(image, true)).is_err());
    assert!(dev.writes.is_empty());
}

#[test]
fn flash_execute_refuses_an_unsigned_image_with_no_write() {
    // The brick guard: a model-matching image whose CMAC does NOT verify (empty
    // integrity table) must be refused before any firmware byte is streamed.
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let mut img = vec![0u8; IMAGE_SIZE];
    stamp_descriptor(&mut img, "BD-RE BU40N");
    let err = flash(&mut dev, &Mtk, &bin_req(img, true)).unwrap_err();
    assert!(format!("{err:#}").contains("AES-CMAC"), "got: {err}");
    assert!(
        !dev.writes.iter().any(|(cdb, _)| is_stream_write(cdb)),
        "no firmware bytes may be streamed for an unsigned image"
    );
}

#[test]
fn flash_aborts_on_a_failed_backup_without_rescue_flag() {
    // A failed pre-flash per-unit backup must abort the flash. A signed,
    // model-matching input ensures this test reaches the backup gate.
    let mut dev = MockScsiDevice::new()
        .with_firmware_image(backup_firmware())
        .on_fail(
            |cdb: &[u8]| is_mode6_read(cdb) && !is_identity_read(cdb) && !is_receiver_read(cdb),
            "dump read refused",
        );
    let req = bin_req(make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N"), true);
    let err = flash(&mut dev, &Mtk, &req).unwrap_err();
    // Every flash read fails, including the boot banner. The operation retains
    // typed pre-write backup failure evidence without exposing internal causes.
    let failure = err
        .downcast_ref::<crate::backend::UpdateFailure>()
        .expect("failed backup retains update failure evidence");
    assert_eq!(failure.phase, "backup");
    assert!(!failure.write_started);
    assert!(
        !dev.writes.iter().any(|(cdb, _)| is_stream_write(cdb)),
        "no firmware bytes may be streamed after a failed backup"
    );
}

#[test]
fn dump_refuses_unreadable_firmware_without_creating_archive() {
    let gap = offset_bytes(0x100000);
    let mut dev = MockScsiDevice::new()
        .with_firmware_image(backup_firmware())
        .on_fail(
            move |cdb| is_mode6_read(cdb) && cdb.get(3..6) == Some(&gap[..]),
            "unreadable main",
        );
    let out = fresh_backup_path();
    let err = backup(&mut dev, &Mtk, &out, false).unwrap_err();
    assert!(format!("{err:#}").contains("backup needs every firmware byte"));
    assert!(!out.exists());
    assert!(dev.writes.is_empty());
}

#[test]
fn execute_refuses_unsaved_or_existing_backup_before_write() {
    let mut req = bin_req(backup_firmware(), true);
    req.predump_out = None;
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    let error = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(crate::workflow::error_message(&error)
        .contains("Choose a destination for the pre-flash backup"));
    let evidence = error
        .downcast_ref::<crate::backend::UpdateFailure>()
        .unwrap();
    assert_eq!(evidence.phase, "backup destination");
    assert!(!evidence.write_started);
    assert!(dev.writes.is_empty());

    let out = fresh_backup_path();
    std::fs::write(&out, b"existing backup").unwrap();
    req.predump_out = Some(out.clone());
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    let error = flash(&mut dev, &Mtk, &req).unwrap_err();
    let issue = crate::workflow::user_error(&error);
    assert_eq!(issue.id, "errors.file_exists");
    assert_eq!(issue.consequence, Some("errors.update_blocked"));
    assert!(format!("{error:#}").contains("existing backups are never overwritten"));
    assert!(
        dev.reads.is_empty(),
        "refuse before slow capture or planning"
    );
    assert!(dev.writes.is_empty());
    assert_eq!(std::fs::read(&out).unwrap(), b"existing backup");
    let mut dev = MockScsiDevice::new();
    let error = crate::user_error::read_only(backup(&mut dev, &Mtk, &out, false)).unwrap_err();
    let issue = crate::workflow::user_error(&error);
    assert_eq!(issue.id, "errors.file_exists");
    assert_eq!(issue.consequence, Some("errors.no_firmware_write"));
    assert!(dev.reads.is_empty());
    assert!(dev.writes.is_empty());
    assert_eq!(std::fs::read(&out).unwrap(), b"existing backup");
    std::fs::remove_file(out).unwrap();
}

#[test]
fn restore_refuses_partial_or_corrupt_archive_without_write() {
    let complete = coherent_backup();
    let mut tar = complete.to_tar_bytes().unwrap();
    let needle = b"rom_1F0000.bin";
    let pos = tar.windows(needle.len()).position(|w| w == needle).unwrap();
    let body = pos + 512;
    tar[body] ^= 0x01;
    let mut req = bin_req(tar, true);
    req.input_format = &LEGACY_TAR;
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    assert!(format!("{:#}", flash(&mut dev, &Mtk, &req).unwrap_err())
        .contains("per-unit regions do not match"));
    assert!(dev.writes.is_empty());

    req.input = sample_user_dump().to_tar_bytes().unwrap();
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    assert!(
        format!("{:#}", flash(&mut dev, &Mtk, &req).unwrap_err()).contains("missing backup.toml")
    );
    assert!(dev.writes.is_empty());
}

#[test]
fn restore_refuses_other_drive_backup_without_write() {
    let tar = coherent_backup().to_tar_bytes().unwrap();
    let mut req = bin_req(tar, true);
    req.input_format = &LEGACY_TAR;
    req.drive_model = "WH16NS60".into();
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    assert!(
        crate::workflow::error_message(&flash(&mut dev, &Mtk, &req).unwrap_err())
            .contains("does not match the target drive")
    );
    assert!(dev.writes.is_empty());
}

#[test]
fn backup_refuses_image_per_unit_disagreement_without_write() {
    let mut artifact = coherent_backup();
    artifact.per_unit.rom_1f0000[0] ^= 1;
    let tar = artifact.to_tar_bytes().unwrap();
    let mut req = bin_req(tar, true);
    req.input_format = &LEGACY_TAR;
    req.drive_model = "BD-RE BU40N".into();
    let mut dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    assert!(format!("{:#}", flash(&mut dev, &Mtk, &req).unwrap_err())
        .contains("disagree with firmware image"));
    assert!(dev.writes.is_empty());
}

#[test]
fn flash_execute_refuses_a_different_family_image_with_no_write() {
    // A correctly-signed image of a DIFFERENT hardware family must never reach
    // the write. (A same-family image of another model is a crossflash.)
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let img = make_flashable_other_family("BD-RE WH16NS60");
    let err = flash(&mut dev, &Mtk, &bin_req(img, true)).unwrap_err();
    assert!(
        format!("{err:#}").contains("different hardware family"),
        "got: {err}"
    );
    assert!(
        !dev.writes.iter().any(|(cdb, _)| is_stream_write(cdb)),
        "no firmware bytes may be streamed for a different-family image"
    );
}

// ---- info on a FILE (classify_file) ----

#[test]
fn classify_file_reports_a_valid_mt1959_image() {
    // A correctly-signed BU40N image classifies as MT1959 / BD-UHD / executable
    // / CMAC-valid — the `info <file>` happy path, no drive involved.
    let img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    let fc = classify_file(&img);
    let chip = fc.chip.expect("recognized MT1959");
    assert_eq!(chip.family, freemkv_chipset::ChipFamily::Mt1959);
    assert!(chip.model.to_ascii_uppercase().contains("BU40N"));
    let cap = fc.capability.expect("capability");
    assert!(cap.bd_aacs);
    assert!(cap.media_class >= freemkv_chipset::MediaClass::Bd);
    let (_, status) = fc.flash.expect("MediaTek flash recipe");
    assert!(status.is_executable());
    assert!(
        matches!(fc.cmac, CmacSummary::Valid { .. }),
        "a signed image must report valid integrity"
    );
}

#[test]
fn classify_file_flags_a_corrupt_signed_image() {
    // Flip a byte inside a signed range → integrity must report Invalid.
    let mut img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    img[0x12000] ^= 0xFF;
    assert!(matches!(
        classify_file(&img).cmac,
        CmacSummary::Invalid { .. }
    ));
}

#[test]
fn classify_file_rejects_unrecognizable_bytes() {
    // Too small / no MTEKMT19xx tag → not a recognizable image (never panics),
    // and no capability/flash is inferred for an unrecognized image.
    assert!(classify_file(&[0u8; 100]).chip.is_none());
    assert!(classify_file(&vec![0xAAu8; IMAGE_SIZE]).chip.is_none());
    let fc = classify_file(&[0u8; 100]);
    assert!(fc.capability.is_none() && fc.flash.is_none());
    assert!(matches!(fc.cmac, CmacSummary::Unsigned));
}

#[test]
fn existing_preflash_destination_fails_before_capturing_the_drive() {
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let req = bin_req(backup_firmware(), true);
    let path = req.predump_out.as_ref().unwrap();
    std::fs::write(path, b"keep this rollback").unwrap();
    let result = flash(&mut dev, &Mtk, &req);
    assert_eq!(std::fs::read(path).unwrap(), b"keep this rollback");
    std::fs::remove_file(path).unwrap();
    assert!(result.is_err());
    // Only the chip-gate identity reads (banner + descriptor) precede the
    // collision check; never the multi-minute firmware read.
    assert!(
        dev.reads
            .iter()
            .all(|c| is_identity_read(c) || is_receiver_read(c) || c.first() == Some(&0x12)),
        "do not spend minutes reading before finding a path collision"
    );
    // Two identity windows, each read at most twice (one retry).
    assert!(dev.reads.iter().filter(|c| is_identity_read(c)).count() <= 4);
    assert!(dev.writes.is_empty());
}

#[test]
fn encrypted_upload_still_detects_corrupt_plaintext_readback() {
    let mut firmware = backup_firmware();
    crate::backends::mtk::bulk_receiver_fixture::stamp(&mut firmware);
    let want = offset_bytes(0x10000);
    let mut dev = MockScsiDevice::new()
        .with_firmware_image(firmware.clone())
        .on_after_stream(
            move |cdb| is_mode6_read(cdb) && cdb.get(3..6) == Some(&want[..]),
            vec![0xff; CHUNK],
        );
    let req = bin_req(firmware, true);
    let error = flash(&mut dev, &Mtk, &req)
        .expect_err("encrypted transport must not disable integrity verification");
    let _ = std::fs::remove_file(req.predump_out.unwrap());
    assert!(
        matches!(error.downcast_ref::<mediatek_optical::update::FlashError<anyhow::Error>>(), Some(mediatek_optical::update::FlashError::Mismatch { differing, .. }) if *differing > 0),
        "{error:#}"
    );
}

#[test]
fn flash_requires_successful_backup() {
    let req = bin_req(backup_firmware(), true);
    let mut dev = MockScsiDevice::new();
    assert!(capture_required_backup(
        &mut dev,
        &Mtk,
        &Mtk,
        &FlashPlan::new(()),
        &req,
        &mut crate::workflow::Preconfirmed
    )
    .is_err());
    assert!(!dev.reads.is_empty());
    assert!(dev.writes.is_empty());
}

#[test]
fn mediatek_dump_preserves_raw_unsigned_memory_without_requiring_backup_integrity() {
    let raw = vec![0x5a; IMAGE_SIZE];
    let mut dev = MockScsiDevice::new().with_firmware_image(raw.clone());
    let dump = DumpFacet::capture(
        &Mtk,
        DeviceAccess::Read(&mut ReadDevice::without_unlocks(&mut dev)),
    );
    assert_eq!(dump.unwrap(), raw);
    assert!(dev.writes.is_empty());
    assert!(BackupFacet::capture(&Mtk, &mut ReadDevice::without_unlocks(&mut dev)).is_err());
}

fn descriptor(feature: u16, payload_len: u8) -> Vec<u8> {
    let mut data = vec![0u8; 12 + usize::from(payload_len)];
    let length = (data.len() - 4) as u32;
    data[..4].copy_from_slice(&length.to_be_bytes());
    data[8..10].copy_from_slice(&feature.to_be_bytes());
    data[11] = payload_len;
    data[12..].fill(b'S');
    data
}

#[test]
fn guard_no_medium_refuses_disc_and_open_tray_on_execute() {
    let mut loaded = MockScsiDevice::new().with_medium_loaded();
    assert!(guard_no_medium(&mut loaded, true).is_err());
    let mut open = MockScsiDevice::new().with_tray_open();
    assert!(guard_no_medium(&mut open, true).is_err());
    // A dry run only warns.
    let mut loaded = MockScsiDevice::new().with_medium_loaded();
    assert!(guard_no_medium(&mut loaded, false).is_ok());
}

#[test]
fn guard_no_medium_allows_closed_empty() {
    let mut dev = MockScsiDevice::new();
    assert!(guard_no_medium(&mut dev, true).is_ok());
}

#[test]
fn capture_is_saved_before_target_dependent_rollback_check() {
    use crate::backend::{
        AuthorizedPlan, BackupFormat, BackupNotice, FlashFacet, Identity, Match, ReadDevice,
        WriteDevice,
    };
    struct RejectUpdate {
        path: std::path::PathBuf,
    }
    impl Backend for RejectUpdate {
        fn descriptor(&self) -> &'static crate::backend::Descriptor {
            &crate::backends::mtk::DESCRIPTOR
        }
        fn probe(&self, _: &mut ReadDevice<'_>, _: &Identity) -> Result<Option<Match>> {
            unreachable!()
        }
        fn backup(&self) -> Option<&dyn BackupFacet> {
            Some(self)
        }
        fn flash(&self) -> Option<&dyn FlashFacet> {
            Some(self)
        }
    }
    impl BackupFacet for RejectUpdate {
        fn format(&self) -> BackupFormat {
            Mtk.format()
        }
        fn capture(&self, _: &mut ReadDevice<'_>) -> Result<Vec<u8>> {
            Ok(backup_firmware())
        }
        fn notice(&self, _: &[u8]) -> BackupNotice {
            BackupNotice::None
        }
        fn validate(&self, bytes: &[u8], model: &str) -> Result<Vec<u8>> {
            BackupFacet::validate(&Mtk, bytes, model)
        }
    }
    impl FlashFacet for RejectUpdate {
        fn plan(&self, _: &mut ReadDevice<'_>, _: &FlashRequest) -> Result<FlashPlan> {
            Ok(FlashPlan::new(()))
        }
        fn verify_backup(&self, _: &FlashPlan, bytes: &[u8]) -> Result<()> {
            assert_eq!(
                std::fs::read(&self.path).expect("capture must already be saved"),
                bytes
            );
            bail!("target requires an uncaptured region")
        }
        fn authorize(
            &self,
            _: &mut ReadDevice<'_>,
            _: FlashPlan,
            _: Option<&SavedBackup>,
        ) -> Result<AuthorizedPlan> {
            panic!("authorize after a refused coverage check")
        }
        fn execute(
            &self,
            _: &mut WriteDevice<'_>,
            _: &AuthorizedPlan,
        ) -> Result<crate::backend::UpdateOutcome> {
            panic!("update prohibited")
        }
    }
    let req = bin_req(vec![], true);
    let path = req.predump_out.clone().unwrap();
    let backend = RejectUpdate { path: path.clone() };
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let plan = FlashPlan::new(());
    let Err(error) = capture_required_backup(
        &mut dev,
        &backend,
        &backend,
        &plan,
        &req,
        &mut crate::workflow::Preconfirmed,
    ) else {
        panic!("an incomplete rollback was accepted");
    };
    let message = format!("{error:#}");
    assert!(message.contains("backup saved to"), "{message}");
    assert!(
        message.contains("target requires an uncaptured region"),
        "{message}"
    );
    assert!(path.exists());
    assert!(dev.writes.is_empty());
    std::fs::remove_file(path).unwrap();
}

#[test]
fn chip_gate_refuses_cross_generation_images() {
    // Drive: MT1959 (BU40N). Image: an MT1939 build with a matching model.
    let mut img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    let d = ROM_1EC000_OFFSET as usize;
    img[d + 0x34..d + 0x3E].copy_from_slice(b"MTEKMT1939");
    crate::backends::mtk::fixture::stamp(&mut img, &crate::backends::mtk::fixture::JB7);
    let img = crate::cmac::resign(&img).unwrap();
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let gate = ensure_same_chip(&mut dev, &img).unwrap_err();
    assert!(
        format!("{gate:#}").contains("cannot be overridden"),
        "{gate:#}"
    );
    assert_eq!(
        crate::workflow::user_error(&gate).id,
        "errors.incompatible_firmware"
    );
    let normal = Mtk
        .validate_image(
            &mut ReadDevice::without_unlocks(&mut dev),
            &img,
            "BD-RE BU40N",
        )
        .unwrap_err();
    assert!(format!("{normal:#}").contains("MT1939"), "{normal:#}");
    assert!(dev.writes.is_empty());
}

#[test]
fn raw_drive_reads_are_never_flashable() {
    // A drive read's boot page is the read-back mirror of 0x10000; writing it
    // would store the wrong boot page.
    let mut read = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    let mirror = read[0x1_0000..0x1_0400].to_vec();
    read[..0x400].copy_from_slice(&mirror);
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let normal = Mtk
        .validate_image(
            &mut ReadDevice::without_unlocks(&mut dev),
            &read,
            "BD-RE BU40N",
        )
        .unwrap_err();
    assert!(normal.to_string().contains("raw drive read"), "{normal}");
}

#[test]
fn unknown_boot_pages_are_refused() {
    let mut img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    img[..0x400].fill(0x42);
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let err = Mtk
        .validate_image(
            &mut ReadDevice::without_unlocks(&mut dev),
            &img,
            "BD-RE BU40N",
        )
        .unwrap_err();
    assert!(format!("{err:#}").contains("boot page"), "{err}");
}

#[test]
fn chip_gate_refuses_when_the_banner_is_unreadable() {
    // The drive's chip generation is decided by its boot banner, so an
    // unreadable banner refuses rather than falling back to the stale tag.
    let img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    let mut dev = MockScsiDevice::new()
        .with_firmware_image(backup_firmware())
        .on_fail(
            |cdb: &[u8]| cdb.get(3..6) == Some(&offset_bytes(0x3000)[..]),
            "banner read refused",
        );
    let err = ensure_same_chip(&mut dev, &img).unwrap_err();
    assert!(format!("{err:#}").contains("boot banner"), "{err}");
}

fn captured_output(op: impl FnOnce()) -> String {
    let log = std::rc::Rc::new(std::cell::RefCell::new(String::new()));
    let sink = log.clone();
    crate::output::capture_events(
        move |event| sink.borrow_mut().push_str(&format!("{event:?}\n")),
        op,
    );
    let out = log.borrow().clone();
    out
}

#[test]
fn info_file_prefers_a_pioneer_bundle_over_an_embedded_mtek_tag() {
    let mut normal = vec![0u8; 0x1d7000];
    let head = b"********  Copyright(c) 2000 Pioneer Corporation  ********\r\nID : PIONEER BD-RW   BDR-UD04.\r\nRevision Level : 1.11 .\r\nHardware Version : SAT 8A10.\r\nDestination : GENERAL.\r\nFile Type : Normal.\r\n";
    normal[..head.len()].copy_from_slice(head);
    normal[0x1000..0x100A].copy_from_slice(b"MTEKMT1959");
    let mut tar_bytes = Vec::new();
    {
        let mut tar = tar::Builder::new(&mut tar_bytes);
        let path = "components/normal.enc";
        let mut header = tar::Header::new_gnu();
        header.as_mut_bytes()[..path.len()].copy_from_slice(path.as_bytes());
        header.set_size(normal.len() as u64);
        header.set_mode(0o644);
        header.set_cksum();
        tar.append(&header, &normal[..]).unwrap();
        tar.finish().unwrap();
    }
    let path = fresh_backup_path();
    std::fs::write(&path, &tar_bytes).unwrap();
    let mut result = None;
    let out = captured_output(|| result = Some(info_file(&path)));
    let _ = std::fs::remove_file(&path);
    result.unwrap().unwrap();
    assert!(out.contains("Pioneer"), "Pioneer report missing: {out}");
    assert!(
        !out.to_lowercase().contains("chipset"),
        "reported as MediaTek: {out}"
    );
}

#[test]
fn describe_never_prints_escape_sequences_from_the_image() {
    let img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    let mut hostile = img.clone();
    let d = ROM_1EC000_OFFSET as usize;
    hostile[d + 0x08..d + 0x08 + 4].copy_from_slice(b"\x1b[2J");
    let hostile = crate::cmac::resign(&hostile).unwrap();
    let out = captured_output(|| {
        FileFacet::describe(
            &Mtk,
            &hostile,
            &FileFacet::recognize(&Mtk, &hostile).unwrap(),
        )
        .expect("recognized")
        .unwrap();
    });
    assert!(out.contains("Chipset"), "not described: {out}");
    assert!(!out.contains('\x1b') && !out.contains("\\u{1b}"), "{out:?}");
}

#[test]
fn legacy_backup_member_names_are_sanitized_in_errors() {
    let mut out = Vec::new();
    {
        let mut tar = tar::Builder::new(&mut out);
        let path = "bad\u{1b}[2J.bin";
        let mut header = tar::Header::new_gnu();
        header.as_mut_bytes()[..path.len()].copy_from_slice(path.as_bytes());
        header.set_size(1);
        header.set_mode(0o644);
        header.set_cksum();
        tar.append(&header, &[0u8][..]).unwrap();
        tar.finish().unwrap();
    }
    let err = crate::backends::mtk::backup::BackupArtifact::from_tar_bytes(&out, IMAGE_SIZE)
        .err()
        .expect("must fail");
    let text = format!("{err:#}");
    assert!(text.contains("unexpected"), "{text}");
    assert!(!text.contains('\x1b'), "{text:?}");
}

#[test]
fn classify_file_flags_an_integrity_entry_running_past_the_image() {
    let img = with_active_cmac_range(vec![0u8; IMAGE_SIZE], 0x11000, IMAGE_SIZE as u32 + 5);
    assert!(
        matches!(classify_file(&img).cmac, CmacSummary::Invalid { .. }),
        "a present-but-corrupt table must not read as unsigned"
    );
}

#[test]
fn chip_gate_always_reads_the_banner() {
    // The banner is the authoritative chip signal, so it is always read — never
    // skipped for a "tagged" drive (the tag is a stale vendor label).
    let img = make_flashable(vec![0u8; IMAGE_SIZE], "BD-RE BU40N");
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    Mtk.validate_image(
        &mut ReadDevice::without_unlocks(&mut dev),
        &img,
        "BD-RE BU40N",
    )
    .unwrap();
    let banner = offset_bytes(0x3000);
    let banner_reads = dev
        .reads
        .iter()
        .filter(|cdb| is_mode6_read(cdb) && cdb.get(3..6) == Some(&banner[..]))
        .count();
    assert!(
        banner_reads > 0,
        "the banner must be read to decide the chip"
    );
}

/// A flashable image whose descriptor carries `tag` (or none) and whose boot
/// banner at 0x3000 reads `banner`: real ASUS BW-16D1HT parts are MT1939
/// silicon (tag) with an `MT1959 Boot` banner.
fn chip_image(model: &str, tag: Option<&[u8; 10]>, banner: &[u8]) -> Vec<u8> {
    use crate::backends::mtk::fixture;
    let mut img = make_flashable(vec![0u8; IMAGE_SIZE], model);
    let d = ROM_1EC000_OFFSET as usize;
    img[d + 0x34..d + 0x3E].fill(0);
    // The hardware record repeats the tag: an untagged image has none.
    img[fixture::RECORD_AREA..fixture::RECORD_AREA + 0x100].fill(0);
    if let Some(tag) = tag {
        img[d + 0x34..d + 0x3E].copy_from_slice(tag);
        let board = if tag == b"MTEKMT1939" {
            fixture::JB8
        } else {
            fixture::BU3
        };
        fixture::stamp(&mut img, &board);
    }
    img[0x3000..0x3020].fill(0);
    img[0x3000..0x3000 + banner.len()].copy_from_slice(banner);
    crate::cmac::resign(&img).unwrap()
}

fn mt1939_drive() -> MockScsiDevice {
    MockScsiDevice::new().with_firmware_image(chip_image(
        "BD-RE BU40N",
        Some(b"MTEKMT1939"),
        b"MT1959 Boot JB8",
    ))
}

#[test]
fn chip_gate_follows_the_banner_not_the_tag() {
    // A JB8 image/drive carries the stale tag MTEKMT1939 but an "MT1959 Boot"
    // banner, so both are MT1959 and the gate passes — the tag never decides.
    let jb8 = chip_image("BD-RE BU40N", Some(b"MTEKMT1939"), b"MT1959 Boot JB8");
    let mut dev = mt1939_drive();
    Mtk.validate_image(
        &mut ReadDevice::without_unlocks(&mut dev),
        &jb8,
        "BD-RE BU40N",
    )
    .unwrap();
    ensure_same_chip(&mut dev, &jb8).unwrap();

    // A genuine classic MT1939 image ("MT1939 Boot Code") on that MT1959 drive
    // is a true cross-generation mismatch, refused with no writes.
    let classic = chip_image("BD-RE BU40N", Some(b"MTEKMT1939"), b"MT1939 Boot Code");
    let normal = Mtk
        .validate_image(
            &mut ReadDevice::without_unlocks(&mut dev),
            &classic,
            "BD-RE BU40N",
        )
        .unwrap_err();
    assert!(format!("{normal:#}").contains("MT1959"), "{normal:#}");
    assert!(format!("{normal:#}").contains("MT1939"), "{normal:#}");
    let gate = ensure_same_chip(&mut dev, &classic).unwrap_err();
    assert!(format!("{gate:#}").contains("MT1939"), "{gate:#}");
    assert!(dev.writes.is_empty());
}

#[test]
fn chip_gate_identifies_from_the_banner_with_or_without_a_tag() {
    // An untagged image is identified by its banner alone (MT1939 here), but has
    // no hardware record, so the family gate refuses it — the chip gate passes.
    let untagged = chip_image("BD-RE BU40N", None, b"MT1939 Boot Code");
    let mut banner_only = MockScsiDevice::new().with_firmware_image(chip_image(
        "BD-RE BU40N",
        None,
        b"MT1939 Boot Code",
    ));
    let err = ensure_same_chip(&mut banner_only, &untagged).unwrap_err();
    assert!(
        format!("{err:#}").contains("target firmware family"),
        "{err}"
    );

    // A tag cannot stand in for the banner: an image with a tag but no banner
    // names no chip and is refused as unrecognizable.
    let tag_no_banner = chip_image("BD-RE BU40N", Some(b"MTEKMT1939"), b"");
    let err = ensure_same_chip(&mut banner_only, &tag_no_banner).unwrap_err();
    assert!(format!("{err:#}").contains("MT19"), "{err:#}");
    assert!(banner_only.writes.is_empty());
}

fn is_receiver_read(cdb: &[u8]) -> bool {
    if !is_mode6_read(cdb) || cdb.len() < 9 {
        return false;
    }
    let off = ((cdb[3] as u32) << 16) | ((cdb[4] as u32) << 8) | cdb[5] as u32;
    ((0x98000..0xb4000).contains(&off) && read_len(cdb).is_some_and(|n| n <= 1088))
        || ((0x140000..0x1b0000).contains(&off) && read_len(cdb).is_some_and(|n| n <= 1024))
}

#[test]
fn unknown_receiver_refuses_before_backup_or_write() {
    let mut installed = backup_firmware();
    installed[0x9a300..0x9a340].fill(0);
    let mut dev = MockScsiDevice::new().with_firmware_image(installed);
    let req = bin_req(backup_firmware(), true);
    let error = flash(&mut dev, &Mtk, &req).unwrap_err();
    let evidence = error
        .downcast_ref::<crate::backend::UpdateFailure>()
        .unwrap();
    assert_eq!(evidence.phase, "package and receiver checks");
    assert!(!evidence.write_started);
    assert!(!evidence.temporary_firmware);
    assert!(
        format!("{error:#}").contains("receiver signature"),
        "{error:#}"
    );
    assert!(dev.writes.is_empty());
    assert!(!req.predump_out.unwrap().exists());
}

#[test]
fn mediatek_preview_keeps_installed_backup_checks_pending_without_writes() {
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let req = bin_req(backup_firmware(), false);
    let preview = super::preview_flash_details(&mut dev, &Mtk, &req).unwrap();
    assert!(preview.compatibility_pending);
    assert!(dev.writes.is_empty());
    assert!(req.predump_out.is_none());
}

#[test]
fn encoding_override_cannot_contradict_live_receiver() {
    let mut dev = MockScsiDevice::new().with_firmware_image(backup_firmware());
    let mut req = bin_req(backup_firmware(), true);
    req.enc_override = Some(true);
    let error = flash(&mut dev, &Mtk, &req).unwrap_err();
    assert!(format!("{error:#}").contains("contradicts"), "{error:#}");
    assert!(dev.writes.is_empty());
    assert!(!req.predump_out.unwrap().exists());
}
