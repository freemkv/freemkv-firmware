//! Tripwires for the two-stage flash (design findings R1, R2 and R5): `plan`
//! needs no backup, `authorize` runs the installed-firmware gates after it,
//! `execute` writes only through a grant that requires the saved backup, and
//! the behaviours the old single-stage flow had are kept.

use super::*;
use crate::backend::{AuthorizedPlan, Confirm, FlashPlan, PlanLine, SavedBackup, WriteDevice};

/// The (installed backup, target package) pair the Pioneer executor goldens
/// use: a plain update, or one that needs the Kernel restoration pass.
fn pioneer_update(restore: bool) -> (Vec<u8>, Vec<u8>) {
    (
        archive(&prepared_pair(restore, 1), false),
        archive(&prepared_pair(false, 0), false),
    )
}

fn pioneer_plan(target: Vec<u8>) -> FlashPlan {
    let req = pioneer_request(target, &PIONEER_PACKAGE, true);
    let mut dev = MockScsiDevice::new();
    Pioneer::new()
        .plan(&mut ReadDevice::without_unlocks(&mut dev), &req)
        .expect("a package plans without its drive")
}

fn authorize(plan: FlashPlan, installed: Vec<u8>) -> Result<AuthorizedPlan> {
    let mut dev = MockScsiDevice::new();
    let saved = crate::engine::gates::saved_for_tests(installed);
    let result = Pioneer::new().authorize(
        &mut ReadDevice::without_unlocks(&mut dev),
        plan,
        Some(&saved),
    );
    assert!(dev.reads.is_empty() && dev.writes.is_empty());
    result
}

/// A front-end that records what it was asked and declines.
#[derive(Default)]
struct Decline(Vec<Option<String>>);

impl Confirm for Decline {
    fn confirm(&mut self, plan: &AuthorizedPlan) -> Result<bool> {
        self.0.push(plan.confirmation.clone());
        Ok(false)
    }
}

fn text_index(outcome: &Outcome, needle: &str) -> usize {
    outcome
        .text
        .iter()
        .position(|l| l.contains(needle))
        .unwrap_or_else(|| panic!("no {needle:?} in {:#?}", outcome.text))
}

#[test]
fn flash_plan_needs_no_backup() {
    // MediaTek: an execute plan with no backup destination reads only the chip
    // identity and receiver code, without capturing a full backup.
    let image = make_flashable(vec![0x11u8; IMAGE_SIZE], "BD-RE BU40N");
    let req = mtk_request(image.clone(), true, None);
    let mut dev = Rec::new(mtk_drive());
    let plan = Mtk
        .plan(&mut ReadDevice::without_unlocks(&mut dev), &req)
        .expect("plan without a backup");
    assert!(plan.after_backup.contains(&PlanLine::Backup));
    assert_eq!(
        dev.transcript()
            .into_iter()
            .filter(|l| !receiver_probe_line(l))
            .collect::<Vec<_>>(),
        [
            "IN   cdb=3c06001ec00000010000 alloc=256 -> ok 256",
            "IN   cdb=3c060000300000002000 alloc=32 -> ok 32",
            // The optical receiver profile independently binds its chip from the boot banner.
            "IN   cdb=3c060000300000002000 alloc=32 -> ok 32",
        ]
    );

    // Pioneer: planned from the package alone, against a drive that is not a
    // Pioneer, with nothing installed known.
    let (_, target) = pioneer_update(false);
    let req = pioneer_request(target, &PIONEER_PACKAGE, true);
    let mut dev = Rec::new(MockScsiDevice::new());
    Pioneer::new()
        .plan(&mut ReadDevice::without_unlocks(&mut dev), &req)
        .expect("plan without a backup");
    assert!(dev.transcript().is_empty());

    // The engine's first stage alone: the tray, then the plan; nothing saved.
    let (outcome, transcript) = drive_run(mtk_drive(), |d| {
        crate::engine::plan_flash(d, &Mtk, &mtk_request(image, true, None)).map(drop)
    });
    assert_eq!(outcome.result, "OK");
    assert_eq!(
        transcript
            .into_iter()
            .filter(|l| !receiver_probe_line(l))
            .collect::<Vec<_>>(),
        [
            "MEDIUM -> ClosedEmpty",
            "IN   cdb=3c06001ec00000010000 alloc=256 -> ok 256",
            "IN   cdb=3c060000300000002000 alloc=32 -> ok 32",
            // The optical receiver profile independently binds its chip from the boot banner.
            "IN   cdb=3c060000300000002000 alloc=32 -> ok 32",
        ]
    );
}

#[test]
fn flash_authorize_runs_pioneer_installed_gates_after_backup() {
    // One plan, made before any backup; what authorize decides depends only
    // on the installed firmware in the saved backup.
    let (plain, target) = pioneer_update(false);
    let (barrier, _) = pioneer_update(true);
    let authorized = authorize(pioneer_plan(target.clone()), plain).expect("plain update");
    assert!(authorized.warnings.is_empty());

    let authorized = authorize(pioneer_plan(target.clone()), barrier).expect("barrier update");
    assert_eq!(
        authorized.warnings.len(),
        1,
        "the generation barrier is a property of the installed Kernel"
    );
    assert!(authorized.warnings[0].contains("generation barrier"));

    // An installed backup without a Kernel cannot establish the receiver.
    let pair = prepared_pair(true, 1);
    let normal_only = tar_of(&[(
        "normal.enc",
        &pair.normal().repack(&pair.normal().image).unwrap(),
    )]);
    let error = authorize(pioneer_plan(target), normal_only).err().unwrap();
    assert!(
        format!("{error:#}").contains("unknown_installed_kernel"),
        "{error:#}"
    );
}

#[test]
fn pioneer_confirmation_text_is_returned_not_prompted() {
    let (installed, target) = pioneer_update(false);
    let plan = pioneer_plan(target);
    let mut authorized = None;
    let outcome = run(|| {
        authorized = Some(authorize(plan, installed)?);
        Ok(())
    });
    assert_eq!(outcome.result, "OK");
    assert!(
        outcome.events.is_empty(),
        "authorize printed or prompted: {:#?}",
        outcome.events
    );
    assert_eq!(
        authorized.unwrap().confirmation.as_deref(),
        Some("This will flash: KERNEL (rev 0000) + NORMAL (rev 1.00)")
    );

    // The engine shows the text and asks the front-end; a decline writes nothing.
    let mut front_end = Decline::default();
    let (outcome, transcript) = drive_run(MockScsiDevice::echoing(), |d| {
        crate::engine::flash(d, &Confirming, &confirming_request(), &mut front_end)
    });
    assert_eq!(outcome.result, "ERR update failed during confirmation (write started: false; temporary firmware: false; completed stages: []): ui.cancelled_no_firmware_was_written: flash aborted at confirmation prompt");
    assert_eq!(front_end.0, [Some(CONFIRM_TEXT.to_string())]);
    assert!(outcome.text.iter().any(|l| l == CONFIRM_TEXT));
    assert!(
        transcript.iter().all(|l| !l.starts_with("OUT")),
        "{transcript:#?}"
    );
}

#[test]
fn flash_never_writes_without_saved_backup() {
    // A failed backup read stops both backends before any data-out.
    let image = make_flashable(vec![0x11u8; IMAGE_SIZE], "BD-RE BU40N");
    let dir = scratch("never-without-backup");
    let unreadable = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on_fail(
            |cdb| cdb.first() == Some(&0x3c) && cdb.get(3..6) == Some(&[0x10, 0, 0][..]),
            "unreadable main",
        );
    let req = mtk_request(image, true, Some(dir.join("mtk.bin")));
    let (outcome, transcript) = drive_run(unreadable, |d| engine_flash(d, &Mtk, &req));
    assert!(
        outcome.result.contains("pre-flash backup failed"),
        "{}",
        outcome.result
    );
    assert!(
        transcript.iter().all(|l| !l.starts_with("OUT")),
        "{transcript:#?}"
    );
    assert!(!dir.join("mtk.bin").exists());

    let (_, target) = pioneer_update(false);
    let mut req = pioneer_request(target, &PIONEER_PACKAGE, true);
    req.predump_out = Some(dir.join("pioneer.tar"));
    let (outcome, transcript) = drive_run(MockScsiDevice::pioneer(), |d| {
        engine_flash(d, &Pioneer::new(), &req)
    });
    assert!(
        outcome.result.contains("errors.backup_required"),
        "{}",
        outcome.result
    );
    assert!(
        transcript.iter().all(|l| !l.starts_with("OUT")),
        "{transcript:#?}"
    );

    // A backend whose backup fails is never handed a write grant.
    let mut dev = MockScsiDevice::echoing();
    let mut req = confirming_request();
    req.predump_out = Some(dir.join("fails.bin"));
    let error =
        crate::engine::flash(&mut dev, &FailingBackup, &req, &mut Decline::default()).unwrap_err();
    assert!(format!("{error:#}").contains("no capture"), "{error:#}");
    assert!(dev.writes.is_empty());
}

#[test]
fn flash_proceeds_without_backup_when_the_operator_consents() {
    // A backend whose backup capture fails: with the operator's consent at the
    // prompt, the flash proceeds with NO backup and still writes — every other
    // gate (plan, authorize, execute grant) having passed. No backup file is
    // written.
    struct Consent;
    impl Confirm for Consent {
        fn confirm(&mut self, _plan: &AuthorizedPlan) -> Result<bool> {
            Ok(true)
        }
        fn proceed_without_backup(&mut self, _reason: &str) -> Result<bool> {
            Ok(true)
        }
    }

    let dir = scratch("proceed-without-backup");
    let mut dev = MockScsiDevice::echoing();
    let mut req = confirming_request();
    req.predump_out = Some(dir.join("fails.bin"));
    crate::engine::flash(&mut dev, &FailingBackup, &req, &mut Consent)
        .expect("consented no-backup flash proceeds");
    assert!(!dev.writes.is_empty(), "the flash must still write");
    assert!(
        !dir.join("fails.bin").exists(),
        "no backup file is written when none could be captured"
    );
}

#[test]
fn post_flash_identity_check_fails_unconfirmed_flash() {
    // The image streams and reads back cleanly, but the rebooted drive's
    // firmware identity cannot be read: the flash is not confirmed.
    let dir = scratch("unconfirmed");
    let image = make_flashable(vec![0x11u8; IMAGE_SIZE], "BD-RE BU40N");
    let dev = MockScsiDevice::echoing()
        .with_firmware_image(backup_firmware())
        .on_fail_after_stream(
            |cdb| cdb.first() == Some(&0x12),
            "drive still re-enumerating",
        );
    let req = mtk_request(image, true, Some(dir.join("rollback.bin")));
    let (outcome, transcript) = drive_run(dev, |d| engine_flash(d, &Mtk, &req));
    assert!(
        outcome.result.contains("target startup was not confirmed"),
        "{}",
        outcome.result
    );
    assert!(
        transcript.iter().any(|l| l.starts_with("OUT")),
        "the image was written"
    );
    assert!(!outcome.text.iter().any(|l| l.contains("flash complete .")));
    assert!(!outcome.text.iter().any(|l| l.starts_with("firmware now")));
}

#[test]
fn backup_candidate_infix_and_sha_line_kept() {
    let identity = crate::backend::Identity {
        product: "BD-RW   BDR-UD04".into(),
        revision: "1.14".into(),
        ..Default::default()
    };
    let pioneer = Pioneer::new().backup().unwrap().format();
    assert_eq!(
        crate::workflow::default_backup_name(&identity, Some(pioneer), false).unwrap(),
        PathBuf::from("BD-RW___BDR-UD04_1.14.candidate.tar")
    );
    let mtk = Mtk.backup().unwrap().format();
    assert_eq!(
        crate::workflow::default_backup_name(&identity, Some(mtk), false).unwrap(),
        PathBuf::from("BD-RW___BDR-UD04_1.14.backup.bin")
    );

    let out = scratch("candidate").join("pioneer.tar");
    let (outcome, _) = drive_run(BackupReplay::new(), |d| {
        crate::engine::backup(d, &Pioneer::new(), &out, false)
    });
    assert_eq!(outcome.result, "OK");
    let sha = format!("{:x}", Sha256::digest(std::fs::read(&out).unwrap()));
    assert!(outcome.text.contains(&format!("candidate sha256: {sha}")));
    assert!(outcome
        .events
        .contains(&format!("FIELD    Saved to = {}", out.display())));
}

#[test]
fn raw_dump_name_and_line_kept() {
    let identity = crate::backend::Identity {
        product: "BD-RW   BDR-UD04".into(),
        revision: "1.14".into(),
        ..Default::default()
    };
    let format = Pioneer::new().backup().unwrap().format();
    assert_eq!(
        crate::workflow::default_backup_name(&identity, Some(format), true).unwrap(),
        PathBuf::from("BD-RW___BDR-UD04_1.14.dump.bin")
    );
    assert_eq!(
        crate::workflow::default_backup_name(&identity, None, true).unwrap(),
        PathBuf::from("BD-RW___BDR-UD04_1.14.dump.bin")
    );

    let out = scratch("raw-dump").join("pioneer.dump.bin");
    let (outcome, _) = drive_run(BackupReplay::new(), |d| {
        crate::engine::backup(d, &Pioneer::new(), &out, true)
    });
    assert_eq!(outcome.result, "OK");
    assert_eq!(
        outcome.text.last().map(String::as_str),
        Some("RAW DUMP: device memory and diagnostic sections; NOT a flashable backup.")
    );
    assert!(outcome
        .events
        .contains(&"FIELD    Artifact = Raw memory dump — not a flashable backup".to_string()));
}

#[test]
fn saved_backup_kept_when_authorize_refuses() {
    // The replayed UD04 backs up completely, then authorize refuses this
    // package against the installed firmware it found.
    let dir = scratch("authorize-refuses");
    let out = dir.join("preflash.tar");
    let (_, target) = pioneer_update(false);
    let mut req = pioneer_request(target, &PIONEER_PACKAGE, true);
    req.predump_out = Some(out.clone());
    let mut front_end = Decline::default();
    let (outcome, transcript) = drive_run(BackupReplay::new(), |d| {
        crate::engine::flash(d, &Pioneer::new(), &req, &mut front_end)
    });
    assert!(outcome.result.starts_with("ERR "), "{}", outcome.result);
    assert!(
        !outcome.result.contains("confirmation"),
        "{}",
        outcome.result
    );
    assert!(
        front_end.0.is_empty(),
        "authorize refused before the confirmation"
    );
    let saved = std::fs::read(&out).expect("the backup is kept");
    BackupFacet::validate(&Pioneer::new(), &saved, "BD-RW   BDR-UD04").unwrap();
    let line = text_index(&outcome, &format!("backup: saved {}", out.display()));
    assert_eq!(
        line,
        outcome.text.len() - 1,
        "the backup line is the last output"
    );
    let knock = "OUT  cdb=3b0241a5aaaa00000000";
    assert!(
        transcript
            .iter()
            .filter(|l| l.starts_with("OUT"))
            .all(|l| l.starts_with(knock)),
        "{transcript:#?}"
    );
}

#[test]
fn dry_run_keeps_tray_warning_and_mtk_preflight() {
    let image = make_flashable(vec![0x11u8; IMAGE_SIZE], "BD-RE BU40N");
    let req = mtk_request(image, false, None);
    let (outcome, transcript) = drive_run(mtk_drive().with_medium_loaded(), |d| {
        engine_flash(d, &Mtk, &req)
    });
    assert_eq!(outcome.result, "OK");
    assert_eq!(
        outcome.text[0],
        "WARNING: a disc is loaded. An actual flash requires a closed, empty tray."
    );
    assert!(text_index(&outcome, "preflight ....") > text_index(&outcome, "== flash plan =="));
    assert!(outcome
        .text
        .last()
        .unwrap()
        .starts_with("DRY RUN: no firmware writes"));
    assert_eq!(
        transcript
            .into_iter()
            .filter(|l| !receiver_probe_line(l))
            .collect::<Vec<_>>(),
        [
            "MEDIUM -> DiscPresent",
            "IN   cdb=3c06001ec00000010000 alloc=256 -> ok 256",
            "IN   cdb=3c060000300000002000 alloc=32 -> ok 32",
            // The optical receiver profile independently binds its chip from the boot banner.
            "IN   cdb=3c060000300000002000 alloc=32 -> ok 32",
            "IN   cdb=3c06001ec000000100000000 alloc=256 -> ok 256",
            "IN   cdb=000000000000000000000000 alloc=0 -> ok 0",
        ]
    );

    // Pioneer's dry run plans from the file: no tray check, no I/O at all.
    let (_, target) = pioneer_update(false);
    let req = pioneer_request(target, &PIONEER_PACKAGE, false);
    let (outcome, transcript) = drive_run(MockScsiDevice::pioneer().with_medium_loaded(), |d| {
        engine_flash(d, &Pioneer::new(), &req)
    });
    assert_eq!(outcome.result, "OK");
    assert!(transcript.is_empty(), "{transcript:#?}");
    assert_eq!(
        outcome.text.last().unwrap(),
        "DRY RUN: no firmware writes or backup capture. Drive discovery may read identity metadata."
    );
}

#[test]
fn pioneer_preview_passes_only_package_checks_without_approving_drive_compatibility() {
    let (_, target) = pioneer_update(false);
    let req = pioneer_request(target, &PIONEER_PACKAGE, false);
    let mut dev = MockScsiDevice::pioneer();
    let preview = crate::engine::preview_flash_details(&mut dev, &Pioneer::new(), &req).unwrap();
    assert!(preview.compatibility_pending);
    assert!(preview
        .lines
        .iter()
        .any(|line| line.contains("Drive compatibility is still pending")));
    assert!(preview
        .lines
        .iter()
        .any(|line| line.contains("before confirmation or writing")));
    assert!(dev.reads.is_empty());
    assert!(dev.writes.is_empty());
}

#[test]
fn mtk_execute_prints_plan_after_backup_summary() {
    let dir = scratch("plan-after-backup");
    let out = dir.join("rollback.bin");
    let image = make_flashable(vec![0x11u8; IMAGE_SIZE], "BD-RE BU40N");
    let req = mtk_request(image, true, Some(out.clone()));
    let dev = MockScsiDevice::echoing().with_firmware_image(backup_firmware());
    let (outcome, _) = drive_run(dev, |d| engine_flash(d, &Mtk, &req));
    assert_eq!(outcome.result, "OK");
    let last_backup_read = outcome
        .text
        .iter()
        .rposition(|l| l.starts_with("reading drive memory"))
        .expect("backup progress");
    let header = text_index(&outcome, "== flash plan ==");
    let backup = text_index(&outcome, "backup: saved ");
    assert!(last_backup_read < header && header < backup);
    assert!(outcome.text[backup].contains(&out.display().to_string()));
    assert!(backup < text_index(&outcome, "EXECUTING flash"));
}

// ---- the CLI prompt, recorded against v0.11.2 --------------------------------

/// The confirmation text the prompt goldens show (a Pioneer package summary).
const CONFIRM_TEXT: &str = "This will flash: KERNEL (rev 0000) + NORMAL (rev 1.00)";

/// The CLI's prompt core with the terminal check and input scripted.
struct Scripted {
    is_tty: bool,
    input: &'static str,
}

impl Confirm for Scripted {
    fn confirm(&mut self, _plan: &AuthorizedPlan) -> Result<bool> {
        let mut reader = self.input.as_bytes();
        crate::output::confirm_with(self.is_tty, &mut reader)
    }
}

/// The engine showing a confirmation and the CLI answering it, TTY and not.
#[test]
fn golden_pioneer_confirm_prompt() {
    let mut g = Golden::default();
    for (title, is_tty, input) in [
        ("Pioneer prompt: stdin is not a TTY", false, ""),
        ("Pioneer prompt: TTY answers y", true, "y\n"),
        ("Pioneer prompt: TTY answers yes", true, "YES\n"),
        ("Pioneer prompt: TTY answers n", true, "n\n"),
        ("Pioneer prompt: TTY input ends", true, ""),
    ] {
        let mut dev = MockScsiDevice::echoing();
        let mut cli = Scripted { is_tty, input };
        let outcome =
            run(|| crate::engine::flash(&mut dev, &Confirming, &confirming_request(), &mut cli));
        g.case(title, &outcome, None);
    }
    check("pioneer_confirm_prompt", g);
}

// ---- a minimal backend for engine-order checks ------------------------------

fn confirming_request() -> FlashRequest {
    let mut req = mtk_request(vec![1], true, None);
    req.predump_out = Some(scratch("confirming").join("backup.bin"));
    req
}

/// A backend whose backup always saves and whose authorize asks a question.
struct Confirming;

/// A backend whose backup capture always fails.
struct FailingBackup;

static TEST_FORMATS: &[FileFormat] = &[];
static CONFIRMING: crate::backend::Descriptor = crate::backend::Descriptor {
    id: BackendId("test-confirming"),
    display_name: "Test",
    flash_summary: None,
    formats: TEST_FORMATS,
};

macro_rules! test_backend {
    ($ty:ty, $capture:expr) => {
        test_backend!($ty, $capture, Ok(Vec::new()));
    };
    ($ty:ty, $capture:expr, $preflight:expr) => {
        impl Backend for $ty {
            fn descriptor(&self) -> &'static crate::backend::Descriptor {
                &CONFIRMING
            }
            fn probe(
                &self,
                _: &mut ReadDevice<'_>,
                _: &crate::backend::Identity,
            ) -> Result<Option<crate::backend::Match>> {
                Ok(None)
            }
            fn backup(&self) -> Option<&dyn BackupFacet> {
                Some(self)
            }
            fn flash(&self) -> Option<&dyn FlashFacet> {
                Some(self)
            }
        }
        impl BackupFacet for $ty {
            fn format(&self) -> crate::backend::BackupFormat {
                crate::backend::BackupFormat {
                    extension: "bin",
                    infix: "backup",
                }
            }
            fn capture(&self, _: &mut ReadDevice<'_>) -> Result<Vec<u8>> {
                $capture
            }
            fn notice(&self, _: &[u8]) -> crate::backend::BackupNotice {
                crate::backend::BackupNotice::None
            }
            fn validate(&self, bytes: &[u8], _: &str) -> Result<Vec<u8>> {
                Ok(bytes.to_vec())
            }
        }
        impl FlashFacet for $ty {
            fn can_proceed_without_backup(&self) -> bool {
                true // These synthetic executors do not need installed receiver bytes.
            }
            fn preflight(
                &self,
                _: &mut ReadDevice<'_>,
                _: &FlashPlan,
            ) -> Result<Vec<crate::backend::PlanLine>> {
                $preflight
            }
            fn plan(&self, _: &mut ReadDevice<'_>, _: &FlashRequest) -> Result<FlashPlan> {
                Ok(FlashPlan::new(()))
            }
            fn authorize(
                &self,
                _: &mut ReadDevice<'_>,
                plan: FlashPlan,
                _: Option<&SavedBackup>,
            ) -> Result<AuthorizedPlan> {
                let mut authorized = AuthorizedPlan::new(plan, ());
                authorized.confirmation = Some(CONFIRM_TEXT.into());
                Ok(authorized)
            }
            fn execute(
                &self,
                dev: &mut WriteDevice<'_>,
                _: &AuthorizedPlan,
            ) -> Result<crate::backend::UpdateOutcome> {
                dev.command_out(&[0x3b, 0, 0, 0, 0, 0, 0, 0, 0, 0], &[0])?;
                Ok(crate::backend::UpdateOutcome::Completed(
                    crate::backend::UpdateEvidence {
                        target_started: false,
                        target_identity: String::new(),
                        verified_regions: vec![],
                        unverified_regions: vec!["test write".into()],
                        completed_stages: vec!["test write".into()],
                        temporary_firmware: false,
                    },
                ))
            }
        }
    };
}

test_backend!(Confirming, Ok(vec![0xAA; 16]));
test_backend!(FailingBackup, bail!("no capture"));

/// Flash `target` onto a drive running `installed` (both `BD-RE  BH16NS40`)
/// through the real engine, recording every command in order.
fn family_flash(installed: &[u8], target: &[u8]) -> (Outcome, Vec<String>, std::path::PathBuf) {
    let model = "BD-RE  BH16NS40";
    let backup = scratch("mtk-family-tripwire").join(format!("{}.bin", sha(target)));
    let mut req = mtk_request(target.to_vec(), true, Some(backup.clone()));
    req.drive_model = model.into();
    let dev = MockScsiDevice::echoing()
        .with_firmware_image(drive_read(installed))
        .with_product(model);
    let (outcome, transcript) = drive_run(dev, |d| engine_flash(d, &Mtk, &req));
    (outcome, transcript, backup)
}

/// The session as the transcript records it: what the OEM tool sends.
fn oem_session() -> Vec<String> {
    mediatek_optical::DriveClass::Mt19
        .steps()
        .iter()
        .map(|step| {
            use mediatek_optical::update::Direction;
            match step.direction {
                Direction::Out => format!("OUTS cdb={} len={}", hex(&step.cdb), step.length),
                _ => format!("IN   cdb={} alloc={}", hex(&step.cdb), step.length),
            }
        })
        .collect()
}

#[test]
fn same_line_reflash_sends_exactly_the_oem_session() {
    for board in [fixture::JB7, fixture::JB8] {
        let image = fixture::image(&board, "BD-RE  BH16NS40", 9);
        let (outcome, transcript, _) = family_flash(&image, &image);
        assert_eq!(outcome.result, "OK", "{board:?}: {:#?}", outcome.text);
        // Read-only preflight also probes. The OEM session begins two
        // commands before the first PREPARE write (PROBE, TUR, PREPARE).
        let start = transcript
            .iter()
            .position(|l| l.starts_with("OUT"))
            .expect("PREPARE")
            .checked_sub(2)
            .expect("PROBE and TUR before PREPARE");
        let sent: Vec<String> = transcript[start..start + 134]
            .iter()
            .map(|l| {
                l.split(" sha256=")
                    .next()
                    .unwrap()
                    .split(" -> ")
                    .next()
                    .unwrap()
                    .to_string()
            })
            .collect();
        assert_eq!(sent, oem_session(), "{board:?}");
        // The OEM updaters' REQUEST SENSE (INTENDED_CHANGES.md, M-RS).
        assert_eq!(sent[133], "IN   cdb=030000001080000000000000 alloc=16");
    }
}

#[test]
fn cross_line_image_is_refused_after_the_backup_before_any_write() {
    let model = "BD-RE  BH16NS40";
    // Two board lines of the SAME chip (both MT1939, banner "MT1939 Boot Code")
    // and model, differing only by platform → a family mismatch caught after the
    // backup. (JB8 is now MT1959, so JB7-vs-JB8 would be a chip mismatch caught
    // before the backup, a different path.)
    let jb7 = fixture::image(&fixture::JB7, model, 3);
    let jb9 = fixture::image(
        &fixture::Board {
            platform: "JB9",
            ..fixture::JB7
        },
        model,
        5,
    );
    for (installed, target) in [(&jb7, &jb9), (&jb9, &jb7)] {
        let (outcome, transcript, backup) = family_flash(installed, target);
        assert!(
            outcome.result.contains("family mismatch"),
            "{}",
            outcome.result
        );
        assert!(backup.exists(), "the pre-flash backup is kept");
        assert!(
            !transcript.iter().any(|l| l.starts_with("OUT")),
            "no write may reach the drive"
        );
    }
}

#[test]
fn unknown_families_are_refused_before_any_write() {
    let model = "BD-RE  BH16NS40";
    let jb7 = fixture::image(&fixture::JB7, model, 3);
    let nameless = fixture::without_record(&jb7);
    for (installed, target, which) in [(&jb7, &nameless, "target"), (&nameless, &jb7, "installed")]
    {
        let (outcome, transcript, backup) = family_flash(installed, target);
        assert!(
            outcome
                .result
                .contains(&format!("could not determine the {which} firmware family")),
            "{}",
            outcome.result
        );
        assert!(!transcript.iter().any(|l| l.starts_with("OUT")));
        // An image without a family is refused at the plan, before the backup.
        assert_eq!(backup.exists(), which == "installed", "{which}");
    }
}

// These additional read-only commands inspect the active receiver; golden
// transcripts and the detector tests separately verify their exact contents.
fn receiver_probe_line(line: &str) -> bool {
    [
        "IN   cdb=120000002400",
        "IN   cdb=3c060009",
        "IN   cdb=3c06000a",
        "IN   cdb=3c06000b",
        "IN   cdb=3c060014",
        "IN   cdb=3c060015",
        "IN   cdb=3c060016",
        "IN   cdb=3c060017",
        "IN   cdb=3c060018",
        "IN   cdb=3c060019",
        "IN   cdb=3c06001a",
    ]
    .iter()
    .any(|prefix| line.starts_with(prefix))
}

#[test]
fn execute_runs_readonly_preflight_before_backup_or_write() {
    struct Unready;
    test_backend!(
        Unready,
        panic!("backup must not start after refused preflight"),
        bail!("receiver not ready")
    );
    let mut dev = MockScsiDevice::new();
    let req = confirming_request();
    let error = crate::engine::flash(&mut dev, &Unready, &req, &mut crate::workflow::Preconfirmed)
        .unwrap_err();
    assert!(crate::workflow::error_message(&error).contains("No firmware was written"));
    assert!(format!("{error:#}").contains("receiver not ready"));
    let evidence = error
        .downcast_ref::<crate::backend::UpdateFailure>()
        .unwrap();
    assert_eq!(evidence.phase, "preflight");
    assert!(!evidence.write_started);
    assert!(dev.writes.is_empty());
    assert!(!req.predump_out.as_ref().unwrap().exists());
}
