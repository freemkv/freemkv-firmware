//! Read-only device handles. A backend's read-only operations receive a
//! [`ReadDevice`], which refuses every data-out command except the read-unlock
//! commands the backend declares, and every zero-length data-in except the
//! read-safe no-data commands in `NO_DATA_READS`. Writable handles come only
//! from the engine's gates (`engine::gates::WriteDevice`).

use anyhow::{bail, Result};

use super::Backend;
use crate::platform::{MediumStatus, ScsiDevice};

/// A data-out command a backend declares, matched by CDB and payload.
pub struct CdbPattern {
    /// What the command is, for refusals and reviews.
    pub label: &'static str,
    /// Whether a CDB and its data-out payload are this command. Commands that
    /// share a CDB and differ only in payload must be told apart here.
    pub matches: fn(cdb: &[u8], data: &[u8]) -> bool,
}

/// Whether `cdb` with payload `data` matches any of `patterns`.
pub(crate) fn declared(patterns: &[CdbPattern], cdb: &[u8], data: &[u8]) -> bool {
    patterns.iter().any(|p| (p.matches)(cdb, data))
}

/// The refusal for an undeclared data-out command.
pub(crate) fn refuse(cdb: &[u8]) -> anyhow::Error {
    anyhow::anyhow!(
        "refused data-out command {}: a read-only operation may only send its \
         backend's declared read-unlock commands",
        hex(cdb)
    )
}

/// Opcodes a limited handle may issue as a zero-length data-in. The MediaTek
/// transport sends no-data commands that way, so an unlisted opcode (PREPARE,
/// COMMIT) is refused. Derived from every zero-length command the flasher
/// sends: only TEST UNIT READY (the MediaTek sequences, recovery, readiness).
pub(crate) const NO_DATA_READS: &[u8] = &[0x00];

/// Refuse a zero-length data-in whose opcode is not in [`NO_DATA_READS`].
pub(crate) fn check_no_data(cdb: &[u8], alloc_len: usize) -> Result<()> {
    if alloc_len == 0 && !cdb.first().is_some_and(|op| NO_DATA_READS.contains(op)) {
        bail!(
            "refused no-data command {}: a read-only operation may only send \
             TEST UNIT READY without a data phase",
            hex(cdb)
        );
    }
    Ok(())
}

fn hex(cdb: &[u8]) -> String {
    cdb.iter().map(|b| format!("{b:02x}")).collect()
}

/// A device lent to a read-only operation.
pub struct ReadDevice<'d> {
    dev: &'d mut dyn ScsiDevice,
    allowed: &'static [CdbPattern],
}

impl<'d> ReadDevice<'d> {
    /// Wrap `dev` for `backend`'s read-only operations: the only data-out
    /// allowed is the read-unlock commands it declares in
    /// [`Backend::allowed_data_out`].
    pub fn for_backend<B: Backend + ?Sized>(dev: &'d mut dyn ScsiDevice, backend: &B) -> Self {
        Self::new(dev, backend.allowed_data_out())
    }

    /// Wrap `dev`, allowing no data-out at all (before a backend is known).
    pub fn without_unlocks(dev: &'d mut dyn ScsiDevice) -> Self {
        Self::new(dev, &[])
    }

    /// Wrap `dev`, allowing only the data-out commands in `allowed`. Private, so
    /// a read grant never carries patterns no backend declared.
    fn new(dev: &'d mut dyn ScsiDevice, allowed: &'static [CdbPattern]) -> Self {
        Self { dev, allowed }
    }

    fn check(&self, cdb: &[u8], data: &[u8]) -> Result<()> {
        if !declared(self.allowed, cdb, data) {
            bail!(refuse(cdb));
        }
        Ok(())
    }
}

impl ScsiDevice for ReadDevice<'_> {
    fn diagnostic_in(&mut self, cdb: &[u8], alloc_len: usize, timeout_ms: u32) -> Result<Vec<u8>> {
        check_no_data(cdb, alloc_len)?;
        self.dev.diagnostic_in(cdb, alloc_len, timeout_ms)
    }

    fn command_in(&mut self, cdb: &[u8], alloc_len: usize) -> Result<Vec<u8>> {
        check_no_data(cdb, alloc_len)?;
        self.dev.command_in(cdb, alloc_len)
    }

    fn command_out(&mut self, cdb: &[u8], data: &[u8]) -> Result<()> {
        self.check(cdb, data)?;
        self.dev.command_out(cdb, data)
    }

    fn command_out_strict(&mut self, cdb: &[u8], data: &[u8]) -> Result<()> {
        self.check(cdb, data)?;
        self.dev.command_out_strict(cdb, data)
    }

    fn describe(&self) -> String {
        self.dev.describe()
    }

    fn medium_status(&mut self) -> Result<MediumStatus> {
        self.dev.medium_status()
    }
}

/// The device a dump or recovery receives: read-only, or a write grant the
/// engine issued after that operation's gates passed.
pub enum DeviceAccess<'a, 'd> {
    /// Read-only access.
    Read(&'a mut ReadDevice<'d>),
    /// A gated write grant.
    Write(&'a mut crate::engine::gates::WriteDevice<'d>),
}

impl<'d> DeviceAccess<'_, 'd> {
    /// The device for reads (and, under a write grant, writes).
    pub fn scsi(&mut self) -> &mut dyn ScsiDevice {
        match self {
            Self::Read(dev) => &mut **dev,
            Self::Write(dev) => &mut **dev,
        }
    }

    /// The write grant, when the engine issued one.
    pub fn writer(&mut self) -> Option<&mut crate::engine::gates::WriteDevice<'d>> {
        match self {
            Self::Read(_) => None,
            Self::Write(dev) => Some(&mut **dev),
        }
    }
}

#[cfg(test)]
#[path = "device_tests.rs"]
mod tests;
