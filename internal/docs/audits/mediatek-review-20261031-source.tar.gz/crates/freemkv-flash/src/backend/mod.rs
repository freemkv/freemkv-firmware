//! The backend contract: identity, file formats, optional facets, devices and
//! the explicit registry.
//!
//! A drive family is a module under [`crate::backends`] plus one line in
//! [`registry`]. Core code reaches a backend only through the [`Backend`]
//! trait: its [`Descriptor`] and whichever facets it offers. What a drive can
//! do ([`Capabilities`]) is derived from facet presence.
//!
//! Every read-only operation receives a [`ReadDevice`], which refuses data-out
//! except the backend's declared read-unlock commands. Writes receive a
//! [`WriteDevice`], which only the engine's gates can create.

use std::any::Any;
use std::fmt;
use std::path::{Path, PathBuf};

use anyhow::{Context, Result};

use crate::inspection::{Control, Inspection, LiveState};
use crate::manifest::FlashMode;
use crate::platform::ScsiDevice;
use crate::report::{Row, Slot};

pub mod detection;
pub mod device;
pub mod registry;

pub use crate::engine::gates::{SavedBackup, WriteDevice};
pub use device::{CdbPattern, DeviceAccess, ReadDevice};

// ---- Identity and formats ---------------------------------------------------

/// Stable protocol name of a backend (`"mtk19xx"`, `"pioneer-oem"`).
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct BackendId(pub &'static str);

impl fmt::Display for BackendId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.0)
    }
}

/// What a backend declares about itself.
#[derive(Debug)]
pub struct Descriptor {
    /// Stable protocol name.
    pub id: BackendId,
    /// User-facing family name (`"MediaTek MT19xx"`, `"Pioneer"`).
    pub display_name: &'static str,
    /// The `flash:` line `info` prints for a live drive, when one applies.
    pub flash_summary: Option<&'static str>,
    /// Every file format this backend reads, in recognition order.
    pub formats: &'static [FileFormat],
}

impl Descriptor {
    /// Whether `format` is one of this backend's own formats.
    pub fn owns(&self, format: &FileFormat) -> bool {
        self.formats.contains(format)
    }
}

/// How the engine treats a flash input of a given format.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FormatRole {
    /// A firmware image written as is.
    Image,
    /// A backup archive, decoded back to an image before writing.
    Backup,
    /// A multi-component update package.
    Package,
}

/// One file format a backend owns.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct FileFormat {
    /// Stable id (`"mtk-image"`, `"pioneer-package"`).
    pub id: &'static str,
    /// User-facing wording (`"Pioneer firmware bundle"`).
    pub label: &'static str,
    /// Usual file-name endings, for pickers and help text.
    pub extensions: &'static [&'static str],
    /// May Flash and Recovery use this as an update input (not merely inspect it)?
    pub update_input: bool,
    /// How a flash treats this format.
    pub role: FormatRole,
}

impl FileFormat {
    /// Shared format gate for Flash, Recovery and their Current references.
    pub fn ensure_update_input(&self) -> Result<()> {
        anyhow::ensure!(
            self.update_input,
            anyhow::anyhow!(
                "{} is inspection-only; use a TAR package for Pioneer updates",
                self.label
            )
            .context(crate::user_error::IssueCode::UnsupportedFirmware)
        );
        Ok(())
    }
}

/// Family name shown for a drive no backend recognizes.
pub const UNKNOWN_FAMILY: &str = "Unknown";

/// Standard INQUIRY identity fields plus the boot banner, for `info`.
#[derive(Debug, Clone, Default)]
pub struct Identity {
    /// T10 vendor id (INQUIRY bytes 8..16), trimmed.
    pub vendor: String,
    /// Product id (INQUIRY bytes 16..32), trimmed.
    pub product: String,
    /// Product revision (INQUIRY bytes 32..36), trimmed.
    pub revision: String,
    /// "MT19xx Boot" banner (READ BUFFER mode 6 @ 0x3000), if any.
    pub banner: Option<String>,
}

pub(crate) fn trim_ascii(bytes: &[u8]) -> String {
    String::from_utf8_lossy(bytes)
        .trim_matches(|c: char| c.is_whitespace() || c == '\0')
        .to_string()
}

/// Sanitize a drive-supplied ASCII string for safe display: keeps printable
/// bytes (0x20..=0x7e) and replaces everything else (including terminal
/// control/escape sequences a malicious or malfunctioning drive could return)
/// with `.`.
pub(crate) fn sanitize_ascii(s: &str) -> String {
    s.chars()
        .map(|c| {
            if ('\u{20}'..='\u{7e}').contains(&c) {
                c
            } else {
                '.'
            }
        })
        .collect()
}

/// Standard SPC INQUIRY CDB for `alloc` bytes.
fn inquiry_cdb(alloc: u8) -> [u8; 6] {
    [0x12, 0x00, 0x00, 0x00, alloc, 0x00]
}

/// Read standard INQUIRY identity, surfacing a failed INQUIRY (permission or
/// transport fault) as an error instead of an empty identity.
pub fn try_read_identity(dev: &mut dyn ScsiDevice) -> Result<Identity> {
    let data = dev
        .command_in(&inquiry_cdb(96), 96)
        .context("INQUIRY failed")?;
    let id = decode_identity(&data)?;
    crate::diagnostics::record(format!(
        "drive identity: vendor={:?} product={:?} revision={:?}",
        id.vendor, id.product, id.revision
    ));
    Ok(id)
}

pub(crate) fn decode_identity(data: &[u8]) -> Result<Identity> {
    anyhow::ensure!(
        data.len() >= 36,
        "short INQUIRY identity: {} bytes returned, at least 36 required",
        data.len()
    );
    Ok(Identity {
        vendor: sanitize_ascii(&trim_ascii(&data[8..16])),
        product: sanitize_ascii(&trim_ascii(&data[16..32])),
        revision: sanitize_ascii(&trim_ascii(&data[32..36])),
        banner: None,
    })
}

/// Read standard INQUIRY identity. Vendor ROM reads belong to a matched
/// protocol backend, never to the common identity path. A failed INQUIRY still
/// yields an empty identity for legacy metadata callers and records the cause.
/// Use `try_read_identity` when identification is required for the operation.
pub fn read_identity(dev: &mut dyn ScsiDevice) -> Identity {
    match try_read_identity(dev) {
        Ok(id) => id,
        Err(error) => {
            crate::diagnostics::record(format!("could not read drive identity: {error:#}"));
            Identity::default()
        }
    }
}

/// A positive read-only probe.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Match {
    /// The backend that matched.
    pub backend: BackendId,
    /// Read-only signature that justified the match.
    pub evidence: &'static str,
}

// ---- Shared request and report types ----------------------------------------

/// A fully-resolved flash request handed to [`crate::engine`].
#[derive(Debug, Clone)]
pub struct FlashRequest {
    /// Explicit installed-firmware receiver evidence; never used as a backup.
    pub current: Option<Vec<u8>>,
    /// The raw input file bytes.
    pub input: Vec<u8>,
    /// The input's format, owned by the drive's backend unless misdirected.
    pub input_format: &'static FileFormat,
    /// Streaming mode (`main` vs `full`). On MediaTek this is informational:
    /// the full image is always streamed and the commit always sent.
    pub mode: FlashMode,
    /// Actually issue writes (otherwise dry-run).
    pub execute: bool,
    /// User acknowledged the bricking risk.
    pub acknowledged_risk: bool,
    /// Legacy encoding assertion. MediaTek rejects a value that contradicts
    /// live receiver detection; CLI and GUI leave this unset.
    pub enc_override: Option<bool>,
    /// Drive model (INQUIRY product), shown in the flash plan.
    pub drive_model: String,
    /// Show the raw SCSI CDB sequence in the plan (default: clean summary only).
    pub verbose: bool,
    /// Where to save the required pre-flash backup.
    pub predump_out: Option<std::path::PathBuf>,
}

/// A selected firmware image has proven missing or corrupt bytes.
#[derive(Debug)]
pub struct CorruptFirmware {
    /// Diagnostic description; rendered UI guidance does not expose this text.
    pub detail: String,
}
impl fmt::Display for CorruptFirmware {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.detail)
    }
}
impl std::error::Error for CorruptFirmware {}

/// Live receiver detection failed; retain diagnostics while asking for Current.
#[derive(Debug)]
pub struct CurrentFirmwareRequired {
    pub(crate) source: anyhow::Error,
}

impl std::fmt::Display for CurrentFirmwareRequired {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("The current firmware could not be automatically detected from the drive. Specify the firmware currently installed as Current firmware and try again.")
    }
}

impl std::error::Error for CurrentFirmwareRequired {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        Some(self.source.as_ref())
    }
}

/// A proven hardware-family mismatch, with technical evidence kept as its source.
#[derive(Debug)]
pub struct HardwareMismatch {
    pub(crate) installed_model: String,
    pub(crate) target_model: String,
    pub(crate) source: anyhow::Error,
}

impl std::fmt::Display for HardwareMismatch {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "The underlying hardware for these firmwares is not compatible. Installed firmware: {}. Target firmware: {}. No firmware was written.",
            crate::style::printable(crate::style::ident_or_unknown(&self.installed_model)),
            crate::style::printable(crate::style::ident_or_unknown(&self.target_model)))
    }
}

impl std::error::Error for HardwareMismatch {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        Some(self.source.as_ref())
    }
}

/// A valid Normal requires a different Kernel generation than the drive has.
#[derive(Debug)]
pub struct InstalledKernelMismatch {
    /// The Kernel tag required by the selected Normal.
    pub required: String,
    /// The Kernel tag found in the installed backup.
    pub installed: String,
}

impl std::fmt::Display for InstalledKernelMismatch {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Normal requires Kernel {}, but the drive has Kernel {}",
            self.required, self.installed
        )
    }
}

impl std::error::Error for InstalledKernelMismatch {}

/// What a drive offers, derived from the facets its backend provides.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Capabilities {
    /// Flash accepts an explicit installed-firmware receiver reference.
    pub flash_current: bool,
    /// A complete or candidate firmware backup can be captured (`backup`).
    pub backup: bool,
    /// A raw memory dump can be captured (`dump`).
    pub dump: bool,
    /// The WRITE path (`flash`) is implemented and may execute.
    pub flash: bool,
    /// A receiver can be recovered (`recover`).
    pub recovery: bool,
    /// Firmware from this backend can be inspected.
    pub inspect: bool,
    /// The dump is a deeper salvage read (slower, retrying, tolerant of an
    /// unstable drive).
    pub deep_salvage: bool,
}

impl Capabilities {
    /// A drive no backend recognizes: identify only.
    pub const NONE: Self = Self {
        flash_current: false,
        backup: false,
        dump: false,
        flash: false,
        recovery: false,
        inspect: false,
        deep_salvage: false,
    };

    /// What `backend` offers.
    pub fn of(backend: &dyn Backend) -> Self {
        Self {
            flash_current: backend.flash().is_some_and(|f| f.accepts_current()),
            backup: backend.backup().is_some(),
            dump: backend.dump().is_some(),
            flash: backend.flash().is_some(),
            recovery: backend.recovery().is_some(),
            inspect: backend.inspect().is_some(),
            deep_salvage: backend.dump().is_some_and(|d| d.deep_salvage()),
        }
    }
}

/// How a backup file is named and labelled: `<model>_<rev>.<infix>.<extension>`
/// and a `<infix> sha256` line.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BackupFormat {
    /// File extension.
    pub extension: &'static str,
    /// Filename infix: `backup` for a proven rollback, `candidate` otherwise.
    pub infix: &'static str,
}

/// Provenance of a just-written backup, decided from the artifact's own bytes.
pub enum BackupNotice {
    /// Every component is byte-exact OEM; the capture is a faithful original.
    VerifiedOem(String),
    /// At least one component is a reconstruction (made-up seed/signature), so
    /// physical restore and drive acceptance are untested.
    Unverified(String),
    /// Nothing to say about provenance.
    None,
}

/// The installed firmware's identity, as `info` and the post-flash check show it.
pub struct FirmwareReport {
    /// ASCII descriptor read from the drive, when it has one.
    pub descriptor: Option<String>,
    /// Fingerprint of the firmware's readable code windows.
    pub fingerprint: String,
    /// The matching catalog entry: `(description, where to obtain the image)`.
    pub matched: Option<(&'static str, &'static str)>,
}

/// Unsupported-protocol error shared by backup and flash dispatch. `family`
/// is the matched backend's display name, or [`UNKNOWN_FAMILY`].
pub fn unsupported_family_error(family: &str) -> anyhow::Error {
    anyhow::anyhow!(
        "No executable flash path or confirmed restorable backup is available for {family}. \
         Identification probes may have been sent; no firmware write or backup file was produced. \
         Run `freemkv-flash info DEVICE` to record the identity before adding a backend."
    )
    .context(crate::user_error::IssueCode::UnsupportedDrive)
}

// ---- The trait and its facets -----------------------------------------------

/// A firmware command-protocol backend. Everything beyond identity is an
/// optional facet; core code offers exactly what the facets provide.
pub trait Backend: Sync + 'static {
    /// A localized, expected read limitation shown before capture/update.
    fn read_notice(&self) -> Option<&'static str> {
        None
    }

    /// Whether to offer automatic Current firmware acquisition. The optical
    /// library owns this protocol capability; unknown backends require a file.
    fn can_read(&self) -> bool {
        false
    }

    /// What this backend declares about itself: id, names and file formats.
    fn descriptor(&self) -> &'static Descriptor;

    /// Recognize this protocol from read-only evidence. `None` means it does not
    /// match; an error means the probe could not safely decide.
    fn probe(&self, dev: &mut ReadDevice<'_>, identity: &Identity) -> Result<Option<Match>>;

    /// INQUIRY identity plus any backend banner, for `info` and backup naming.
    fn identity(&self, dev: &mut ReadDevice<'_>) -> Identity {
        self.try_identity(dev).unwrap_or_else(|error| {
            crate::diagnostics::record(format!("could not read backend identity: {error:#}"));
            Identity::default()
        })
    }

    /// Required identity, preserving a failed read instead of declaring the drive unsupported.
    fn try_identity(&self, dev: &mut ReadDevice<'_>) -> Result<Identity> {
        try_read_identity(dev).map_err(|error| {
            crate::user_error::explain(error, crate::user_error::IssueCode::Connection)
        })
    }

    /// The data-out commands this backend's read-only operations may send
    /// (e.g. a read-unlock knock). Everything else is refused.
    fn allowed_data_out(&self) -> &'static [CdbPattern] {
        &[]
    }

    /// File recognition and description (`check`, `info <file>`, flash input).
    fn files(&self) -> Option<&dyn FileFacet> {
        None
    }
    /// Vendor details for `info` and the post-flash identity check.
    fn details(&self) -> Option<&dyn DetailsFacet> {
        None
    }
    /// Backup capture and restore decoding.
    fn backup(&self) -> Option<&dyn BackupFacet> {
        None
    }
    /// Raw memory dump.
    fn dump(&self) -> Option<&dyn DumpFacet> {
        None
    }
    /// Firmware update.
    fn flash(&self) -> Option<&dyn FlashFacet> {
        None
    }
    /// Recovery of a receiver whose normal update path is unusable.
    fn recovery(&self) -> Option<&dyn RecoveryFacet> {
        None
    }
    /// Firmware inspection.
    fn inspect(&self) -> Option<&dyn InspectFacet> {
        None
    }
    /// Read-only drive settings.
    fn settings(&self) -> Option<&dyn SettingsFacet> {
        None
    }
}

/// How a file was recognized. A structural match (a parsed container or exact
/// layout) beats a heuristic one (a pattern search).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Confidence {
    /// The bytes parse as this format.
    Structural,
    /// A signature was found in the bytes.
    Heuristic,
}

/// A backend's claim on a file.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Recognized {
    /// The format the bytes are.
    pub format: &'static FileFormat,
    /// How sure the backend is.
    pub confidence: Confidence,
}

/// File recognition and description.
pub trait FileFacet {
    /// Offline family evidence for an early refusal when Current is supplied.
    /// Missing evidence leaves the complete admission checks mandatory.
    fn family_evidence(&self, _bytes: &[u8]) -> Option<(String, String)> {
        None
    }
    /// This backend's claim on `bytes`, if any. The registry resolves claims
    /// once for flash input, `check`, `info <file>` and inspection.
    fn recognize(&self, bytes: &[u8]) -> Option<Recognized>;
    /// Print the `info <file>` / `check` report for a file this backend
    /// recognized, or `None` to leave it to the generic report. Read-only.
    fn describe(&self, bytes: &[u8], recognized: &Recognized) -> Option<Result<()>>;
    /// Check device-independent input integrity before opening any drive.
    /// This grants no hardware compatibility or write authorization.
    fn validate_flash_input(&self, _bytes: &[u8], _recognized: &Recognized) -> Result<()> {
        Ok(())
    }
    /// The format of a flash input no backend recognizes, by its name, so the
    /// drive's flash path reports the specific parse error.
    fn classify_input(&self, path: &Path, bytes: &[u8]) -> &'static FileFormat;
    /// A format of this backend that the file name alone identifies, whichever
    /// drive the file is meant for.
    fn claims_by_name(&self, _path: &Path) -> Option<&'static FileFormat> {
        None
    }
}

/// What `info` has already read when it asks a backend for its rows.
pub struct InfoSoFar<'a> {
    /// The standard snapshot.
    pub standard: &'a crate::standard::StandardInfo,
    /// The backend's settings read, once the region rows are done.
    pub settings: Option<&'a Result<crate::output::device_settings::Settings>>,
}

/// Vendor details for `info`.
pub trait DetailsFacet {
    /// The backend's rows at `slot`. Anything already in `read` is reused,
    /// never read again.
    fn rows(&self, _dev: &mut ReadDevice<'_>, _read: &InfoSoFar<'_>, _slot: Slot) -> Vec<Row> {
        Vec::new()
    }
    /// The installed firmware's identity (also the post-flash check).
    fn post_flash_identity(&self, _dev: &mut ReadDevice<'_>) -> Result<Option<FirmwareReport>> {
        Ok(None)
    }
}

/// Drive settings, read-only.
pub trait SettingsFacet {
    /// Read the drive's settings.
    fn read(&self, dev: &mut ReadDevice<'_>) -> Result<crate::output::device_settings::Settings>;
}

/// Backup capture.
pub trait BackupFacet {
    /// File naming and labelling.
    fn format(&self) -> BackupFormat;
    /// Capture one complete serialized backup. Read-only.
    fn capture(&self, dev: &mut ReadDevice<'_>) -> Result<Vec<u8>>;
    /// Provenance advisory for a just-written backup.
    fn notice(&self, bytes: &[u8]) -> BackupNotice;
    /// Validate a backup for `target_model` and return the image it restores.
    fn validate(&self, bytes: &[u8], target_model: &str) -> Result<Vec<u8>>;
}

/// Raw memory dump (saved verbatim as one `.dump.bin`, not a backup).
pub trait DumpFacet {
    /// Whether the dump is a deeper salvage read.
    fn deep_salvage(&self) -> bool {
        false
    }
    /// Data-out commands the dump sends (unlocks, RAM logging); empty means a
    /// read-only dump.
    fn writes(&self) -> &'static [CdbPattern] {
        &[]
    }
    /// Capture the dump. A dump with declared writes gets a write grant limited
    /// to those commands.
    fn capture(&self, dev: DeviceAccess<'_, '_>) -> Result<Vec<u8>>;
}

/// One line of a flash plan, styled by the engine.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PlanLine {
    /// A bold section header.
    Header(String),
    /// A `label: value` fact.
    Field(&'static str, String),
    /// The `backup:` fact: the saved backup, or that a dry run captures none.
    Backup,
    /// Plain text.
    Text(String),
    /// A caution.
    Warning(String),
    /// A dotted-leader status row that passed.
    Ok(&'static str, String),
    /// Multi-line text shown as one block (it carries its own newlines).
    Block(String),
    /// A line set off from the previous one by a blank line.
    Spaced(Box<PlanLine>),
    /// Optional technical presentation; terminal output is unchanged.
    /// Nested warnings must remain visible in every front-end.
    Detail(Box<PlanLine>),
}

/// A pre-backup flash plan: what to show, plus backend-private state that only
/// the same backend's `authorize` reads.
pub struct FlashPlan {
    /// Installed-versus-target compatibility remains unchecked until backup.
    pub compatibility_pending: bool,
    /// Shown as soon as the plan is made, on a dry run and on execute.
    pub notes: Vec<PlanLine>,
    /// The plan a dry run shows.
    pub dry_run: Vec<PlanLine>,
    /// What execute shows once the backup is saved and covers the update.
    pub after_backup: Vec<PlanLine>,
    state: Box<dyn Any + Send>,
}

impl FlashPlan {
    /// A plan carrying `state` for the backend's own `authorize`.
    pub fn new(state: impl Any + Send) -> Self {
        Self {
            compatibility_pending: true,
            notes: Vec::new(),
            dry_run: Vec::new(),
            after_backup: Vec::new(),
            state: Box::new(state),
        }
    }

    /// The backend state, when this plan was made by that backend.
    pub fn state<T: 'static>(&self) -> Result<&T> {
        self.state
            .downcast_ref()
            .context("flash plan was made by another backend")
    }
}

/// A plan every installed-firmware gate has passed. Front-ends show
/// `warnings`, then ask for `confirmation` when it is set.
pub struct AuthorizedPlan {
    /// The plan this authorizes.
    pub plan: FlashPlan,
    /// Cautions shown before the confirmation (e.g. a generation barrier).
    pub warnings: Vec<String>,
    /// What the user confirms; `None` needs no further confirmation.
    pub confirmation: Option<String>,
    backup: String,
    saved_backup: Option<PathBuf>,
    backup_waived: bool,
    state: Box<dyn Any + Send>,
}

impl AuthorizedPlan {
    /// An authorization of `plan` carrying `state` for the backend's `execute`.
    pub fn new(plan: FlashPlan, state: impl Any + Send) -> Self {
        Self {
            plan,
            warnings: Vec::new(),
            confirmation: None,
            backup: String::new(),
            saved_backup: None,
            backup_waived: false,
            state: Box::new(state),
        }
    }

    /// The `backup:` summary of the saved pre-flash backup, which the engine
    /// fills in once the backend has authorized the plan.
    pub fn backup(&self) -> &str {
        &self.backup
    }

    pub(crate) fn set_backup(&mut self, summary: &str) {
        self.backup = summary.to_string();
    }

    /// Actual saved artifact evidence, populated only by the engine.
    pub fn saved_backup(&self) -> Option<&Path> {
        self.saved_backup.as_deref()
    }

    /// Whether the engine obtained explicit consent to proceed without rollback.
    pub fn backup_waived(&self) -> bool {
        self.backup_waived
    }

    pub(crate) fn set_backup_evidence(&mut self, saved: Option<&SavedBackup>) {
        self.saved_backup = saved.map(|backup| backup.path().to_path_buf());
        self.backup_waived = saved.is_none();
    }

    /// The backend state, when this authorization was made by that backend.
    pub fn state<T: 'static>(&self) -> Result<&T> {
        self.state
            .downcast_ref()
            .context("authorized plan was made by another backend")
    }
}

/// The installed MediaTek firmware restricts the reads needed for a full backup.
#[derive(Debug)]
pub struct BackupReadRestricted;

impl std::fmt::Display for BackupReadRestricted {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("This firmware cannot be backed up. This is normal for many MediaTek drives.")
    }
}

impl std::error::Error for BackupReadRestricted {}

/// A front-end's answer to an authorized flash's confirmation text.
pub trait Confirm {
    /// Whether to write. The engine has already shown the warnings and text.
    fn confirm(&mut self, plan: &AuthorizedPlan) -> Result<bool>;
    /// Whether to flash WITHOUT a rollback backup, after the pre-flash backup
    /// could not be captured (`reason` explains why). Default: refuse, so a
    /// front-end that cannot ask a human never silently flashes an
    /// unrecoverable drive. The CLI prompts; the GUI shows a sheet.
    fn proceed_without_backup(&mut self, _reason: &str) -> Result<bool> {
        Ok(false)
    }
    /// Whether to be asked about every authorized flash, including one whose
    /// backend words no confirmation (a GUI's sheet). The CLI asks only when
    /// there is text.
    fn asks_every_flash(&self) -> bool {
        false
    }
}

/// Evidence returned by an update executor; transferring bytes alone is not success.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum UpdateOutcome {
    /// Read-only preparation finished; no update was attempted.
    Planned,
    /// The procedure finished, with its verification limits retained.
    Completed(UpdateEvidence),
}

/// Readback evidence retained independently of the overall update outcome.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComponentVerification {
    /// All requested bytes matched.
    Matched,
    /// Readable bytes differed.
    Mismatched,
    /// Reads failed or were incomplete.
    Unavailable,
    /// The operation stopped before comparison.
    NotChecked,
    /// This component was not requested.
    NotRequested,
}

/// Verification facts preserved when a later update stage fails.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UpdateVerification {
    /// Kernel readback state for the current pass.
    pub kernel: ComponentVerification,
    /// Normal readback state for the current pass.
    pub normal: ComponentVerification,
    /// Normal runtime and receiver continuity were confirmed.
    pub startup_confirmed: bool,
    /// Device branding observed after the transfer, if available.
    pub observed_identity: Option<String>,
    /// Advertised identity of the selected package.
    pub selected_identity: String,
}
impl fmt::Display for UpdateVerification {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Kernel: {:?}; Normal: {:?}; startup confirmed: {}; selected package: {}; drive reports: {}",
            self.kernel, self.normal, self.startup_confirmed, self.selected_identity,
            self.observed_identity.as_deref().unwrap_or("not observed after transfer"))
    }
}
impl std::error::Error for UpdateVerification {}

/// Backend-owned facts about the requested target and every completed stage.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UpdateEvidence {
    /// The requested target's startup identity was confirmed.
    pub target_started: bool,
    /// Target model, revision and/or descriptor identity matched at startup.
    pub target_identity: String,
    /// Regions compared against the expected target bytes.
    pub verified_regions: Vec<String>,
    /// Regions that could not be read back or compared.
    pub unverified_regions: Vec<String>,
    /// Successfully completed stages, in execution order.
    pub completed_stages: Vec<String>,
    /// An intermediate or temporary image remains installed.
    pub temporary_firmware: bool,
}

impl UpdateOutcome {
    /// Only a confirmed final target permits optional post-update probing.
    pub fn safe_to_probe(&self) -> bool {
        matches!(self, Self::Completed(e) if e.target_started && !e.target_identity.is_empty() && !e.temporary_firmware)
    }

    /// Full completion requires both target startup and readback evidence.
    pub fn fully_verified(&self) -> bool {
        matches!(self, Self::Completed(e) if e.target_started && !e.target_identity.is_empty() && !e.temporary_firmware
            && !e.verified_regions.is_empty() && e.unverified_regions.is_empty())
    }

    /// A short result that never promotes limited verification to full success.
    pub fn summary(&self) -> &'static str {
        match self {
            Self::Planned => "preflight complete",
            Self::Completed(e) if e.temporary_firmware => "unfinished — temporary firmware remains",
            Self::Completed(e) if !e.target_started || e.target_identity.is_empty() => {
                "outcome uncertain — target startup not confirmed"
            }
            Self::Completed(_) if self.fully_verified() => "complete — target verified",
            Self::Completed(_) => "target started — readback verification limited",
        }
    }
}

/// A completed executor returned evidence that cannot confirm the final target.
/// Front-ends keep this typed result instead of reducing it to a summary string.
#[derive(Debug)]
pub struct UnverifiedUpdateOutcome(pub UpdateOutcome);

impl std::fmt::Display for UnverifiedUpdateOutcome {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "update outcome not verified: {:?}", self.0)
    }
}

impl std::error::Error for UnverifiedUpdateOutcome {}

/// The furthest update command boundary supported by backend evidence.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UpdateProgress {
    /// No update command was issued.
    Preflight,
    /// An update-entry command was attempted; no firmware payload was sent.
    EntryAttempted,
    /// A payload command was attempted, but acceptance is not established.
    PayloadAttempted,
    /// At least one payload command was accepted by the transport.
    PayloadAccepted,
    /// The complete payload was accepted; programming or startup is unconfirmed.
    UploadComplete,
    /// The backend cannot establish where the worker stopped.
    Unknown,
}

/// The consequence shown to a user, selected from typed transport evidence.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UpdateImpact {
    /// The update was blocked before a device update command.
    Blocked,
    /// Entry was attempted, with zero payload bytes sent.
    EntryUncertain,
    /// Firmware payload may be incomplete or unverified.
    PayloadUncertain,
    /// An intermediate image may remain installed.
    TemporaryFirmware,
    /// The update outcome is unknown.
    Unknown,
}

/// Facts retained when an update fails, including its last known protocol milestone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UpdateFailure {
    /// Stage or protocol phase where the failure occurred.
    pub phase: String,
    /// Whether a firmware-update command may have reached the drive.
    pub write_started: bool,
    /// Furthest protocol milestone known when the failure was reported.
    pub progress: UpdateProgress,
    /// Payload bytes acknowledged in the failing stage, when observable.
    pub payload_bytes_accepted: Option<usize>,
    /// Whether an intermediate or temporary image may remain installed.
    pub temporary_firmware: bool,
    /// Stages known to have completed before the failure.
    pub completed_stages: Vec<String>,
}

impl std::fmt::Display for UpdateFailure {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self.progress {
            UpdateProgress::EntryAttempted => write!(f,
                "update failed during {} (entry command attempted; no firmware payload sent; temporary firmware: {}; completed stages: {:?})",
                self.phase, self.temporary_firmware, self.completed_stages),
            _ if self.write_started => write!(f,
                "update failed during {} (progress: {:?}; payload bytes accepted in stage: {:?}; temporary firmware: {}; completed stages: {:?})",
                self.phase, self.progress, self.payload_bytes_accepted,
                self.temporary_firmware, self.completed_stages),
            _ => write!(f,
                "update failed during {} (write started: false; temporary firmware: {}; completed stages: {:?})",
                self.phase, self.temporary_firmware, self.completed_stages),
        }
    }
}

impl std::error::Error for UpdateFailure {}

impl UpdateFailure {
    /// Do not infer a payload write from an entry command alone.
    pub fn impact(&self) -> UpdateImpact {
        if self.temporary_firmware {
            return UpdateImpact::TemporaryFirmware;
        }
        match self.progress {
            UpdateProgress::Preflight => UpdateImpact::Blocked,
            UpdateProgress::EntryAttempted => UpdateImpact::EntryUncertain,
            UpdateProgress::PayloadAttempted
            | UpdateProgress::PayloadAccepted
            | UpdateProgress::UploadComplete => UpdateImpact::PayloadUncertain,
            UpdateProgress::Unknown => UpdateImpact::Unknown,
        }
    }

    /// Attach evidence only at a boundary that cannot issue firmware writes.
    pub(crate) fn before_write(phase: &str, error: anyhow::Error) -> anyhow::Error {
        if error.is::<Self>() {
            return error;
        }
        error.context(Self {
            phase: phase.into(),
            write_started: false,
            progress: UpdateProgress::Preflight,
            payload_bytes_accepted: Some(0),
            temporary_firmware: false,
            completed_stages: Vec::new(),
        })
    }
}

/// A preview can validate a package while installed compatibility is still pending.
pub struct FlashPreview {
    /// Rendered checks and limitations for the front-end.
    pub lines: Vec<String>,
    /// Requires installed evidence before confirmation and any firmware write.
    pub compatibility_pending: bool,
}

/// Firmware update in two read-only stages, then the write.
pub trait FlashFacet {
    /// A backend must explicitly support execution without installed rollback evidence.
    fn can_proceed_without_backup(&self) -> bool {
        false
    }
    /// Whether Flash accepts a separate installed-firmware receiver reference.
    fn accepts_current(&self) -> bool {
        false
    }
    /// Read-only and pre-backup: validate the input against the drive and
    /// describe the plan. Must not need the backup.
    fn plan(&self, dev: &mut ReadDevice<'_>, req: &FlashRequest) -> Result<FlashPlan>;
    /// Whether a dry run touches the drive (tray warning, preflight).
    fn dry_run_uses_device(&self) -> bool {
        true
    }
    /// Read-only readiness check, used on dry runs and before actual backup/write.
    /// The returned presentation lines are displayed only on a dry run.
    fn preflight(&self, _dev: &mut ReadDevice<'_>, _plan: &FlashPlan) -> Result<Vec<PlanLine>> {
        Ok(Vec::new())
    }
    /// Whether the saved backup is a usable rollback: it holds every region the
    /// plan overwrites. The backup stays saved when this refuses. Pioneer
    /// enforces this in its `verify_backup` override (a private coverage check).
    /// MediaTek does NOT override this method (it uses the default `Ok`); it
    /// enforces coverage in its `authorize`, where `InstalledFirmware::new`
    /// refuses a backup that cannot serve as the drive's installed firmware, and
    /// additionally runs its rollback simulation there via
    /// `crossflash::decide_rollback`, with the backup still saved.
    fn verify_backup(&self, _plan: &FlashPlan, _backup: &[u8]) -> Result<()> {
        Ok(())
    }
    /// Read-only, after the backup: every gate that needs the installed
    /// firmware. May refuse; the saved backup is kept.
    fn authorize(
        &self,
        dev: &mut ReadDevice<'_>,
        plan: FlashPlan,
        backup: Option<&SavedBackup>,
    ) -> Result<AuthorizedPlan>;
    /// Write, then verify the result.
    fn execute(&self, dev: &mut WriteDevice<'_>, plan: &AuthorizedPlan) -> Result<UpdateOutcome>;
}

/// A receiver a recovery backend identified, with what it read.
pub struct RecoveryTarget {
    /// The receiver as identified, for front-ends and diagnostics.
    pub label: String,
    state: Box<dyn Any + Send>,
}

impl RecoveryTarget {
    /// A target carrying `state` for the backend's own `recover`.
    pub fn new(label: String, state: impl Any + Send) -> Self {
        Self {
            label,
            state: Box::new(state),
        }
    }

    /// The backend state, when this target was identified by that backend.
    pub fn state<T: 'static>(&self) -> Result<&T> {
        self.state
            .downcast_ref()
            .context("recovery target was identified by another backend")
    }
}

/// A family override was requested from a backend that does not offer it.
#[derive(Debug)]
pub struct UnsupportedFamilyOverride;
impl std::fmt::Display for UnsupportedFamilyOverride {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("recovery.family_override_unsupported")
    }
}
impl std::error::Error for UnsupportedFamilyOverride {}

/// Recovery without automatic backups or Flash-only tray gates. Each backend
/// owns its recovery admission policy and declares any explicit family override.
pub trait RecoveryFacet {
    /// Prepare once; the returned object owns every loaded firmware byte.
    fn prepare(
        &self,
        dev: &mut ReadDevice<'_>,
        receiver: &RecoveryTarget,
        current: Option<&[u8]>,
        target: &[u8],
        bypass_family_check: bool,
    ) -> Result<Box<dyn PreparedRecoveryUpdate>>;

    /// A classified drive may need a Current file before its receiver can be identified.
    fn accepts_current_for_identification(&self) -> bool {
        false
    }
    /// Whether recovery needs an explicit Current file or permission to read it.
    fn requires_current(&self) -> bool {
        true
    }

    /// Read-only, with no protocol probe (the drive may be too damaged to
    /// classify): `Some` when this is a receiver this backend recovers.
    fn identify(&self, dev: &mut ReadDevice<'_>) -> Result<Option<RecoveryTarget>>;
    /// Identify with an explicitly supplied installed-firmware reference.
    /// Backends that do not need it retain their existing identification path.
    fn identify_with_current(
        &self,
        dev: &mut ReadDevice<'_>,
        _current: Option<&[u8]>,
    ) -> Result<Option<RecoveryTarget>> {
        self.identify(dev)
    }
    /// Whether this recovery backend can explicitly waive its firmware family check.
    fn supports_family_override(&self) -> bool {
        false
    }
    /// Recovery with an explicit family override; unsupported backends fail closed.
    fn recover_with_family_override(
        &self,
        dev: DeviceAccess<'_, '_>,
        receiver: &RecoveryTarget,
        current: Option<&[u8]>,
        target: &[u8],
        bypass_family_check: bool,
    ) -> Result<UpdateOutcome> {
        if bypass_family_check {
            return Err(UnsupportedFamilyOverride.into());
        }
        self.recover(dev, receiver, current, target)
    }
    /// The refusal when [`RecoveryFacet::identify`] finds no receiver.
    fn unidentified(&self) -> &'static str;
    /// Prepare the transfer from `current` (read from the drive when `None`)
    /// and `target`, and write it when given a write grant.
    fn recover(
        &self,
        dev: DeviceAccess<'_, '_>,
        receiver: &RecoveryTarget,
        current: Option<&[u8]>,
        target: &[u8],
    ) -> Result<UpdateOutcome>;
}

/// Backend-owned recovery state retained from preparation through confirmation.
pub trait PreparedRecoveryUpdate: Send {
    /// Execute the exact prepared bytes, then verify the written firmware.
    fn execute(&self, dev: &mut WriteDevice<'_>) -> Result<UpdateOutcome>;
}

/// Firmware inspection.
pub trait InspectFacet {
    /// Inspect a firmware file, or `None` when it is not this backend's format.
    fn inspect(
        &self,
        source: String,
        bytes: &[u8],
        control: &Control,
    ) -> Option<Result<Inspection>>;
    /// The live drive state shown beside a captured inspection.
    fn live_state(&self, dev: &mut ReadDevice<'_>) -> LiveState;
    /// Whether a live capture saves the raw drive read (the dump) rather than
    /// a backup. A raw read keeps the per-unit data a backup resets.
    fn raw_capture(&self) -> bool {
        false
    }
}

#[cfg(test)]
mod outcome_tests {
    use super::*;

    #[test]
    fn completion_requires_identity_and_readback_and_final_firmware() {
        let mut evidence = UpdateEvidence {
            target_started: true,
            target_identity: String::new(),
            verified_regions: vec!["kernel".into()],
            unverified_regions: vec![],
            completed_stages: vec!["target".into()],
            temporary_firmware: false,
        };
        let missing_identity = UpdateOutcome::Completed(evidence.clone());
        assert!(!missing_identity.fully_verified());
        assert!(!missing_identity.safe_to_probe());
        assert!(missing_identity.summary().contains("uncertain"));
        evidence.target_identity = "expected model / revision".into();
        assert!(UpdateOutcome::Completed(evidence.clone()).fully_verified());
        evidence.unverified_regions.push("normal".into());
        let partial = UpdateOutcome::Completed(evidence.clone());
        assert!(!partial.fully_verified());
        assert!(partial.safe_to_probe());
        assert!(partial.summary().contains("limited"));
        evidence.temporary_firmware = true;
        assert!(!UpdateOutcome::Completed(evidence).safe_to_probe());
    }
}
