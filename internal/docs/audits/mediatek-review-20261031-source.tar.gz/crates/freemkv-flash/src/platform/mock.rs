//! A programmable in-memory [`ScsiDevice`] for host-independent tests.
//!
//! `MockScsiDevice` lets tests answer specific CDBs with canned data or errors
//! and records every command_out (write) it receives, so the drive/flash logic
//! can be exercised on any OS (including macOS CI) without real hardware.

use std::collections::HashMap;

use anyhow::{bail, Result};

use super::{MediumStatus, ScsiDevice};

type Matcher = Box<dyn Fn(&[u8]) -> bool + Send + Sync>;

enum Outcome {
    /// Return these exact bytes (as-is, ignoring alloc_len).
    Data(Vec<u8>),
    /// Fail the command with this message.
    Fail(String),
    Sense(u8, u8, u8),
}

struct Rule {
    matcher: Matcher,
    outcome: Outcome,
    after_stream: bool,
}

/// A mock SCSI device driven by a list of CDB-matching rules.
///
/// Unmatched `command_in` calls return an all-zero buffer of the requested
/// length; unmatched `command_out` calls succeed and are recorded in
/// [`MockScsiDevice::writes`].
#[derive(Default)]
pub struct MockScsiDevice {
    rules: Vec<Rule>,
    /// Every `(cdb, data)` pair received via `command_out`, in order.
    pub writes: Vec<(Vec<u8>, Vec<u8>)>,
    /// Every CDB received via `command_in`, in order.
    pub reads: Vec<Vec<u8>>,
    /// Tray/medium state [`ScsiDevice::medium_status`] reports — lets a test
    /// exercise the flash engine's refusals. Defaults to `ClosedEmpty` (flash-safe),
    /// so every existing mock flashes as a closed, empty tray.
    medium: MediumStatus,
    /// When true, WRITE BUFFER mode-6 data is captured by offset and echoed
    /// back on a matching READ BUFFER mode-6 (opt-in; off by default).
    echo: bool,
    /// Offset -> last-written bytes, populated only when `echo` is set.
    echo_store: HashMap<u32, Vec<u8>>,
    /// Optional complete mode-6 firmware read surface for backup-path tests.
    firmware_image: Option<Vec<u8>>,
    /// INQUIRY product reported alongside `firmware_image` (default `BD-RE BU40N`).
    product: Option<String>,
    base_inquiry: Option<Vec<u8>>,
}

impl MockScsiDevice {
    /// Create an empty mock (all reads zero-fill, all writes recorded).
    pub fn new() -> Self {
        Self::default()
    }

    /// Create a mock that ECHOES WRITE BUFFER mode-6 data back on the matching
    /// READ BUFFER mode-6 offset (real-write-then-real-readback semantics),
    /// instead of always zero-filling unmatched reads. `.on(...)` rules still
    /// take precedence over the echo, so a test can inject a mismatch at a
    /// specific offset.
    pub fn echoing() -> Self {
        Self {
            echo: true,
            ..Self::default()
        }
    }

    /// Expose a supplied byte-exact firmware image on mode-6 reads.
    pub fn with_firmware_image(mut self, image: Vec<u8>) -> Self {
        self.firmware_image = Some(image);
        self
    }

    /// Report `product` (at most 16 bytes) as the INQUIRY product of a mock
    /// that exposes a firmware image.
    pub fn with_product(mut self, product: &str) -> Self {
        self.product = Some(product.to_owned());
        self
    }

    /// Add a rule: when `matcher(cdb)` is true on a data-in command, return `data`.
    pub fn on<F>(mut self, matcher: F, data: Vec<u8>) -> Self
    where
        F: Fn(&[u8]) -> bool + Send + Sync + 'static,
    {
        self.rules.push(Rule {
            matcher: Box::new(matcher),
            outcome: Outcome::Data(data),
            after_stream: false,
        });
        self
    }

    /// Add a rule: when `matcher(cdb)` is true, fail the command with `msg`.
    pub fn on_fail<F>(mut self, matcher: F, msg: &str) -> Self
    where
        F: Fn(&[u8]) -> bool + Send + Sync + 'static,
    {
        self.rules.push(Rule {
            matcher: Box::new(matcher),
            outcome: Outcome::Fail(msg.to_string()),
            after_stream: false,
        });
        self
    }

    /// Return structured SCSI sense for a rejected identification command.
    pub fn on_sense<F>(mut self, matcher: F, key: u8, asc: u8, ascq: u8) -> Self
    where
        F: Fn(&[u8]) -> bool + Send + Sync + 'static,
    {
        self.rules.push(Rule {
            matcher: Box::new(matcher),
            outcome: Outcome::Sense(key, asc, ascq),
            after_stream: false,
        });
        self
    }

    /// Respond only after the first firmware-stream WRITE BUFFER command.
    pub fn on_after_stream<F>(mut self, matcher: F, data: Vec<u8>) -> Self
    where
        F: Fn(&[u8]) -> bool + Send + Sync + 'static,
    {
        self.rules.push(Rule {
            matcher: Box::new(matcher),
            outcome: Outcome::Data(data),
            after_stream: true,
        });
        self
    }

    /// Fail a read only after firmware streaming has begun.
    pub fn on_fail_after_stream<F>(mut self, matcher: F, msg: &str) -> Self
    where
        F: Fn(&[u8]) -> bool + Send + Sync + 'static,
    {
        self.rules.push(Rule {
            matcher: Box::new(matcher),
            outcome: Outcome::Fail(msg.to_string()),
            after_stream: true,
        });
        self
    }

    /// A mock that classifies as MediaTek: GET CONFIGURATION 0x010C echoes the
    /// `01 0C` feature descriptor AND the boot-ROM region at `0x003000` carries
    /// the ASCII `MT19` short-form boot banner (`"MT1959 Boot BU5..."` at
    /// offset 0 of the 32-byte region) — the MT19-family vendor signature
    /// the classifier cross-checks via `has_mt19_banner`.
    pub fn mtk() -> Self {
        let mut fd = vec![0u8; 28];
        // GET CONFIG header (8) + feature descriptor: feature code at bytes 8..10.
        fd[8] = 0x01;
        fd[9] = 0x0C;
        fd[3] = 24;
        fd[11] = 16;
        let mut boot_rom = vec![0u8; 32];
        // Short boot-banner: `MT1959 Boot BU5...` — the ASCII substring the
        // classifier's `has_mt19_banner` scans the 32-byte 0x003000 region
        // for (`MT19` — appears in both `MT1959` and `MT1939` variants).
        boot_rom[0..15].copy_from_slice(b"MT1959 Boot BU5");
        // Reading `ROM_003000_OFFSET = 0x3000` with `MODE_6` and `BUFFER_ID = 0x00`:
        // CDB[0]=0x3C, CDB[1]=mode6, CDB[2]=0x00 buffer-id, CDB[3..6]=offset(0x003000).
        let mut inquiry = vec![0; 96];
        inquiry[0] = 5;
        Self {
            base_inquiry: Some(inquiry),
            ..Self::default()
        }
        .on(
            |cdb| cdb.first() == Some(&0x46) && cdb.get(2..4) == Some(&[0x01, 0x0C][..]),
            fd,
        )
        .on(
            |cdb| {
                cdb.first() == Some(&0x3C)
                    && cdb.get(1).map(|m| m & 0x1f) == Some(0x06)
                    && cdb.get(2) == Some(&0x00)
                    && cdb.get(3..6) == Some(&[0x00, 0x30, 0x00][..])
            },
            boot_rom,
        )
    }

    /// Mark this mock as having a disc loaded, so [`ScsiDevice::medium_status`]
    /// reports `DiscPresent` (the flash engine then refuses a `--execute` flash).
    pub fn with_medium_loaded(mut self) -> Self {
        self.medium = MediumStatus::DiscPresent;
        self
    }

    /// Mark this mock's tray as open, so [`ScsiDevice::medium_status`] reports
    /// `TrayOpen` (the flash engine then refuses until the tray is closed).
    pub fn with_tray_open(mut self) -> Self {
        self.medium = MediumStatus::TrayOpen;
        self
    }

    /// A mock that classifies as Pioneer/Renesas: READ BUFFER buffer-id 0xF1
    /// succeeds with non-zero data; GET CONFIGURATION 0x010C does not echo `01 0C`.
    ///
    pub fn pioneer() -> Self {
        let mut inq = vec![0u8; 96];
        inq[0] = 5;
        inq[8..16].copy_from_slice(b"PIONEER ");
        inq[16..24].copy_from_slice(b"BDR-UD04");
        let mut f1 = vec![0u8; 48];
        f1[16..24].copy_from_slice(b"SAT 8A10");
        f1[24..28].copy_from_slice(b"ID40");
        f1[32..36].copy_from_slice(b"ID40");
        Self::new()
            .on(
                |cdb| cdb.first() == Some(&0x3C) && cdb.get(2) == Some(&0xF1),
                f1,
            )
            .on(|cdb| cdb.first() == Some(&0x12), inq)
    }

    /// Like [`Self::pioneer`] but with a `RENESAS` INQUIRY vendor, so it
    /// retains a RENESAS identity but matches no registered flash protocol.
    pub fn renesas() -> Self {
        let mut inq = vec![0u8; 96];
        inq[8..15].copy_from_slice(b"RENESAS");
        inq[15] = b' ';
        let mut f1 = vec![0u8; 48];
        f1[16..24].copy_from_slice(b"SAT 8A10");
        Self::new()
            .on(
                |cdb| cdb.first() == Some(&0x3C) && cdb.get(2) == Some(&0xF1),
                f1,
            )
            .on(|cdb| cdb.first() == Some(&0x12), inq)
    }
}

/// Decode the big-endian 24-bit offset carried in `cdb[3..6]`, shared by the
/// READ BUFFER / WRITE BUFFER (mode 6) CDBs regardless of their overall length.
fn offset24(cdb: &[u8]) -> Option<u32> {
    if cdb.len() < 6 {
        return None;
    }
    Some(((cdb[3] as u32) << 16) | ((cdb[4] as u32) << 8) | (cdb[5] as u32))
}

/// Is this a WRITE BUFFER (0x3B) or READ BUFFER (0x3C) CDB in mode 6 (the
/// register-offset stream/readback mode used by the flash sequence)?
fn is_mode6(cdb: &[u8], opcode: u8) -> bool {
    cdb.first() == Some(&opcode) && cdb.get(1).map(|m| m & 0x1f) == Some(0x06)
}

impl ScsiDevice for MockScsiDevice {
    fn command_in(&mut self, cdb: &[u8], alloc_len: usize) -> Result<Vec<u8>> {
        self.reads.push(cdb.to_vec());
        for rule in &self.rules {
            if rule.after_stream && !self.writes.iter().any(|(cdb, _)| is_mode6(cdb, 0x3B)) {
                continue;
            }
            if (rule.matcher)(cdb) {
                return match &rule.outcome {
                    Outcome::Data(d) => Ok(d.clone()),
                    Outcome::Fail(m) => bail!("{m}"),
                    Outcome::Sense(k, a, q) => {
                        return Err(
                            super::ScsiSenseError::new(*k, *a, *q, "command rejected").into()
                        )
                    }
                };
            }
        }
        if cdb.first() == Some(&0x12) {
            if let Some(inquiry) = &self.base_inquiry {
                return Ok(inquiry.clone());
            }
        }
        if self.firmware_image.is_some() && cdb.first() == Some(&0x12) {
            let mut inquiry = vec![0u8; alloc_len];
            if inquiry.len() >= 36 {
                inquiry[0] = 5;
                inquiry[4] = (inquiry.len() - 5) as u8;
                inquiry[8..16].copy_from_slice(b"HL-DT-ST");
                inquiry[16..32].fill(b' ');
                inquiry[16..27].copy_from_slice(b"BD-RE BU40N");
                inquiry[32..36].copy_from_slice(b"1.00");
                // A programmed descriptor becomes the running identity. Explicit
                // INQUIRY rules and product overrides still simulate stale/wrong startup.
                let descriptor = self
                    .echo_store
                    .get(&0x1ec000)
                    .map(Vec::as_slice)
                    .or_else(|| self.firmware_image.as_ref()?.get(0x1ec000..));
                if let Some(identity) = descriptor.and_then(|d| d.get(..28)) {
                    if identity[..8]
                        .iter()
                        .all(|b| b.is_ascii_graphic() || *b == b' ')
                        && identity[..8].iter().any(u8::is_ascii_alphanumeric)
                    {
                        inquiry[8..36].copy_from_slice(identity);
                    }
                }
                if let Some(product) = &self.product {
                    inquiry[16..32].fill(b' ');
                    inquiry[16..16 + product.len()].copy_from_slice(product.as_bytes());
                }
            }
            return Ok(inquiry);
        }
        if self.echo && is_mode6(cdb, 0x3C) {
            if let Some(off) = offset24(cdb) {
                if let Some(stored) = self.echo_store.get(&off) {
                    let mut out = stored.clone();
                    out.resize(alloc_len, 0);
                    return Ok(out);
                }
            }
        }
        if is_mode6(cdb, 0x3C) {
            if let (Some(image), Some(off)) = (&self.firmware_image, offset24(cdb)) {
                let start = off as usize;
                if let Some(slice) = image.get(start..start.saturating_add(alloc_len)) {
                    return Ok(slice.to_vec());
                }
            }
        }
        if cdb.first() == Some(&0x46) && cdb.len() >= 4 && alloc_len == 28 {
            let mut data = vec![0u8; alloc_len.min(28)];
            let length = (data.len() - 4) as u32;
            data[..4].copy_from_slice(&length.to_be_bytes());
            data[8..10].copy_from_slice(&cdb[2..4]);
            data[11] = (data.len() - 12) as u8;
            data[12..].fill(b'S');
            return Ok(data);
        }
        if cdb.first() == Some(&0x12) && alloc_len >= 36 {
            let mut data = vec![0u8; alloc_len];
            data[4] = (alloc_len - 5) as u8;
            return Ok(data);
        }
        Ok(vec![0u8; alloc_len])
    }

    fn command_out(&mut self, cdb: &[u8], data: &[u8]) -> Result<()> {
        for rule in &self.rules {
            if (rule.matcher)(cdb) {
                if let Outcome::Fail(m) = &rule.outcome {
                    bail!("{m}");
                }
            }
        }
        if self.echo && is_mode6(cdb, 0x3B) {
            if let Some(off) = offset24(cdb) {
                self.echo_store.insert(off, data.to_vec());
            }
        }
        self.writes.push((cdb.to_vec(), data.to_vec()));
        Ok(())
    }

    fn medium_status(&mut self) -> Result<MediumStatus> {
        Ok(self.medium)
    }

    fn describe(&self) -> String {
        "mock://in-memory".to_string()
    }
}
