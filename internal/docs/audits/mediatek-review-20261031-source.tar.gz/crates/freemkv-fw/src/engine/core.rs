//! MT1959 grounded find/build/patch — the *knowledge* the dumb [`thumb_asm`]
//! verbs are pointed at, all **derived from the drive's own code**, never
//! hardcoded.
//!
//! Every fact used to build the freemkv firmware is recovered from a consumer in
//! the image and cross-checked, so a wrong fact fails loudly at the find rather
//! than silently on hardware:
//!
//! * the command-dispatch record format is proven by the **scanner** (the code
//!   that reads the table): it does `ldrb [rec+1]`=flags, `ldrb [rec]`=opcode,
//!   `ldr [rec+4]`=handler — so records are `opcode@0 / flags@1 / handler@4`;
//! * `cdb_base` is the literal the scanner loads to read the incoming CDB;
//! * the sense-setter is the routine the scanner tail-calls to raise a sense;
//! * the `0x3C` handler is the unique live record for that opcode, its handler
//!   pointer cross-checked to land on a real `push {…,lr}` prologue.
//!
//! The freemkv command is a hijack of the standard `READ BUFFER` (`0x3C`)
//! handler, discriminated by an OEM-unused mode: `cdb[1]==KNOCK_MODE` plus a
//! knock at `cdb[2..4]`. On a match the handler dispatches on the sub-function
//! (`cdb[4]`) and returns a data payload via the drive's own response path
//! (byte-writer + commit); on a miss it tail-calls the original handler, so OEM
//! behaviour is byte-identical. `flags` stays `0x01` — which on hardware is a
//! drive-*ready* gate, NOT a media gate: the command answers with no disc.

use anyhow::{anyhow, bail, ensure, Context, Result};

use super::lever::{LeverId, LeverReport, ModifyReport, Validation};
use super::mt1959::Mt1959Engine;
use crate::abi;
use crate::boot::BootSettings;
use crate::family::{Capability, ChipInfo, MediaClass};
use thumb_asm::{self as thumb, Asm, BranchKind, CommandRecord};

// The wire frame (opcode / mode / knock / identity sense) is defined once in
// `crate::abi` and imported here — the engine emits exactly what the host ABI
// describes, so the two can never drift.

/// Record flags on the live `0x3C` record. `0x01` is a drive-*ready* gate (NOT a
/// media gate — proven on hardware: the command answers with no disc), which is
/// exactly how OEM ships it. Engine-specific (a property of this firmware's
/// dispatch table), so it lives here rather than in the wire ABI.
pub const LIVE_FLAGS: u8 = 0x01;

/// Chip-family flag value marking a chain record in the dispatch table.
pub(crate) const CHAIN_FLAG: u8 = 0x04;
/// Flag value marking a segment terminator.
pub(crate) const TERM_FLAG: u8 = 0x03;
/// Record stride in bytes.
pub(crate) const STRIDE: usize = 8;
/// Where injected code may live (past the loader); the scanner region and
/// beyond. Free space is searched from here up.
pub(crate) const CODE_REGION_START: usize = 0x0000_9c00;

/// Bytes cleared in the response buffer before writing a reply (so no stale
/// buffer data leaks into the padding beyond the payload).
pub(crate) const CLEAR_LEN: u8 = 64;
/// Number of feature flags (Feature ids `0x01..=0x06`). Sizes the SRAM flag
/// table, bounds the [`abi::Verb::Reset`] sweep, and sizes the
/// [`abi::Verb::Identity`] feature-state table appended after the magic+version.
/// (Was `7` before the ABI consolidation: wire id `0x07` — the retired `Bus`
/// feature — is now unassigned; `Feature::Encryption` at `0x06` is the sole
/// content-encryption toggle.)
pub(crate) const NUM_FEATURES: u8 = 6;

/// The SRAM (on-chip working RAM) window scanned by [`Mt1959Engine::find_free_sram_cell`]
/// and holding every runtime flag/scratch cell.
pub(crate) const SRAM_LO: u32 = 0x0200_0000;

/// Conservative SRAM placement ceiling inferred from the owned MT1959 capture
/// and write-persistence observations. This is not a documented memory map or
/// evidence that every MT1939/MT1959 model has the same runtime layout.
/// Static placement checks stay below this ceiling on both paths.
pub(crate) const SRAM_END: u32 = 0x0200_1a00;

/// Modern flag-table location supported by the owned BU40N runtime capture.
/// The captured gap was `0x02000e3c..0x02000f08`; each image is additionally
/// checked for observed static references with four-byte guards. Capture and
/// static absence do not prove this address is unused under every workload or
/// model. Classic firmware has real uses here and selects a separate candidate.
/// See `research/libredrive/mtk/SRAM_FLAG_CELL.md` for the capture's limits.
pub(crate) const FLAG_TABLE_BASE: u32 = 0x0200_0e40;

/// TEMPORARY flash-write probe ([`abi::Verb::FlashWrite`]) constants.
///
/// The OEM flash PROGRAM routine (thumb): `program(r0=src, r1=dest, r2=len,
/// r3=op)`. `op=1` = erase-aligned read-modify-write. `dest` (r1) is a DIRECT
/// flash byte offset; `src` (r0) is a DIRECT memory pointer (`ldrb [r0+i]`). The
/// OEM HRL wrapper (0x1354a0) calls it `r0=0x30000`, `r1=0x1e0000/0x1d8000`,
/// `r2=0x8000`, `r3=1` — proven. Its address is NOT hardcoded: it is recovered
/// per image by [`Mt1959Engine::find_flash_program`] (`0x13da2a` on BU40N 1.00),
/// so the probe generalizes across the MediaTek corpus instead of pinning one VA.
///
/// Two family-invariant constants disambiguate the PROGRAM routine from a decoy
/// erase routine that shares its prologue: the mailbox doorbell cell and the
/// controller register base, both materialized in the PROGRAM routine's literal
/// pool on every owned MT19xx image. Only the true PROGRAM routine's pool ALSO
/// carries a `0x01ff_xxxx` descriptor pointer (the decoy lacks it), which is the
/// third leg of the match — see [`Mt1959Engine::find_flash_program`].
pub(crate) const FLASH_MAILBOX: u32 = 0x0200_1200;
pub(crate) const FLASH_CONTROLLER: u32 = 0x0400_2240;

/// Prologue signature of the OEM flash PROGRAM routine: `push {r0-r7,lr}; movs
/// r6,r1; movs r5,r2; movs r4,r3; cmp r3,#4; sub sp,#4; bcc <…>`. Matches TWICE
/// on a BU40N image (the true PROGRAM routine at `0x13da2a` plus a decoy erase
/// routine at `0x8faa` that shares the prologue); [`Mt1959Engine::find_flash_program`]
/// disambiguates by the literal-pool contents (mailbox + controller + descriptor).
pub(crate) const FLASH_PROGRAM_SIG: &[(u16, u16)] = &[
    (0xB5FF, 0xFFFF), // push {r0,r1,r2,r3,r4,r5,r6,r7,lr}
    (0x000E, 0xFFFF), // movs r6,r1        (dest)
    (0x0015, 0xFFFF), // movs r5,r2        (len)
    (0x001C, 0xFFFF), // movs r4,r3        (op)
    (0x2B04, 0xFFFF), // cmp  r3,#4
    (0xB081, 0xFFFF), // sub  sp,#4
    (0xD302, 0xFFFF), // bcc  <…>
];

/// Number of pool bytes past the PROGRAM routine's entry scanned for the mailbox /
/// controller / descriptor literals that identify it. The constant table of a
/// routine this size sits within its first ~1 KiB; 0x400 covers it on every owned
/// image.
pub(crate) const FLASH_POOL_SPAN: usize = 0x400;

/// Signature of the MT1959 boot-init hook site — the main-task prologue that reads
/// the boot-mode word and branches on it: `ldr r0,[pc,#imm]; push {r4,r5,r6,lr};
/// ldr r0,[r0,#0x18]; lsls r0,r0,#0x18; bmi <…>; movs r1,#0; movs r0,#0`. The
/// leading `ldr r0,[pc,#imm]` immediate varies per build, so its low byte is masked
/// (`?? 48`). This signature ANCHORS the boot-init hook, but the detour is NOT
/// written here: the `bmi` at `anchor+8` is the cold/warm-boot split, and the cold
/// arm (`movs r1,#0; movs r0,#0; bl <bss/SRAM clear>`) ZEROES the flag table before
/// the two paths rejoin. [`Mt1959Engine::emit_boot_init`] therefore follows the
/// `bmi` to its convergence target — the `bl <orig_init>` both paths reach AFTER the
/// clear — and detours THAT, so the boot stub's `0xFF` flag write is never wiped.
/// [`Mt1959Engine::find_boot_init`] still resolves this anchor's `anchor+4`
/// (the boot-status reload, left untouched). Unique (n==1) on all 68 owned MT1959 images;
/// present on the 17 MT1939-classic images only via [`BOOT_INIT_SIG_CLASSIC`]
/// (an older prologue whose second halfword differs), so the modern shape returns
/// zero there and [`Mt1959Engine::find_boot_init`] falls back.
pub(crate) const BOOT_INIT_SIG: &[(u16, u16)] = &[
    (0x4800, 0xFF00), // ldr  r0,[pc,#imm]   (boot-status base; imm varies → masked)
    (0xB570, 0xFFFF), // push {r4,r5,r6,lr}
    (0x6980, 0xFFFF), // ldr  r0,[r0,#0x18]  ← hook site (anchor+4)
    (0x0600, 0xFFFF), // lsls r0,r0,#0x18
    (0xD403, 0xFFFF), // bmi  <…>
    (0x2100, 0xFFFF), // movs r1,#0
    (0x2000, 0xFFFF), // movs r0,#0
];

/// MT1939-classic variant of the boot-init hook site. RE-derived from the classic
/// lineage (research/hoard-campaign), where the main-task prologue reads the
/// boot-mode word through the SAME `ldr r0,[r0,#0x18]; lsls r0,r0,#0x18` reload as
/// modern, but the surrounding shape differs: the `push {r4,r5,r6,lr}` of
/// [`BOOT_INIT_SIG`] is replaced by a `subs r0,#0xc0` discriminator, and the
/// trailing `movs r1,#0; movs r0,#0` pair is absent, so the modern signature
/// misses entirely on classic images. The four replayed/replaced bytes at the
/// hook site are `80 69 00 06` (`ldr r0,[r0,#0x18]; lsls r0,r0,#0x18`), byte-for-
/// byte identical to modern — so the boot-init stub itself is unchanged; only the
/// finder needs a second shape to resolve the site.
///
/// The hook site is `anchor+4` (index 2, the `ldr r0,[r0,#0x18]`), exactly as for
/// [`BOOT_INIT_SIG`]. Capability base `0x0400_2040`, boot-mode word `@0x0400_2058`.
///
/// This classic site is a called leaf helper. Production emission requires its
/// unique caller, resolved by [`classic_boot_init_caller`]. Hardware call-order
/// remains unconfirmed. The helper also matches modern images, so
/// [`Mt1959Engine::find_boot_init`] tries the modern shape first and uses this
/// fallback only when the modern shape has no matches.
pub(crate) const BOOT_INIT_SIG_CLASSIC: &[(u16, u16)] = &[
    (0x4800, 0xFF00), // ldr  r0,[pc,#imm]   (boot-status base; imm varies → masked)
    (0x38C0, 0xFFFF), // subs r0,#0xc0       (classic discriminator)
    (0x6980, 0xFFFF), // ldr  r0,[r0,#0x18]  ← hook site (anchor+4)
    (0x0600, 0xFFFF), // lsls r0,r0,#0x18
    (0xD400, 0xFF00), // bmi  <…>            (displacement varies → masked)
];

/// SAFETY BOUND for the flash-write probe: the destination offset MUST satisfy
/// `FLASHWRITE_ALLOW_LO <= off < FLASHWRITE_ALLOW_HI`, else the handler refuses
/// (error status word, PROGRAM routine NOT called).
///
/// The window is the NV block `0x1EA000..0x1EB000` — the SAVE home. Corpus-proven
/// (all 118 OEM images) as the one always-writable free zone:
///   * OEM-WRITTEN in every one of the 118 images (the block holds the OEM region /
///     RPC-2 record at `0x1EA4B0`), so the flash controller UNLOCKS this block on
///     every drive — a write here actually PERSISTS on hardware;
///   * its head `0x1EA000..0x1EA4B0` (1200 bytes) is blank (`0xFF`) in every image —
///     free scratch that clobbers no OEM data;
///   * OUTSIDE CMAC coverage in every image — the highest CMAC-covered byte across
///     the corpus is `0x1CFFFF`, so this block clears it by a wide margin.
///
/// This REPLACES the earlier `0x1ED000..0x1EF000` (and before it `0x1D0000`) windows,
/// which the full-corpus block-writability scan proved are ALWAYS-BLANK / never
/// OEM-written — i.e. controller-LOCKED: writes there do NOT persist (the earlier
/// on-hardware 1-byte probe that read back `0xFF` failed for exactly this reason).
/// The OEM PROGRAM routine reached here is the drive's GENERAL flash programmer (28
/// callers; the HRL wrapper is only one), and `op=1` is a neighbour-preserving
/// erase-block read-modify-write, so a program in the blank head cannot disturb the
/// OEM region record lower in the same block.
pub(crate) const FLASHWRITE_ALLOW_LO: u32 = 0x001E_A000;
pub(crate) const FLASHWRITE_ALLOW_HI: u32 = 0x001E_B000;
const _: () = assert!(FLASHWRITE_ALLOW_LO < FLASHWRITE_ALLOW_HI);
// Stay inside the corpus-proven-unlocked NV block, 4-KiB erase-sector aligned —
// compile-time proven here.
const _: () = assert!(FLASHWRITE_ALLOW_LO >= 0x001E_A000);
const _: () = assert!(FLASHWRITE_ALLOW_HI <= 0x001E_B000);
const _: () = assert!(FLASHWRITE_ALLOW_LO.is_multiple_of(0x1000));
const _: () = assert!(FLASHWRITE_ALLOW_HI.is_multiple_of(0x1000));

/// SAVE home: base of the corpus-universal NV block. [`abi::Verb::Save`] programs the
/// live flag table verbatim to this flash offset; [`abi::RESET_TO_FLASH`]
/// loads it back explicitly. Boot always uses the image’s baked settings. The engine resolves this per image by SIGNATURE via
/// [`Mt1959Engine::find_nv_block`] (the region record `00 04 05` at block+0x4B0 with a
/// blank head) — it is NOT a hardcoded build input. This constant is the corpus-
/// expected value (`0x1EA000` on all 118), used by the compile-time FlashWrite bound
/// and unit tests; `build_handler` asserts the signature-resolved block agrees with
/// this window on every build. The head is blank in every image and the block is
/// controller-unlocked (OEM writes the region record at `+0x4B0`), so `op=1` RMW here
/// persists our bytes while preserving that OEM record.
pub(crate) const SAVE_HOME: u32 = 0x001E_A000;
const _: () = assert!(SAVE_HOME >= FLASHWRITE_ALLOW_LO && SAVE_HOME < FLASHWRITE_ALLOW_HI);

/// SAVE payload length, including the saved marker in slot zero. Explicit
/// RESET_TO_FLASH uses this record; boot never overlays it onto image settings.
pub(crate) const SAVE_LEN: u8 = NUM_FEATURES + 1;

/// Shipping defaults used by existing golden tests. Production emitters take
/// validated per-image settings from the shared boot model.
#[cfg(test)]
pub(crate) const DEFAULT_FLAGS: [u8; NUM_FEATURES as usize + 1] = BootSettings::standard().flags();

/// SAVE marks a configuration for explicit RESET_TO_FLASH reload. An erased
/// marker falls back to the image defaults. The record never overrides boot.
pub(crate) const NV_SAVED_MARKER: u8 = 0x01;

/// Byte offset from [`FLAG_TABLE_BASE`] of the 1-byte SRAM scratch cell the
/// flash-write probe stages its source byte in before calling the PROGRAM
/// routine (`r0 = &scratch`). Sits in the same validated 204-byte free hole as
/// the flag table, past the 7-byte flag table (slots `0x00..=0x06`), guard-
/// checked per image by [`Mt1959Engine::assert_sram_cell_free`].
pub(crate) const FLASHWRITE_SCRATCH_OFF: u32 = 0x10;

/// Volatile U/5 classification cache for a qualified legacy media conversion.
/// It is not a feature or saved configuration byte. A conversion must check its
/// SRAM placement and bind both boot initialization and native media reset.
pub(crate) const UHD_IDENTITY_OFF: u32 = 0x08;
const _: () = assert!(UHD_IDENTITY_OFF > NUM_FEATURES as u32);
const _: () = assert!(UHD_IDENTITY_OFF < FLASHWRITE_SCRATCH_OFF);

/// Distinct status word the flash-write probe writes to the reply when it
/// REFUSES an out-of-allowlist offset (PROGRAM routine not called). ASCII
/// `"REFU"` — clearly not a PROGRAM return code, so the host can tell a refusal
/// from a real program status.
pub(crate) const FLASHWRITE_REFUSE_STATUS: u32 = 0x5245_4655;

/// Signature of the read-ramp CEILING gate inside the per-READ ramp writer
/// (`0x1bb22` on both OEM 1.00 and MK 1.03). The bare `cmp #0x32` is ambiguous
/// (the `0x32` "high-speed band" threshold has many consumers), so the full
/// four-instruction shape is matched and proven unique. The gate `cmp` is at
/// `match+4`, its `bhi <ramp-exit>` at `match+6`, and the ramp continues at
/// `match+8`. The Speed (0x02) detour replaces the `cmp/bhi` (4 bytes at
/// `match+4`) with a `bl` to a flag-gated stub; the ramp itself is UNTOUCHED.
pub(crate) const SPEED_GATE_SIG: &[(u16, u16)] = &[
    (0x4900, 0xFF00), // ldr r1,[pc,#imm]  (speed_index SRAM cell literal)
    (0x780A, 0xFFFF), // ldrb r2,[r1]       r2 = speed_index
    (0x2A32, 0xFFFF), // cmp r2,#0x32       ramp self-ceiling band
    (0xD800, 0xFF00), // bhi <ramp-exit>    stop ramping once past the ceiling
];

/// `r0`-register variant of [`SPEED_GATE_SIG`]. Some builds (LG BU40N 1.04/1.05
/// "Original Flasher"/-INTM, and the whole NB-class BP50NB40/BP55EB40/WP50NB40
/// line) load the ramp `speed_index` into `r0` instead of `r2`; the gate is
/// otherwise byte-identical (same `ldr r1,[pc]` cell, same `#0x32` band, same
/// `bhi`), so the gate `cmp` is still at `match+4` and `bhi` at `match+6`.
///
/// PROVEN (research/hoard-campaign-2026-09-03): unique per image on all 15
/// affected MT1959 images, never ambiguous, never overlapping [`SPEED_GATE_SIG`],
/// and **zero matches** in the BU40N 1.00 KAT base (which matches the original) —
/// original-first keeps the KAT byte-identical. `r0` is redefined immediately
/// after the gate (`ldrb r0,[r5,#5]`), i.e. DEAD at both the fall-through and
/// ramp-exit targets, which is what lets the variant stub use it as scratch.
pub(crate) const SPEED_GATE_SIG_R0: &[(u16, u16)] = &[
    (0x4900, 0xFF00), // ldr  r1,[pc,#imm]  (speed_index SRAM cell literal)
    (0x7808, 0xFFFF), // ldrb r0,[r1]       r0 = speed_index (variant register)
    (0x2832, 0xFFFF), // cmp  r0,#0x32      ramp self-ceiling band
    (0xD800, 0xFF00), // bhi  <ramp-exit>
];

/// Signature of the AACS AKE per-AGID state writers at the tail of the
/// key-exchange step handler (`0x136594` on 1.00, `0x13697c` on 1.03 MK —
/// byte-identical). The two writers sit back-to-back: the SUCCESS writer sets the
/// per-AGID state to `6` (AKE authenticated), the RESET writer sets it to `1`
/// (auth failed). Reaching state `6` is the whole VID gate. The RESET writer is the
/// cert accept/reject decision: on a failed host-cert verify the OEM lands here and
/// resets to `1`. Raw Read (0x04) detours the RESET writer's `movs r1,#1; b <back>`
/// (4 bytes at `match+12`) to a flag-gated stub that sets `6` (accept) when
/// `flag[Ake]==STATE_OFF` (null AKE), replicating the OEM `1` when off. Proven unique; the two
/// `b <back>` displacements are masked (`0xE000/0xF800`). `movs r1,#6` is unique in
/// the AACS window, which anchors the match.
pub(crate) const AKE_GATE_SIG: &[(u16, u16)] = &[
    (0x7AA8, 0xFFFF), // ldrb r0,[r5,#0xa]   AGID byte
    (0x0980, 0xFFFF), // lsrs r0,r0,#6       r0 = AGID
    (0x2106, 0xFFFF), // movs r1,#6          success: state 6 (authenticated)
    (0xE000, 0xF800), // b <shared BL set_agid_state>
    (0x7AA8, 0xFFFF), // ldrb r0,[r5,#0xa]
    (0x0980, 0xFFFF), // lsrs r0,r0,#6       r0 = AGID
    (0x2101, 0xFFFF), // movs r1,#1          reset: state 1  ← detour site (match+12)
    (0xE000, 0xF800), // b <shared BL set_agid_state>
];

/// NB-class (LG BP50NB40 / BP55EB40 / WP50NB40 portable) variant of the AKE
/// accept gate. RE'd from `HL-DT-ST_BP50NB40_N1.01` (anchor `0x13405a`),
/// proven-unique across the NB corpus and 0-match on every BU40N image. Two
/// differences from [`AKE_GATE_SIG`] that make the original miss and require a
/// distinct detour: the AGID byte is read via `r4` (not `r5`), and — critically —
/// the accept (`movs r1,#6`) and reject (`movs r1,#1`) arms **converge on a
/// single shared `bl set_agid_state`** at `anchor+12` (the accept arm's `b` lands
/// there) instead of each ending in its own `b`. So the reject writer is a bare
/// 2-byte `movs r1,#1` at `anchor+10` and `anchor+12` is the shared `bl`. Raw
/// Read detours that shared `bl` (see [`Mt1959Engine::build_ake_stub_nb`]) — the
/// stub must PRESERVE `r1` when the flag is off (the accept arm passes through it
/// too), forcing `6` only when `flag[Ake]==STATE_OFF`.
pub(crate) const AKE_GATE_SIG_NB: &[(u16, u16)] = &[
    (0x7AA0, 0xFFFF), // ldrb r0,[r4,#0xa]   AGID byte (r4, not r5)
    (0x0980, 0xFFFF), // lsrs r0,r0,#6       r0 = AGID   (accept arm)
    (0x2106, 0xFFFF), // movs r1,#6          accept: state 6
    (0xE000, 0xF800), // b <shared bl @ +12>
    (0x0980, 0xFFFF), // lsrs r0,r0,#6       reject arm (no second ldrb)
    (0x2101, 0xFFFF), // movs r1,#1          reject: state 1   (bare, 2 bytes)
                      // anchor+12 = `bl set_agid_state`, the shared join both arms reach ← detour site
];

/// NB-class **`1.V5`** variant of the AKE accept gate. RE'd from the two
/// `WH16NS58 1.V5` images (`unMK_WH16NS58_1.V5_N004900` + its MK sibling,
/// anchor `0x13a254`), where BOTH [`AKE_GATE_SIG`] and [`AKE_GATE_SIG_NB`] match
/// 0×. It is a hybrid of the two shapes:
///
/// * like [`AKE_GATE_SIG_NB`], the AGID byte is read via `r4` (not `r5`) and the
///   accept (`movs r1,#6`) and reject (`movs r1,#1`) arms **converge on one
///   shared `bl set_agid_state`** (the accept arm's `b` lands on it) rather than
///   each ending in its own `b`;
/// * unlike `AKE_GATE_SIG_NB` — and like the desktop [`AKE_GATE_SIG`] — the
///   reject arm **re-reads** the AGID byte (`ldrb r0,[r4,#0xa]; lsrs r0,r0,#6`)
///   instead of falling straight into a bare `lsrs`. That extra `ldrb` (2 bytes)
///   pushes the reject writer to `anchor+12` and the shared `bl` to `anchor+14`.
///
/// PROVEN (fleet scan, `[0x130000,0x140000)`): unique per image (n=1) on exactly
/// the 2 `1.V5` images, **zero matches** on every other hoard image, and neither
/// `AKE_GATE_SIG` nor `AKE_GATE_SIG_NB` matches the `1.V5` images — so the three
/// variants never overlap and existing coverage is untouched. The Raw Read detour
/// replaces the shared `bl` at `anchor+14` and reuses the NB stub verbatim
/// ([`Mt1959Engine::build_ake_stub_nb`]): both arms reach the join with `r1`
/// already set, so the stub must PRESERVE `r1` when the flag is off.
pub(crate) const AKE_GATE_SIG_NB_V5: &[(u16, u16)] = &[
    (0x7AA0, 0xFFFF), // ldrb r0,[r4,#0xa]   AGID byte (r4)   (accept arm)
    (0x0980, 0xFFFF), // lsrs r0,r0,#6       r0 = AGID
    (0x2106, 0xFFFF), // movs r1,#6          accept: state 6
    (0xE000, 0xF800), // b <shared bl @ +14>
    (0x7AA0, 0xFFFF), // ldrb r0,[r4,#0xa]   reject arm RE-READS (unlike NB)
    (0x0980, 0xFFFF), // lsrs r0,r0,#6       r0 = AGID
    (0x2101, 0xFFFF), // movs r1,#1          reject: state 1  ← reject writer @ anchor+12
                      // anchor+14 = `bl set_agid_state`, the shared join both arms reach ← detour site
];

/// Signature of the OEM REPORT KEY key-format-8 (RPC state) emitter tail
/// (`0x119890` on 1.00, `0x119a84` on 1.03) — the byte-for-byte identical run
/// that marshals the 8-byte RPC-state frame into the response FIFO. RPCScheme is
/// hardcoded to `1` (RPC-2) via `r4`; the `frame[4]` store `strb r2,[r0,#8]` is
/// at `match+6`. Region-free (0x03) detours from there (4 bytes at `match+6`,
/// consuming the following `mov r3,sp` too) to a flag-gated stub that re-emits
/// `frame[4..7]` — zeroing TypeCode/RegionMask/RPCScheme for a golden-MK RPC-1
/// frame when set, OEM otherwise. Proven unique per image. (`r1==0`, `r4==1`.)
pub(crate) const REGION_EMIT_SIG: &[(u16, u16)] = &[
    (0x466B, 0xFFFF), // mov  r3,sp
    (0x789B, 0xFFFF), // ldrb r3,[r3,#2]   s2
    (0x18D2, 0xFFFF), // adds r2,r2,r3
    (0x7202, 0xFFFF), // strb r2,[r0,#8]   frame[4] = TypeCode/resets/changes ← detour
    (0x466B, 0xFFFF), // mov  r3,sp        (consumed by the 4-byte bl)
    (0x78DA, 0xFFFF), // ldrb r2,[r3,#3]   s3 (RegionMask source, re-read by the stub)
    (0x7202, 0xFFFF), // strb r2,[r0,#8]   frame[5] = RegionMask
    (0x7204, 0xFFFF), // strb r4,[r0,#8]   frame[6] = RPCScheme (r4==1)
    (0x7201, 0xFFFF), // strb r1,[r0,#8]   frame[7] = 0 (reserved)
    (0xBD18, 0xFFFF), // pop  {r3,r4,pc}   emitter epilogue (replicated by the stub)
];

/// Byte offset of the downgrade-enable (DE) byte within the ASCII drive-descriptor
/// record ([`crate::family::DESCRIPTOR_OFFSET`]). The record's family tag
/// `"MTEKMT19.."` sits at `+0x34`; a within-family variant marker (`0x78/0x58/
/// 0x18/0x38`, NOT an invariant) sits at `+0x50`; the DE slot is at `+0x56`.
/// Verified across the owned MT1959 image set.
pub(crate) const DE_BYTE_OFF: usize = 0x56;

/// Signature of `SetDiscMode`'s prologue — the read-datapath disc-mode dispatcher
/// (`0x43cb0` on 1.00). Its `subs r3,r4,#3` feeds a jump-table dispatch that
/// programs the scramble/sector MMIO. Unique per image. (`bl` displacement masked.)
pub(crate) const SETDISCMODE_SIG: &[(u16, u16)] = &[
    (0xB510, 0xFFFF), // push {r4,lr}
    (0x0004, 0xFFFF), // movs r4,r0        (r4 = mode)
    (0x2000, 0xFFFF), // movs r0,#0
    (0xF000, 0xF800), // bl <early-init>   hw1
    (0xD000, 0xD000), // bl                hw2
    (0x1EE3, 0xFFFF), // subs r3,r4,#3     (mode-3 jump-table index)
];

/// Signature of the flash-resident **Host Revocation List (HRL) lookup** routine
/// (`0x13550e` on BU40N 1.00; relocated per version — e.g. `0x13569a` on BU40N
/// 1.02 / BU50N, `0x134cca` on WH16NS60, `0x138e9a` on BE16NU50 — all
/// byte-identical in shape across the MT1959 **and** MT1939 lineages). Returns
/// `1`=host revoked, `2`=blank/`0xFFFF` sentinel, `0`=clean. The cert-send path
/// calls it and then tests `cmp r0,#0; bne <revoke>` at one or more sites; the
/// HRL-skip detour (`flag[Feature::Hrl]==STATE_OFF`) forces the clean (fall-through)
/// path at those sites.
///
/// The fingerprint is **version-invariant by FUNCTION BODY**, not by the BU40N
/// prologue alone: `push {r0,r1,r4-r7,lr}; sub sp,#0xc; ldr r0,[sp,#0xc]; movs
/// r4,r1; bl <count-reader>; movs r7,r0; movs r0,r4; bl <…>; str r0,[sp,#8]; adds
/// r0,r4,#4`. The three `bl` displacements are masked; the surrounding body ops
/// are exact. Extending past the prologue is load-bearing: the bare 6-halfword
/// prologue also occurs (once) on non-AACS DVD-only drives and would false-match,
/// whereas the 12-halfword body is UNIQUE per image and matches on exactly the 91
/// AACS-capable images (parity with the peer AKE/Bus/UHD/Region cert-path gates),
/// 0 on the DVD/CD-only parts. Proven UNIQUE across the 118-image OEM corpus in
/// `[0x130000,0x140000)`; the sibling AACS helper called alongside it at the same
/// cert sites (`push {r4,r5,r6,lr}` prologue) does NOT match. Verified against the
/// capstone traces of BU40N 1.00, BU50N, WH16NS60, and BE16NU50.
pub(crate) const HRL_LOOKUP_SIG: &[(u16, u16)] = &[
    (0xB5F3, 0xFFFF), // push {r0,r1,r4,r5,r6,r7,lr}
    (0xB083, 0xFFFF), // sub  sp,#0xc
    (0x9803, 0xFFFF), // ldr  r0,[sp,#0xc]
    (0x000C, 0xFFFF), // movs r4,r1
    (0xF000, 0xF800), // bl   <count-reader>  hi
    (0xF800, 0xF800), //                      lo
    (0x0007, 0xFFFF), // movs r7,r0
    (0x0020, 0xFFFF), // movs r0,r4
    (0xF000, 0xF800), // bl   <…>             hi
    (0xF800, 0xF800), //                      lo
    (0x9002, 0xFFFF), // str  r0,[sp,#8]
    (0x1D20, 0xFFFF), // adds r0,r4,#4
];

/// The [`abi::Verb::Identity`] reply lead-in: `"freemkv <version>"` (magic +
/// crate version). The live feature-state table (6 bytes, `flag[0x01..=0x06]`)
/// is appended after this by the handler at runtime.
pub(crate) fn identity_blob() -> Vec<u8> {
    format!(
        "{} {}",
        std::str::from_utf8(abi::RESP_MAGIC).unwrap_or("freemkv"),
        env!("CARGO_PKG_VERSION")
    )
    .into_bytes()
}

/// Resolve the pc-relative literal an `ldr rX, [pc, #imm]` at file offset `at`
/// loads (`None` if the halfword there is not such a load).
pub(crate) fn pc_literal(image: &[u8], at: usize) -> Option<u32> {
    let ins = thumb_asm::isa::decode_at(image, at)?;
    if ins.len() != 2 {
        return None;
    }
    thumb_asm::analysis::literal_value(image, at)
}

/// Observed SRAM references, including direct data/ARM literals and decoded
/// Thumb aliases across local control flow. A clean static footprint alone is
/// not evidence of runtime ownership or writability.
#[cfg(test)]
pub(crate) fn referenced_sram(image: &[u8]) -> std::collections::BTreeSet<u32> {
    mediatek_optical::image::analysis::RamReferences::inspect(image)
        .bytes()
        .clone()
}

/// Whether the halfwords at `off` match `sig` (each entry `(value, mask)`,
/// matched as `(hw & mask) == value`).
pub(crate) fn matches_sig(image: &[u8], sig: &[(u16, u16)], off: usize) -> bool {
    sig.iter().enumerate().all(|(k, &(v, m))| {
        let hw = u16::from_le_bytes([image[off + 2 * k], image[off + 2 * k + 1]]);
        (hw & m) == v
    })
}

/// Find the first offset in `[lo, hi)` whose halfwords match `sig` (each entry a
/// `(value, mask)` pair, matched as `(hw & mask) == value`).
pub(crate) fn find_masked(image: &[u8], sig: &[(u16, u16)], lo: usize, hi: usize) -> Option<usize> {
    let hi = hi.min(image.len());
    let span = sig.len() * 2;
    if span == 0 || lo > hi || span > hi - lo {
        return None;
    }
    (lo..=hi - span)
        .step_by(2)
        .find(|&off| matches_sig(image, sig, off))
}

/// Every offset in `[lo, hi)` matching `sig` — used where a finder must prove a
/// signature is *unique* (refuse rather than guess if it is not).
pub(crate) fn find_masked_all(
    image: &[u8],
    sig: &[(u16, u16)],
    lo: usize,
    hi: usize,
) -> Vec<usize> {
    let hi = hi.min(image.len());
    let span = sig.len() * 2;
    if span == 0 || lo > hi || span > hi - lo {
        return Vec::new();
    }
    (lo..=hi - span)
        .step_by(2)
        .filter(|&off| matches_sig(image, sig, off))
        .collect()
}

/// Locate `sig`'s single occurrence in `[lo, hi)`, failing loudly if it is absent
/// or ambiguous (more than one hit) — the "prove it or refuse" contract every
/// grounded finder uses.
///
/// Thin shim over [`thumb_asm::find_one_in`] (0.11.1+). Its `FindError` carries
/// `count` and `first`, but not the lever label we want the operator to see —
/// so this wrapper stays, re-flavouring the typed error as an `anyhow` bail
/// that names the signature and the search window.
///
/// Signature semantics: upstream steps past a match by the full pattern length
/// (non-overlapping); our old hand-rolled loop stepped by one halfword
/// (overlap-permitting). For real 32-byte instruction-sequence signatures no
/// self-overlap is possible, so the two produce identical results on every
/// signature in this crate — pinned by the byte-exact KAT.
pub(crate) fn find_unique(
    image: &[u8],
    sig: &[(u16, u16)],
    lo: usize,
    hi: usize,
    what: &str,
) -> Result<usize> {
    let hi = hi.min(image.len());
    if lo >= hi {
        bail!("{what} signature: empty search window [0x{lo:x},0x{hi:x})");
    }
    match thumb_asm::find_one_in(image, thumb_asm::Needle::Masked(sig), lo..hi) {
        Ok(off) => Ok(off),
        Err(thumb_asm::FindError::NotFound) => {
            bail!("{what} signature matched 0 time(s) in [0x{lo:x},0x{hi:x}) — refusing to patch")
        }
        Err(thumb_asm::FindError::Ambiguous { count, first }) => bail!(
            "{what} signature matched {count} time(s) in [0x{lo:x},0x{hi:x}) \
             (first at 0x{first:x}, want exactly 1) — refusing to patch"
        ),
        // `FindError` is `#[non_exhaustive]` (0.11.0+): any future variant is
        // still a "refuse rather than guess" outcome, so surface it as one.
        Err(e) => bail!("{what} signature: {e}"),
    }
}

/// Select one role across every supported encoding, never by variant priority.
fn find_unique_variant(
    image: &[u8],
    variants: &[&[(u16, u16)]],
    lo: usize,
    hi: usize,
    what: &str,
) -> Result<(usize, usize)> {
    let mut found = None;
    for (variant, pattern) in variants.iter().enumerate() {
        for site in find_masked_all(image, pattern, lo, hi) {
            ensure!(
                found.is_none(),
                "{what}: ambiguous instruction variants; refusing to patch"
            );
            found = Some((site, variant));
        }
    }
    found.ok_or_else(|| anyhow!("{what}: no supported instruction variant"))
}

// (`decode_bl_target` removed 0.8.14: use [`thumb::decode_bl`] from the
// standalone `thumb-asm` crate — same contract, single source of truth.)

/// Follow the decoded cold/warm convergence branch and its native init call.
pub(crate) fn boot_init_convergence(image: &[u8], site: usize) -> Option<(usize, u32)> {
    let branch = thumb::isa::decode_at(image, site.checked_add(4)?)?;
    if branch.mnemonic != "b" || branch.cond != Some(thumb::Cond::Mi) {
        return None;
    }
    let convergence = branch.branch_target()? as usize;
    Some((convergence, thumb::decode_bl(image, convergence)?))
}

/// Emit code writing the 32-bit register `src` big-endian into the reply buffer
/// at byte offsets `base_off..base_off+4`, through the drive byte-writer held in
/// **r7** (`writer(r0=offset, r1=byte)`). Uses r5 as scratch and preserves
/// `src`. Used by the [`abi::Verb::FlashWrite`] probe to marshal the echoed
/// offset and the PROGRAM status word into the data-in reply. The byte-writer
/// preserves r4-r7 (proven by the handler's clear/dump loops using r5/r6 across
/// it), so `src` (r4/r6) survives the four calls.
pub(crate) fn emit_be_word_to_response(a: &mut Asm, src: u16, base_off: u8) {
    for idx in 0u16..4 {
        // r5 = (src >> (8*(3-idx))) & 0xFF — isolate one byte via left-then-right.
        if idx == 0 {
            a.lsrs_imm(5, src, 24);
        } else {
            a.lsls_imm(5, src, 8 * idx);
            a.lsrs_imm(5, 5, 24);
        }
        a.movs_imm(0, base_off + idx as u8);
        a.mov_reg(1, 5);
        a.blx(7);
    }
}

/// Emit a **flash write** through the OEM PROGRAM engine — the reusable freemkv flash
/// primitive (SAVE uses it; so can any future freemkv-owned write). The engine can only
/// source program data from the firmware's reserved NV DRAM window (it applies
/// `phys = (src & 0x00FFFFFF) + dram_base`), so an SRAM src is unreachable. This:
///   1. reads the boot-set window globals `dram_base = [dram_base_ptr]` and
///      `buf_off = [dram_base_ptr + 4]` (the reserved NV scratch offset);
///   2. CPU-stages `len` bytes from SRAM `src` into `dram_base + buf_off`;
///   3. calls `PROGRAM(src = buf_off, dest, len, op = 1)` — a 4 KiB-sector RMW that
///      erases + reprograms while preserving every neighbouring byte in the sector.
///
/// Leaves the PROGRAM status word in **r0**. Clobbers r0,r1,r2,r3,r5,r6. `dest`/`src`
/// are fixed flash/SRAM addresses (compile-time). NOTE: PROGRAM reports "sequence
/// issued", never "committed" — callers that must confirm should read `dest` back.
#[allow(clippy::too_many_arguments)]
pub(crate) fn emit_flash_write(
    a: &mut Asm,
    dram_base_ptr: u32,
    dest: u32,
    src: u32,
    len: u8,
    flash_program: u32,
) {
    a.ldr_lit(0, dram_base_ptr);
    a.ldr_imm(6, 0, 0); // r6 = dram_base = [dram_base_ptr]
    a.ldr_lit(0, dram_base_ptr + 4);
    a.ldr_imm(5, 0, 0); // r5 = buf_off = [dram_base_ptr+4] (reserved NV window offset)
    a.adds_reg(6, 6, 5); // r6 = dram_base + buf_off (DRAM staging target)
    a.ldr_lit(0, src); // r0 = &src (SRAM)
    for i in 0..len as u16 {
        a.ldrb_imm(1, 0, i);
        a.strb_imm(1, 6, i); // stage src[i] -> DRAM window
    }
    a.mov_reg(0, 5); // r0 = src arg = buf_off (window offset; PROGRAM re-adds dram_base)
    a.ldr_lit(1, dest); // r1 = flash dest offset
    a.movs_imm(2, len); // r2 = len
    a.movs_imm(3, 1); // r3 = op=1 (RMW erase, neighbour-preserving)
    a.ldr_lit(5, flash_program | 1);
    a.blx(5); // r0 = PROGRAM status word (r4-r11 preserved)
}

/// The resolved boot-init hook site, tagged by which prologue shape matched.
///
/// Modern sites resolve through the cold/warm convergence call; classic sites
/// require a unique caller of the leaf helper. Neither tag alone qualifies a detour.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BootInitSite {
    /// MT1959 modern prologue site.
    Modern(u32),
    /// MT1939-classic leaf-helper site. The legacy variant name records that
    /// hardware call-order remains unconfirmed; source-qualified emission is supported.
    ClassicUnconfirmed(u32),
}

impl BootInitSite {
    /// The hook-site file offset, regardless of which prologue shape matched.
    pub fn site(self) -> u32 {
        match self {
            BootInitSite::Modern(s) | BootInitSite::ClassicUnconfirmed(s) => s,
        }
    }
}

impl Mt1959Engine {
    /// Require one connected native scanner: incoming CDB, table stride,
    /// linked/terminal records, READ BUFFER routing, and balanced handler calls.
    pub fn find_scanner_entry(&self, image: &[u8]) -> Result<u32> {
        mediatek_optical::image::analysis::CommandScanner::inspect(image)
            .map(|scanner| scanner.entry() as u32)
            .context("native command scanner contract")
    }

    /// Incoming command bytes proven by the connected native scanner grammar.
    pub fn find_cdb_base(&self, image: &[u8]) -> Result<u32> {
        mediatek_optical::image::analysis::CommandScanner::inspect(image)
            .map(|scanner| scanner.cdb())
            .context("native CDB operand contract")
    }

    /// The sense-setter routine `set_sense(key, asc, ascq)` the scanner
    /// tail-calls: the `bl` target immediately after a `movs r2 ; movs r1 ;
    /// movs r0` immediate triple inside the scanner body.
    pub fn sense_setter(&self, image: &[u8]) -> Result<u32> {
        let entry = self.find_scanner_entry(image)? as usize;
        Self::sense_setter_at(image, entry)
    }

    pub(super) fn sense_setter_at(image: &[u8], entry: usize) -> Result<u32> {
        let end = (entry + 0x120).min(image.len().saturating_sub(4));
        let is_movs = |off: usize, rt: u16| {
            let hw = u16::from_le_bytes([image[off], image[off + 1]]);
            (hw & 0xF800) == 0x2000 && ((hw >> 8) & 0x7) == rt
        };
        let mut off = entry;
        while off + 8 <= end {
            if is_movs(off, 2) && is_movs(off + 2, 1) && is_movs(off + 4, 0) {
                if let Some(t) = thumb::decode_bl(image, off + 6) {
                    return Ok(t);
                }
            }
            off += 2;
        }
        bail!("could not locate the sense-setter (movs r2/r1/r0 + bl) inside the scanner")
    }

    /// The unique live dispatch record for `opcode`: found by scanning coherent
    /// `opcode@0/flags@1/handler@4` runs across the table window, keeping records
    /// with the live media-gated flag and an in-image handler, and requiring
    /// exactly one whose handler lands on a real `push {…,lr}` prologue.
    pub fn find_live_record(&self, image: &[u8], opcode: u8) -> Result<CommandRecord> {
        let commands = mediatek_optical::image::analysis::CommandDispatch::inspect(image)
            .context("native command ownership")?;
        Self::live_record_from(&commands, opcode)
    }

    pub(super) fn live_record_from(
        commands: &mediatek_optical::image::analysis::CommandDispatch<'_>,
        opcode: u8,
    ) -> Result<CommandRecord> {
        let image = commands.image();
        let record = commands
            .record(opcode, LIVE_FLAGS)
            .context("live command record")?;
        ensure!(
            thumb::prologue_is_push_lr(image, (record.handler & !1) as usize, 6),
            "native command handler has no supported saved-LR entry"
        );
        Ok(*record)
    }

    /// [`Self::find_live_record`] over an explicit table window. dispatch table lives in the lineage-profile window (MT1959 at 0x140000..0x160000); the MT1939 **classic**
    /// generation keeps the same `opcode@0/flags@1/handler@4` record format but in
    /// a different window (`~0x1a4000`, engine-scope §1), so the classic engine
    /// calls this with that window.
    pub fn find_live_record_in(
        &self,
        image: &[u8],
        opcode: u8,
        table_lo: usize,
        table_hi: usize,
    ) -> Result<CommandRecord> {
        let record = self.find_live_record(image, opcode)?;
        ensure!(
            (table_lo..table_hi).contains(&record.off),
            "proven native command record is outside the requested extent"
        );
        Ok(record)
    }

    /// Largest run of erased flash (`0xFF`) of at least `need` bytes, 4-aligned,
    /// lying inside an active CMAC range (so it's integrity-covered like a real
    /// handler), searched from the code region up. Deterministic (largest wins,
    /// lowest offset breaks ties) so `create` is reproducible. Existing full-run
    /// placements take priority; clipped boundary runs are a fallback.
    pub fn free_space(&self, image: &[u8], need: usize) -> Result<u32> {
        super::code_space::find(image, need, CODE_REGION_START)
    }

    /// The response byte-writer `response_write_byte(r0=offset, r1=byte)` and the
    /// buffer-base commit offset it uses — both derived by a masked instruction
    /// signature over its (fixed) body, which loads `0xaf90`, `[0x02000c7c]`,
    /// `[0x02000c78]`, then `strb r1,[r0]; bx lr`. Returns `(writer, commit_off)`.
    pub fn find_response_writer(&self, image: &[u8]) -> Result<(u32, u32)> {
        let io = mediatek_optical::image::analysis::ResponseIo::inspect(image)
            .map_err(|error| anyhow!("native response I/O: {error}"))?;
        Ok((io.writer() as u32, io.buffer_offset()))
    }

    /// The response-commit routine `commit(r0=buffer_offset)` and the transfer
    /// length field it reads. Returns `(commit_entry, length_field)`.
    ///
    /// Matched by the **version-invariant anchors** rather than an exact byte
    /// run, so one engine handles every MT1959 image regardless of who built it:
    /// the commit routine always (a) stores the DMA source with `str r0,[rN,#0x28]`
    /// then (b) loads the 16-bit transfer-length cell with the immediately
    /// following `ldr r0,[pc,#imm]` (an SRAM literal), and (c) begins with a
    /// `ldr r1,[pc,#imm]` that loads an SRAM base-pointer cell. OEM 1.00 puts
    /// these back-to-back (`commit @ 0x98180`); MK 1.03 inserts extra bounds-clamp
    /// instructions mid-body (`commit @ 0x98434`) which broke the old contiguous
    /// 7-instruction signature — but these three anchors hold in both. The MMIO
    /// control-block base loaded for the `[rN,#0x28]` store is a `0x04..` literal,
    /// so the entry scan keeps only the `ldr r1,[pc]` that targets SRAM.
    pub fn find_response_commit(&self, image: &[u8]) -> Result<(u32, u32)> {
        let io = mediatek_optical::image::analysis::ResponseIo::inspect(image)
            .map_err(|error| anyhow!("native response I/O: {error}"))?;
        Ok((io.commit().entry() as u32, io.commit().length_cell()))
    }

    /// [`Self::find_response_commit`] over an explicit `[lo,hi)` code window.
    pub fn find_response_commit_in(
        &self,
        image: &[u8],
        lo: usize,
        hi: usize,
    ) -> Result<(u32, u32)> {
        let commit = mediatek_optical::image::analysis::ResponseCommit::inspect_in(image, lo, hi)
            .map_err(|error| anyhow!("native response committer: {error}"))?;
        Ok((commit.entry() as u32, commit.length_cell()))
    }

    /// Locate the OEM flash **PROGRAM** routine (`program(r0=src, r1=dest, r2=len,
    /// r3=op)`) — the entry a [`abi::Verb::FlashWrite`] `bl`s. Returns the routine's
    /// address (`0x13da2a` on BU40N 1.00; VA == file offset in this flat image).
    ///
    /// The raw prologue `FLASH_PROGRAM_SIG` is NOT unique: it also matches a decoy
    /// erase routine that shares the prologue (`0x8faa` on BU40N). Disambiguate by the
    /// candidate's constant table (`+0..+FLASH_POOL_SPAN`), requiring ALL THREE of the
    /// mailbox constant `FLASH_MAILBOX`, the controller constant `FLASH_CONTROLLER`,
    /// and a descriptor pointer word in `[0x01ff_0000, 0x0200_0000)`. Only the true
    /// PROGRAM routine carries all three (the decoy lacks the descriptor), which yields
    /// exactly one qualifying candidate across the owned MT19xx corpus. Refuses (rather
    /// than guessing) if zero or more than one candidate qualifies.
    pub fn find_flash_program(&self, image: &[u8]) -> Result<u32> {
        // A descriptor pointer lives in the trailing pool of the true PROGRAM routine.
        let pool_has_word_in = |from: usize, range: std::ops::Range<u32>| -> bool {
            let end = (from + FLASH_POOL_SPAN).min(image.len().saturating_sub(4));
            (from..end)
                .step_by(2)
                .any(|p| range.contains(&thumb::read_u32(image, p)))
        };
        let qualifies = |cand: usize| -> bool {
            pool_has_word_in(cand, FLASH_MAILBOX..FLASH_MAILBOX + 1)
                && pool_has_word_in(cand, FLASH_CONTROLLER..FLASH_CONTROLLER + 1)
                && pool_has_word_in(cand, 0x01ff_0000..0x0200_0000)
        };
        let hits: Vec<usize> = find_masked_all(image, FLASH_PROGRAM_SIG, 0, image.len())
            .into_iter()
            .filter(|&c| qualifies(c))
            .collect();
        match hits.as_slice() {
            [one] => Ok(*one as u32),
            other => bail!(
                "flash PROGRAM routine (prologue + mailbox 0x{FLASH_MAILBOX:08x} + \
                 controller 0x{FLASH_CONTROLLER:08x} + 0x01ff descriptor) matched {} \
                 candidate(s) (want exactly 1) — refusing to patch",
                other.len()
            ),
        }
    }

    /// Locate the **NV DRAM-window base pointer** — the SRAM address of the global that
    /// holds the flash controller's program-source translation base (the engine reads a
    /// program source as `phys = (src & 0x00FFFFFF) + [ptr]`). freemkv's flash-write
    /// primitive (`emit_flash_write`) stages data into that window and passes a window
    /// offset, because the OEM program engine cannot source SRAM directly. `[ptr+4]` is
    /// the reserved NV scratch window offset.
    ///
    /// MUST be signature-derived: it is `0x02000C78` on MT1959 but takes SEVEN distinct
    /// values across the 85 MT1939 images (even within one model line across versions), so
    /// a hardcoded constant would corrupt every MT1939 flash write. Validated 118/118.
    ///
    /// Method: the PROGRAM routine's op=1 RMW path calls two copy helpers (stage +
    /// overlay) that each load this pointer as their first pc-relative SRAM literal. Scan
    /// PROGRAM's body for `bl` targets, read each target's first `ldr rX,[pc,#imm]` SRAM
    /// literal (`0x02000000..0x02002000`, 4-aligned), and return the value loaded by
    /// **≥2 distinct helpers** — unique corpus-wide. Refuses otherwise.
    pub fn find_nv_dram_base(&self, image: &[u8]) -> Result<u32> {
        let program = self.find_flash_program(image)? as usize;
        self.find_nv_dram_base_from(image, program)
    }

    /// [`Self::find_nv_dram_base`] with the PROGRAM anchor already resolved by the
    /// caller — avoids a second full-image `find_flash_program` scan when
    /// [`Self::build_handler`] has one in hand.
    fn find_nv_dram_base_from(&self, image: &[u8], program: usize) -> Result<u32> {
        const SRAM: std::ops::Range<u32> = 0x0200_0000..0x0200_2000;
        // Distinct `bl` targets within the PROGRAM body (op=1 RMW calls its copy helpers).
        let mut targets: Vec<usize> = Vec::new();
        let end = (program + 0x260).min(image.len().saturating_sub(4));
        let mut off = program;
        while off + 4 <= end {
            if let Some(t) = thumb::decode_bl(image, off) {
                let t = t as usize;
                if t < image.len() && !targets.contains(&t) {
                    targets.push(t);
                }
            }
            off += 2;
        }
        // literal -> number of distinct helper routines that load it as their first ldr[pc].
        let mut hits: std::collections::BTreeMap<u32, u32> = std::collections::BTreeMap::new();
        for &t in &targets {
            let tend = (t + 0x40).min(image.len().saturating_sub(2));
            let mut p = t & !1;
            while p + 2 <= tend {
                let hw = u16::from_le_bytes([image[p], image[p + 1]]);
                if (hw & 0xF800) == 0x4800 {
                    if let Some(v) = pc_literal(image, p) {
                        if SRAM.contains(&v) && v & 3 == 0 {
                            *hits.entry(v).or_default() += 1;
                        }
                    }
                    break; // first ldr[pc] of the routine only
                }
                p += 2;
            }
        }
        let winners: Vec<u32> = hits
            .iter()
            .filter(|(_, &c)| c >= 2)
            .map(|(&v, _)| v)
            .collect();
        match winners.as_slice() {
            [one] => Ok(*one),
            other => bail!(
                "NV DRAM-window base pointer: {} SRAM literal(s) loaded by >=2 PROGRAM copy \
                 helpers (want exactly 1) — refusing to resolve the flash-write staging base",
                other.len()
            ),
        }
    }

    /// Locate the **NV block base** (the SAVE home) by the OEM region/RPC-2 record
    /// SIGNATURE — no hardcoded flash offset AND no hard-pinned sub-block alignment.
    /// The record `00 04 05` sits `0x4B0` bytes into its 4 KiB block, followed by
    /// `0xFF` fill, with the block head below it (`base..base+0x4B0`) blank — that head
    /// is freemkv's write scratch. Returns the flash-relative 4 KiB block base
    /// (`0x1EA000` on every corpus image, both chips — proven 118/118 by the corpus NV
    /// scan). Because SAVE/RESET/boot all read and write here, resolving it per-image
    /// (rather than trusting a constant) keeps the foundation correct.
    ///
    /// The earlier revision additionally pinned the record to `(p & 0xFFF) == 0x4B0` —
    /// i.e. it assumed flash offset 0 == file offset 0. That silently failed on the
    /// vendor-WRAPPED dumps (a 0x800-byte cdrinfo ASCII header, or a 4-byte ASUS length
    /// prefix `00 20 00 00` with a trailing ECDSA signature) which shift the whole flash
    /// image by a non-4 KiB-aligned header, so the record no longer lands on a `0x…4B0`
    /// file offset. De-hardcoding to a pure signature match (per the standing lesson:
    /// any hard-pinned offset is suspect — blocks/images relocate across MT19xx variants
    /// and wrappers) recovers all of them. Masking the FOUND record to its enclosing
    /// 4 KiB block (`& !0xFFF`) still yields the flash-relative `0x1EA000` because every
    /// observed wrapper header is smaller than `0x1000 - 0x4B0`, so the record stays
    /// inside the same aligned block as the true NV base.
    ///
    /// Refuses (rather than guessing) unless EXACTLY ONE qualifying record exists in the
    /// top 256 KiB of flash — the structural constraints (record bytes + `0xFF` fill +
    /// a blank 0x4B0-byte head) yield a unique hit corpus-wide.
    pub fn find_nv_block(&self, image: &[u8]) -> Result<u32> {
        const REC: [u8; 3] = [0x00, 0x04, 0x05]; // OEM region/RPC-2 record tag
        const SUB: usize = 0x4B0; // record offset within its 4 KiB block
                                  // NV lives high in flash; the window is len-relative so a prepended
                                  // vendor header (which shifts the image up) never pushes it out.
        let lo = image.len().saturating_sub(0x4_0000).max(SUB);
        let hits: Vec<usize> = (lo..image.len().saturating_sub(16))
            .filter(|&p| {
                image[p..p + 3] == REC
                    && image[p + 3..p + 16].iter().all(|&b| b == 0xFF)
                    && image[p - SUB..p].iter().all(|&b| b == 0xFF)
            })
            .collect();
        match hits.as_slice() {
            [rec] => Ok((*rec as u32) & !0xFFF),
            [] => {
                // A used RPC record need not retain its factory tag/padding.
                // Bind its native copy routine instead of guessing a flash base.
                let copy = mediatek_optical::image::analysis::NvRecordCopy::detect(image)
                    .context("NV record has no factory marker or source-bound native copy")?;
                let base = copy.record & !0xfff;
                ensure!(
                    image
                        .get(base as usize..copy.record as usize)
                        .is_some_and(|head| head.len() == SUB && head.iter().all(|b| *b == 0xff)),
                    "native NV record has no erased settings prefix"
                );
                ensure!(
                    copy.base_cell == self.find_nv_dram_base(image)?,
                    "native NV copy and PROGRAM disagree on the DRAM window"
                );
                Ok(base)
            }
            other => bail!(
                "NV region record (00 04 05 with a blank 0x4B0-byte head) matched {} \
                 candidate(s) in the top 256 KiB (want exactly 1) — refusing to resolve \
                 SAVE home",
                other.len()
            ),
        }
    }

    /// Locate the MT1959 **boot-init** hook site — the point a future boot-init
    /// detour is written (`anchor+4`, over `ldr r0,[r0,#0x18]; lsls r0,r0,#0x18`).
    /// Returns `0x13d41a` on BU40N 1.00.
    ///
    /// `BOOT_INIT_SIG` is unique (n==1) on every owned MT1959 image. On the
    /// MT1939-classic lineage the modern shape returns zero and an ORDERED FALLBACK
    /// to `BOOT_INIT_SIG_CLASSIC` recovers the same reload site (tagged
    /// [`BootInitSite::ClassicUnconfirmed`]). Ordering is MANDATORY and the reason
    /// this is not a merged scan: the classic helper ALSO matches inside 157 modern
    /// images, so a simultaneous scan would make modern images ambiguous. The modern
    /// shape is therefore tried FIRST and resolves modern images without ever
    /// consulting the classic signature.
    ///
    /// Each signature is required unique in its own right (`n==1`); `>1` on either
    /// refuses. Zero matches on BOTH returns `Ok(None)` (unknown prologue shape).
    pub fn find_boot_init(&self, image: &[u8]) -> Result<Option<BootInitSite>> {
        match find_masked_all(image, BOOT_INIT_SIG, 0, image.len()).as_slice() {
            [one] => Ok(Some(BootInitSite::Modern(*one as u32 + 4))),
            // No modern-shape match → try the MT1939-classic variant. Original-first
            // keeps modern images resolving via BOOT_INIT_SIG (byte-identical output).
            [] => match find_masked_all(image, BOOT_INIT_SIG_CLASSIC, 0, image.len()).as_slice() {
                [] => Ok(None),
                [one] => Ok(Some(BootInitSite::ClassicUnconfirmed(*one as u32 + 4))),
                many => bail!(
                    "classic boot-init signature matched {} time(s) (want exactly 1) — \
                     refusing to patch",
                    many.len()
                ),
            },
            many => bail!(
                "boot-init signature matched {} time(s) (want 0 on MT1939-classic or \
                 exactly 1 on MT1959) — refusing to patch",
                many.len()
            ),
        }
    }

    /// The OEM READ DISC STRUCTURE **format dispatcher** and the AACS
    /// auth-granted flag — the two facts needed to read any AACS structure
    /// (Volume ID `0x80`, PMSN `0x81`, Media ID `0x82`, MKB `0x83`, …) by handing
    /// the drive a format byte. Returns `(dispatcher, auth_flag)`.
    ///
    /// * The dispatcher is fingerprinted by its prologue: `push {r4,lr}; ldrb
    ///   r1,[r0,#7]; cmp r1,#0x7f` — it reads the format from `CDB[7]` and splits
    ///   AACS (`≥0x80`) from physical formats. It routes to the plaintext
    ///   `0x136xxx` producers and their emit path commits via the same `0x98180`
    ///   DMA the data-return uses.
    /// * The auth flag is the cell the VID producer gates on, located via the
    ///   unique AACS deny sense `05/6F/02` (`movs r2,#2; movs r1,#0x6f; movs
    ///   r0,#5`) — that base (`0x02000c80`) verified present, flag = base+2.
    ///
    /// Setting `auth_flag` bypasses the sealed host-cert AKE; the structure
    /// values themselves are plaintext identifiers, not sealed secrets.
    ///
    /// Retained as grounded knowledge (the READ DISC STRUCTURE dispatcher + auth
    /// flag). The self-contained VID read (subfn 0x03) no longer routes through
    /// the dispatcher, so this is currently unreferenced by the build.
    #[allow(dead_code)]
    pub fn find_aacs(&self, image: &[u8]) -> Result<(u32, u32)> {
        // dispatcher: push {r4,lr} | ldrb r1,[r0,#7] | cmp r1,#0x7f | bhi
        const DISP: &[(u16, u16)] = &[
            (0xB510, 0xFFFF),
            (0x79C1, 0xFFFF),
            (0x297F, 0xFFFF),
            (0xD800, 0xFF00),
        ];
        let dispatcher = find_masked(image, DISP, 0x000a_0000, 0x000c_0000)
            .ok_or_else(|| anyhow!("READ DISC STRUCTURE format-dispatcher signature not found"))?
            as u32;
        // auth flag via the AACS deny-sense fingerprint.
        const DENY: &[(u16, u16)] = &[(0x2202, 0xFFFF), (0x216F, 0xFFFF), (0x2005, 0xFFFF)];
        let deny = find_masked(image, DENY, 0x0013_0000, 0x0014_0000)
            .ok_or_else(|| anyhow!("AACS deny sense (5/6F/02) signature not found"))?;
        const AUTH_BASE: u32 = 0x0200_0c80;
        thumb::find(
            image,
            thumb::Needle::Word(AUTH_BASE),
            deny.saturating_sub(0x300),
        )
        .filter(|&o| o < deny + 0x40)
        .ok_or_else(|| anyhow!("AACS auth-flag base literal not found near the gate"))?;
        Ok((dispatcher, AUTH_BASE + 2))
    }

    /// The unique offset of the VID gate's address-compute tail. The gate
    /// `ldrb r0,[r0]` is at `result + 16` for BOTH variants.
    ///
    /// Resolve all supported grammars together. Multiple matches, including
    /// different variants, refuse the role rather than selecting by priority.
    pub(crate) fn find_vid_gate(&self, image: &[u8]) -> Result<usize> {
        mediatek_optical::image::analysis::VidGate::inspect(image)
            .map(|gate| gate.anchor())
            .map_err(|e| anyhow!("VID gate: {e}"))
    }

    /// The OEM Volume-ID producer and its clear-VID scratch buffer. Returns
    /// `(producer_entry, out_buf)`.
    ///
    /// The producer is the function containing the VID gate: its entry is the
    /// nearest preceding `push {r4,r5,r6,r7,lr}` (`0xB5F0`). Its output buffer is
    /// the scratch literal it loads (~`0x00210c00`, identical across every image
    /// checked) — a *runtime* address above the 2 MiB flash image, read at
    /// runtime, derived here from the producer's own literal pool (never
    /// hardcoded). Calling the producer stages the CLEAR VID into that buffer
    /// before any transit encryption.
    pub fn find_vid_producer(&self, image: &[u8]) -> Result<(u32, u32)> {
        let contract = mediatek_optical::image::analysis::VidGate::inspect(image)
            .map_err(|e| anyhow!("VID producer contract: {e}"))?;
        let gate = contract.anchor() + 16;
        let producer = contract
            .producer_entry()
            .map_err(|e| anyhow!("VID producer entry: {e}"))?;
        // The scratch-buffer literal: a runtime address in [0x00201000,0x00300000)
        // above the flash image. Require exactly one distinct value in the body.
        let mut out: Option<u32> = None;
        let mut o = producer;
        while o + 2 <= (gate + 0x80).min(image.len()) {
            if let Some(v) = pc_literal(image, o) {
                if (0x0020_1000..0x0030_0000).contains(&v) {
                    match out {
                        None => out = Some(v),
                        Some(prev) if prev == v => {}
                        Some(_) => bail!(
                            "VID producer loads more than one runtime scratch literal — ambiguous"
                        ),
                    }
                }
            }
            o += 2;
        }
        let out = out
            .ok_or_else(|| anyhow!("VID producer scratch-buffer literal (~0x210c00) not found"))?;
        Ok((producer as u32, out))
    }

    /// The OEM per-AGID AKE gate-setter primitive `set_agid_state(r0=agid,
    /// r1=value)` (`0xcadf8` on 1.00). Derived from the image, not by a fragile
    /// standalone signature: the producer opens the gate with `movs r1,#1; bl
    /// <set_agid_state>` on both its proceed and skip paths, so the `bl` target is
    /// the routine. Every such site must agree.
    pub fn find_vid_gate_setter(&self, image: &[u8]) -> Result<u32> {
        let gate = self.find_vid_gate(image)? + 16;
        let end = (gate + 0x60).min(image.len().saturating_sub(4));
        let mut target: Option<u32> = None;
        let mut o = gate;
        while o + 4 <= end {
            if u16::from_le_bytes([image[o], image[o + 1]]) == 0x2101 {
                // movs r1,#1
                if let Some(t) = thumb::decode_bl(image, o + 2) {
                    let t = t & !1;
                    match target {
                        None => target = Some(t),
                        Some(prev) if prev == t => {}
                        Some(_) => bail!("VID gate-setter call sites disagree — ambiguous"),
                    }
                }
            }
            o += 2;
        }
        target.ok_or_else(|| anyhow!("VID gate-setter (movs r1,#1; bl) not found in the producer"))
    }

    /// The OEM VID producer's per-AGID **session struct** base (`0x02000d38` on
    /// 1.00). The producer reads the active AGID from `byte[base+0xa] >> 6`
    /// (top two bits) and bails if it is ≥ 2, so a standalone producer call
    /// depends on that field. Bind the SRAM literal to the actual checked byte
    /// read and prove its saved register remains live along every reaching path.
    /// The Gate-A `04 01` bare-read stub uses
    /// this to reset the AGID selector (`byte[0xa] &= 0x3F`, AGID → 0) before the
    /// producer runs, so a prior read or `04 00` deny can't leave the selector
    /// `>= 2` (which makes the producer bail with ABORTED COMMAND until power-cycle).
    pub fn find_vid_agid_struct(&self, image: &[u8]) -> Result<u32> {
        mediatek_optical::image::analysis::VidGate::inspect(image)
            .and_then(|gate| gate.agid_address())
            .map_err(|e| anyhow!("VID AGID operand binding: {e}"))
    }

    /// `SetDiscMode`, the read-datapath disc-mode dispatcher (`0x43cb0` on 1.00),
    /// located by `SETDISCMODE_SIG` and proven unique. This is the Bus
    /// Encryption (subfn 0x04) hook point; see the build report for why it is not
    /// yet wired.
    pub fn find_setdiscmode(&self, image: &[u8]) -> Result<u32> {
        let lo = 0x0004_0000usize.min(image.len());
        let hi = 0x0005_0000usize.min(image.len());
        Ok(find_unique(image, SETDISCMODE_SIG, lo, hi, "SetDiscMode")? as u32)
    }

    /// The Speed (0x02) ramp-ceiling gate anchor. Returns `(anchor, idx_reg)`
    /// where `idx_reg` is the register the ramp holds `speed_index` in (`2` for the
    /// original `SPEED_GATE_SIG`, `0` for the `SPEED_GATE_SIG_R0` variant); the
    /// gate `cmp/bhi` the detour replaces begins at `anchor+4` for both. Original
    /// first so the BU40N KAT base always resolves to the `r2` shape.
    pub fn find_speed_gate(&self, image: &[u8]) -> Result<(u32, u8)> {
        let lo = 0x0001_0000usize.min(image.len());
        let hi = 0x0002_0000usize.min(image.len());
        let (site, variant) = find_unique_variant(
            image,
            &[SPEED_GATE_SIG, SPEED_GATE_SIG_R0],
            lo,
            hi,
            "Speed ramp-ceiling gate",
        )?;
        Ok((site as u32, if variant == 0 { 2 } else { 0 }))
    }

    /// The Region-free (0x03) RPC-state emitter anchor — the unique
    /// `REGION_EMIT_SIG` match (`0x119890` on 1.00, `0x119a84` on 1.03).
    /// Returns the anchor offset; the `frame[4]` store the detour replaces is at
    /// `anchor+6`.
    pub fn find_region_emitter(&self, image: &[u8]) -> Result<u32> {
        // Full-image scan: `REGION_EMIT_SIG` is a single exact 20-byte hit image-wide
        // on every OEM image (measured maxn==1 across the 118-image corpus), so a
        // bounded window only served to exclude the ~+0x2b000-relocated MT1939-modern
        // block (region emitter at 0x144a66/0x146094/0x145ea4, above the old 0x120000
        // ceiling). `find_unique` still refuses on any n>1.
        Ok(find_unique(image, REGION_EMIT_SIG, 0, image.len(), "RPC-state emitter")? as u32)
    }

    /// [`Self::find_region_emitter`] over an explicit window. `REGION_EMIT_SIG` is
    /// unique on all 42 MT1939 images too, but the MT1939 **classic** RPC emitter
    /// sits at `~0x154000..0x157000` (engine-scope §2), outside the MT1959 window,
    /// so the classic engine searches there.
    pub fn find_region_emitter_in(&self, image: &[u8], lo: usize, hi: usize) -> Result<u32> {
        let lo = lo.min(image.len());
        let hi = hi.min(image.len());
        Ok(find_unique(image, REGION_EMIT_SIG, lo, hi, "RPC-state emitter")? as u32)
    }

    /// The AACS AKE accept-gate anchor — the unique `AKE_GATE_SIG` match
    /// (`0x136594` on 1.00). Returns the anchor; the RESET writer the Raw Read
    /// detour replaces (`movs r1,#1; b <back>`, 4 bytes) is at `anchor+12`.
    pub fn find_ake_gate(&self, image: &[u8]) -> Result<u32> {
        // Full-image scan (all three AKE signatures are unique image-wide, maxn==1
        // measured): the old 0x130000..0x140000 window excluded the ~+0x2b000
        // relocated MT1939-modern AACS block (AKE gate lifted above 0x140000).
        Ok(find_unique(image, AKE_GATE_SIG, 0, image.len(), "AACS AKE accept gate")? as u32)
    }

    /// The NB-class AKE accept-gate anchor — the unique `AKE_GATE_SIG_NB` match.
    /// Returns the anchor; the shared `bl set_agid_state` the Raw Read NB detour
    /// replaces is at `anchor+12` (see `AKE_GATE_SIG_NB`).
    pub fn find_ake_gate_nb(&self, image: &[u8]) -> Result<u32> {
        Ok(find_unique(
            image,
            AKE_GATE_SIG_NB,
            0,
            image.len(),
            "AACS AKE accept gate (NB)",
        )? as u32)
    }

    /// The NB-class `1.V5` AKE accept-gate anchor — the unique
    /// `AKE_GATE_SIG_NB_V5` match. Returns the anchor; the reject writer
    /// (`movs r1,#1`) is at `anchor+12` and the shared `bl set_agid_state` the
    /// Raw Read detour replaces is at `anchor+14` (see `AKE_GATE_SIG_NB_V5`).
    pub fn find_ake_gate_nb_v5(&self, image: &[u8]) -> Result<u32> {
        Ok(find_unique(
            image,
            AKE_GATE_SIG_NB_V5,
            0,
            image.len(),
            "AACS AKE accept gate (NB 1.V5)",
        )? as u32)
    }

    /// The OEM AACS engine full **session-rearm** wrapper — the superset routine
    /// that OEM firmware calls at disc-insert / medium-loaded to bring the AACS
    /// session UP from a clean state. Structure: `push {r4,lr}` → three subsystem
    /// gate/state BLs → the bit-20 write to the engine control word at
    /// `[ptr+4]` (`ldr r2,[pc]; ldr r0,[r2,#4]; movs r1,#1; lsls r1,#0x14;
    /// orrs r0,r1; str r0,[r2,#4]` — the "arm bus-encryption" store the plain
    /// [`Self::find_aacs_session_reset`] primitive does NOT do) → a BL → then
    /// `bl <aacs_session_reset>` itself → four more subsystem re-inits → `pop
    /// {r4,pc}`. On BU40N 1.00 this is at VA `0x00044874`.
    ///
    /// Used by the [`abi::Feature::Encryption`] revert arm (`SET encryption != 0x00`)
    /// so that flipping from a de-bussed session back to OEM/on ACTUALLY
    /// re-wraps the drive at runtime — the fw obeys the flag both directions.
    /// The plain `aacs_session_reset` is insufficient (empirically: kickoff
    /// Fact 4 — direct call returns SCSI Good but the state cell at
    /// `0x01ff9e04` and all observable reads are identical); the bit-20 write
    /// and the four re-init BLs after it are what actually re-arm bus-enc.
    ///
    /// Located by the unique 32-byte inner idiom starting from the routine's
    /// `push {r4,lr}` — three wildcarded BLs, the six-halfword bit-20 store
    /// (which is the strongest fingerprint: setting bit-20 of `[ptr+4]` via the
    /// exact `ldr/ldr/movs/lsls/orrs/str` chain), a wildcarded BL, and the
    /// first halfword of the BL to `aacs_session_reset`. Uniqueness is verified
    /// by decoding that trailing BL and requiring its target to be the
    /// already-resolved `find_aacs_session_reset` entry — same "prove it or
    /// refuse" pattern the reset finder uses to disambiguate its AGID loop.
    pub fn find_aacs_session_rearm(&self, image: &[u8]) -> Result<u32> {
        let reset = self.find_aacs_session_reset(image)?;
        // 16-halfword rearm signature (32 bytes). BL halfwords are matched as
        // BL-shaped (0xF000/0xF800 for hi, 0xC000/0xC000 for lo), tighter than
        // pure wildcard so foreign non-BL sequences with matching mid-body ops
        // do not collide. The bit-20 store idiom (items 8..=13) is what makes
        // this unique image-wide.
        const SIG: &[(u16, u16)] = &[
            (0xB510, 0xFFFF), // push {r4, lr}
            (0xF000, 0xF800),
            (0xC000, 0xC000), // bl <gate-mmio>
            (0xF000, 0xF800),
            (0xC000, 0xC000), // bl <state-bit-21>
            (0xF000, 0xF800),
            (0xC000, 0xC000), // bl <state-zero>
            (0x4A00, 0xFF00), // ldr r2,[pc,#imm]   ─┐
            (0x6850, 0xFFFF), // ldr r0,[r2,#4]     │
            (0x2101, 0xFFFF), // movs r1,#1         │  bit-20 write:
            (0x0509, 0xFFFF), // lsls r1,r1,#0x14   │  "arm bus-encryption"
            (0x4308, 0xFFFF), // orrs r0,r1         │
            (0x6050, 0xFFFF), // str r0,[r2,#4]    ─┘
            (0xF000, 0xF800),
            (0xC000, 0xC000), // bl <state-orrs>
            (0xF000, 0xF800), // bl <aacs_session_reset> (first halfword only;
                              //     target verified below by decoding the full
                              //     32-bit BL, which needs bytes 30..=33).
        ];
        // The trailing BL to aacs_session_reset sits at match+30 (32 bytes: 1
        // push + 3 BLs*4 + 6 mid-body*2 + 1 BL*4 + 1 halfword = 30 bytes to the
        // BL start; the BL itself is 4 bytes wide).
        let hits: Vec<usize> = find_masked_all(image, SIG, 0, image.len())
            .into_iter()
            .filter(|&m| thumb::decode_bl(image, m + 30) == Some(reset))
            .collect();
        let m = match hits.as_slice() {
            [one] => *one,
            [] => bail!(
                "aacs_session_rearm signature not found (want the OEM disc-insert wrapper \
                 whose trailing bl targets aacs_session_reset at 0x{reset:x})"
            ),
            _ => bail!(
                "aacs_session_rearm signature matched {} time(s) (want exactly 1) — refusing",
                hits.len()
            ),
        };
        Ok(m as u32)
    }

    /// The OEM AACS engine session-reset routine (`aacs_session_reset`) — the
    /// primitive that idles the AACS hardware engine (a direct engine gate-bit
    /// clear followed by a mailbox reset), used by the Raw Read deny-path detour
    /// so a failed-cert deny never leaves the engine non-idle (which would hang
    /// the next bare `0xAD` VID read). Returns the routine entry.
    ///
    /// Located by its unique AGID-reset loop, anchored on the already-resolved
    /// `set_agid_state` (the loop's inner `bl` MUST target it): `movs r1,#0; movs
    /// r0,#0; bl <mailbox>; movs r3,#0; movs r1,#1; mov r0,r3; bl <set_agid_state>;
    /// adds r3,#1; uxtb r3; cmp r3,#2; blo`. The two `bl`s are wildcarded then the
    /// set_agid_state one is verified by decoding its target, making the match
    /// unique; the entry is the nearest preceding `push {r4,r5,r6,lr}` (`0xB570`).
    pub fn find_aacs_session_reset(&self, image: &[u8]) -> Result<u32> {
        let setter = self.find_vid_gate_setter(image)?;
        // AGID-reset loop core (14 halfwords; the two BL word-pairs wildcarded).
        const SIG: &[(u16, u16)] = &[
            (0x2100, 0xFFFF), // movs r1,#0
            (0x2000, 0xFFFF), // movs r0,#0
            (0x0000, 0x0000), // bl <mailbox> (lo)
            (0x0000, 0x0000), // bl <mailbox> (hi)
            (0x2300, 0xFFFF), // movs r3,#0
            (0x2101, 0xFFFF), // movs r1,#1
            (0x0018, 0xFFFF), // mov r0,r3
            (0x0000, 0x0000), // bl <set_agid_state> (lo)
            (0x0000, 0x0000), // bl <set_agid_state> (hi)
            (0x1C5B, 0xFFFF), // adds r3,#1
            (0x061B, 0xFFFF), // lsls r3,#0x18
            (0x0E1B, 0xFFFF), // lsrs r3,#0x18
            (0x2B02, 0xFFFF), // cmp r3,#2
            (0xD300, 0xFF00), // blo <loop top>
        ];
        // Full-image scan: the 14-halfword AGID-reset loop is already disambiguated
        // by requiring its inner `bl` to target the resolved `set_agid_state`, so it
        // is unique image-wide. The old 0x90000..0xe0000 window excluded the
        // ~+0x2b000-relocated MT1939-modern block (reset routine lifted above 0xe0000).
        let (lo, hi) = (0, image.len());
        // The set_agid_state BL sits 14 bytes into the match (2+2+4+2+2+2).
        let hits: Vec<usize> = find_masked_all(image, SIG, lo, hi)
            .into_iter()
            .filter(|&m| thumb::decode_bl(image, m + 14) == Some(setter))
            .collect();
        let m = match hits.as_slice() {
            [one] => *one,
            [] => bail!("aacs_session_reset AGID-reset loop signature not found"),
            _ => bail!(
                "aacs_session_reset signature matched {} time(s) (want exactly 1) — refusing",
                hits.len()
            ),
        };
        // Entry: nearest preceding `push {..r4,r5,r6..,lr}`. Desktop/BU40N is
        // `push {r4,r5,r6,lr}` (0xB570); the NB-class portable line uses
        // `push {r3,r4,r5,r6,r7,lr}` (0xB5F8). Accept any push-with-lr whose
        // register mask includes the loop's working regs r4/r5/r6 (mask bit
        // 0x70) — proven to select the routine prologue on both, and BU40N still
        // resolves to the identical 0xB570 entry (KAT unaffected).
        let mut p = m;
        let entry = loop {
            if p < 2 || m - p > 0x40 {
                bail!(
                    "aacs_session_reset prologue (push {{..r4-r6..,lr}}) not found before the loop"
                );
            }
            let hw = u16::from_le_bytes([image[p], image[p + 1]]);
            if (hw & 0xFF00) == 0xB500 && (hw & 0x0070) == 0x0070 {
                break p;
            }
            p -= 2;
        };
        Ok(entry as u32)
    }

    /// The downgrade-enable (DE) byte offset. Anchored on the ASCII identity page
    /// (the same drive-descriptor record [`crate::family::detect_chip`] parses):
    /// the `"MTEKMT19"` family tag at `descriptor+0x34` must be present, then the
    /// DE slot is `descriptor+0x56`. Refuses rather than guessing a byte to poke
    /// if the page isn't the descriptor.
    ///
    /// The tag is the *only* anchor: the byte at `descriptor+0x50` is a
    /// within-family variant/region marker (`0x78/0x58/0x18/0x38` all occur on
    /// genuine MT1959 parts — proven by the 149-image scan in
    /// `research/hoard-campaign-2026-09-03`), NOT an invariant. It was previously
    /// (wrongly) required to equal `0x78`, which refused 8 otherwise-patchable
    /// images whose DE slot is already correct; that guard is removed. The DE slot
    /// at `+0x56` is stable fleet-wide.
    pub fn find_de_byte(&self, image: &[u8]) -> Result<u32> {
        use crate::family::DESCRIPTOR_OFFSET;
        let de = DESCRIPTOR_OFFSET + DE_BYTE_OFF;
        if de >= image.len() {
            bail!("image too small to contain the drive-descriptor DE byte at 0x{de:x}");
        }
        let tag = &image[DESCRIPTOR_OFFSET + 0x34..DESCRIPTOR_OFFSET + 0x3C];
        if !tag.starts_with(b"MTEKMT19") {
            bail!(
                "drive-descriptor family tag not at 0x{:x} — refusing to place the DE byte",
                DESCRIPTOR_OFFSET + 0x34
            );
        }
        Ok(de as u32)
    }

    /// Reject overlap with source references and the conservative SRAM boundary.
    pub(crate) fn assert_sram_cell_free(
        &self,
        image: &[u8],
        base: u32,
        len: u32,
        what: &str,
    ) -> Result<()> {
        super::sram::SramPlacement::inspect(image).assert_free(base, len, what)
    }

    /// Select a statically unreferenced candidate, including flag/scratch guards.
    /// This does not establish runtime ownership of the selected memory.
    pub fn find_free_sram_cell(&self, image: &[u8]) -> Result<u32> {
        super::sram::SramPlacement::inspect(image).candidate()
    }

    /// Assemble the freemkv `0x3C 0E` handler for the `verb [feature] [state]`
    /// grammar: knock-check, then dispatch on the **verb** (`cdb[4]`) and act on
    /// the flat feature-flag table in SRAM. Miss on the knock → tail-call the
    /// original handler (OEM `READ BUFFER` byte-identical). Every address (cdb
    /// base, byte-writer, commit, length field, OEM handler) is derived from the
    /// image.
    ///
    /// Verbs (`cdb[4]`):
    ///   * [`abi::Verb::Set`] — `flag[cdb[5]=feature] = cdb[6]=state`; returns a
    ///     zeroed buffer.
    ///   * [`abi::Verb::Reset`] — write [`abi::STATE_PASSTHROUGH`] to every feature
    ///     flag (`0x01..=0x07`); returns a zeroed buffer.
    ///   * [`abi::Verb::Get`] — returns `flag[cdb[5]=feature]` in response byte 0.
    ///   * [`abi::Verb::Identity`] — returns [`abi::RESP_MAGIC`] + version + the
    ///     live feature-state table (`flag[0x01..=0x06]`).
    ///   * [`abi::Verb::DumpAll`] — peek `CLEAR_LEN` bytes at the 32-bit address
    ///     packed big-endian in `cdb[5..9]`.
    ///   * any other verb — zeroed buffer.
    ///
    /// Each OEM-code trampoline reads its own `flag[feature]` byte (Speed
    /// `flag[0x01]`, Region `flag[0x02]`, UHD `flag[0x03]`, BD `flag[0x04]`, HRL
    /// `flag[0x05]`, Encryption `flag[0x06]`; wire id `0x07` is retired — was `Bus`)
    /// as a uniform tri-state:
    /// `0xFF` = OEM passthrough, `0x01` = on/armed, `0x00` = off (actively disabled).
    /// The always-on boot-init hook writes `0xFF` into every flag at power-on, so an
    /// unarmed or RESET image is byte-behaviour-identical to OEM and a gate only ever
    /// sees `0x00` (off) when the host has explicitly set it — never at boot.
    ///
    /// The host ALWAYS reads `CLEAR_LEN` bytes — a `0x3C` READ BUFFER is a data-in
    /// opcode, so a command with no/short data phase desyncs the transfer (ABORTED
    /// COMMAND + wedged FIFO). Every verb therefore commits the same `CLEAR_LEN`
    /// window (payload leading, zero-padded).
    pub fn build_handler(
        &self,
        image: &[u8],
        oem_handler: u32,
        flag_base: u32,
        boot_function_entry: u32,
    ) -> Result<Vec<u8>> {
        self.build_handler_with_identity(
            image,
            oem_handler,
            flag_base,
            boot_function_entry,
            identity_blob(),
            &BootSettings::standard(),
        )
    }

    /// Explicit identity input keeps the golden build independent of release versions.
    pub(super) fn build_handler_with_identity(
        &self,
        image: &[u8],
        oem_handler: u32,
        flag_base: u32,
        boot_function_entry: u32,
        identity: Vec<u8>,
        defaults: &BootSettings,
    ) -> Result<Vec<u8>> {
        let analysis = mediatek_optical::image::analysis::ImageAnalysis::inspect(image);
        self.build_handler_from_analysis(
            &analysis,
            oem_handler,
            flag_base,
            boot_function_entry,
            identity,
            defaults,
        )
    }

    /// Reuse source-bound native command/response facts from the enclosing build.
    pub(super) fn build_handler_from_analysis(
        &self,
        analysis: &mediatek_optical::image::analysis::ImageAnalysis<'_>,
        oem_handler: u32,
        flag_base: u32,
        boot_function_entry: u32,
        identity: Vec<u8>,
        defaults: &BootSettings,
    ) -> Result<Vec<u8>> {
        let image = analysis.image();
        let cdb = analysis
            .commands()
            .context("native command ownership")?
            .scanner()
            .cdb();
        let response = analysis.response().context("native response I/O")?;
        let (writer, commit_off) = (response.writer() as u32, response.buffer_offset());
        let (commit, length_field) = (
            response.commit().entry() as u32,
            response.commit().length_cell(),
        );
        // OEM flash PROGRAM routine, recovered per image (no hardcoded VA) — the
        // [`abi::Verb::FlashWrite`] probe `bl`s this.
        let flash_program = self.find_flash_program(image)?;
        // SAVE home, signature-derived per image (no hardcoded offset). The diagnostic
        // FlashWrite window is a compile-time bound; assert the resolved NV block agrees
        // so SAVE's destination and that window can never drift apart.
        let save_home = self.find_nv_block(image)?;
        // Flash-write staging base pointer, signature-derived per image (MT1959 0x02000C78,
        // but 7 distinct values across MT1939 — a constant would corrupt every MT1939 SAVE).
        // Reuse the PROGRAM anchor already resolved above (no second full-image scan).
        let nv_dram_base_ptr = self.find_nv_dram_base_from(image, flash_program as usize)?;
        ensure!(
            (FLASHWRITE_ALLOW_LO..FLASHWRITE_ALLOW_HI).contains(&save_home),
            "resolved NV/SAVE block 0x{save_home:x} is outside the flash-write window \
             0x{FLASHWRITE_ALLOW_LO:x}..0x{FLASHWRITE_ALLOW_HI:x}"
        );
        let id_len = identity.len() as u8;

        let mut a = Asm::new();
        let tail = a.label();
        let knock_ok = a.label();
        let not_set = a.label();
        let not_reset = a.label();
        let reset_defaults = a.label();
        let apply_defaults = a.label();
        let reset_flash = a.label();
        let reset_flash_saved = a.label();
        let not_save = a.label();
        let clr = a.label();
        let clr_loop = a.label();
        let clrd = a.label();
        let not_get = a.label();
        let not_flash = a.label();
        let flash_refuse = a.label();
        let flash_reply = a.label();
        let not_dump = a.label();
        let dump_loop = a.label();
        let id_loop = a.label();
        let id_done = a.label();
        let tbl_loop = a.label();
        let docommit = a.label();

        // knock preamble: two distinct knocks route to two isolated dispatches.
        //   cdb[1] must equal KNOCK_MODE (freemkv's sub-command mode)  → else OEM
        //   cdb[2..4] == KNOCK        (safe knock)  → safe dispatch  (knock_ok)
        //   cdb[2..4] == DEBUG_KNOCK  (debug knock) → debug dispatch (debug_ok)
        //   else → OEM tail-call
        //
        // The two branches share NO verb bytes: a typo of a safe verb vs a debug
        // verb (e.g. Set 0x02 vs Call 0x0C) is safe by construction — the wrong
        // knock never reaches the wrong dispatch. Debug-only verbs (Call, Poke,
        // and any future tear-down primitive) live ONLY under DEBUG_KNOCK; every
        // durable verb lives under KNOCK.
        let debug_ok = a.label();
        let try_debug_knock = a.label();
        a.ldr_lit(3, cdb);
        a.ldrb_imm(0, 3, 1);
        a.cmp_imm(0, abi::KNOCK_MODE);
        a.bne(tail);
        a.ldrb_imm(0, 3, 2);
        a.cmp_imm(0, abi::KNOCK[0]);
        a.bne(try_debug_knock);
        a.ldrb_imm(0, 3, 3);
        a.cmp_imm(0, abi::KNOCK[1]);
        a.bne(try_debug_knock);
        a.b(knock_ok);

        a.bind(try_debug_knock);
        a.ldrb_imm(0, 3, 2);
        a.cmp_imm(0, abi::DEBUG_KNOCK[0]);
        a.bne(tail);
        a.ldrb_imm(0, 3, 3);
        a.cmp_imm(0, abi::DEBUG_KNOCK[1]);
        a.bne(tail);
        a.b(debug_ok);

        // knock miss: tail-call the original handler, registers/lr as entered.
        a.bind(tail);
        a.ldr_lit(3, oem_handler | 1);
        a.bx(3);

        // DEBUG-KNOCK dispatch — reached ONLY when cdb[2..4] == DEBUG_KNOCK. r4 = verb
        // byte (cdb[4]) so multiple debug primitives can share this branch:
        //   Verb::Call (0x0C): blx target(r0), where target = cdb[5..9] BE and
        //                      r0 = cdb[9] (a single u8 register arg).
        //   Verb::Poke (0x0D): *(u8*)target = value, where target = cdb[5..9] BE
        //                      and value = cdb[9]. NO bounds check — this is a
        //                      diagnostic primitive for on-drive state discovery.
        //   (any other verb): zeroed reply, no side effect.
        //
        // Both primitives assemble the 32-bit target VA in r6 upfront, then the
        // verb match picks the tail. Callee-saved r5/r6 are used for the target
        // and thumb-bit scratch so the OEM function/MMIO write sees a clean r0.
        a.bind(debug_ok);
        a.push(0x01F0); // push {r4,r5,r6,r7,lr}
        a.ldr_lit(7, writer | 1); // r7 = byte-writer for `clr`
        a.ldrb_imm(4, 3, abi::CDB_VERB as u16); // r4 = verb = cdb[4]
                                                // Assemble the 32-bit target VA in r6 (both Call and Poke use it).
        a.ldrb_imm(6, 3, 5);
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 6);
        a.adds_reg(6, 6, 0); // |= target[23:16]
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 7);
        a.adds_reg(6, 6, 0); // |= target[15:8]
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 8);
        a.adds_reg(6, 6, 0); // |= target[7:0]  → r6 = full 32-bit VA

        // Verb::Call → thumb-OR r6, load r0 = cdb[9] arg, blx.
        //
        // The trailing `movs r4,#0` before `b(clr)` is a SAFETY CLOBBER: the
        // safe-verb dispatch chain (bind(clr) → clr_loop → clrd → FlashWrite →
        // Save → Get → DumpAll → Identity → docommit) reads r4 as the verb byte.
        // On a DEBUG_KNOCK frame the verb byte might collide with a safe verb id
        // (e.g. FlashWrite=0x0A, Save=0x0B, Get=0x03, DumpAll=0x09, Identity=0x01),
        // so without clobbering r4 the fall-through into `clr` would then match
        // the safe verb and execute it under DEBUG_KNOCK — breaking the
        // documented "no safe verb via DEBUG_KNOCK" invariant. Setting r4=0 makes
        // every safe `cmp r4,#imm` bne past the dispatch and reach `docommit`
        // with a well-formed zeroed reply, no side effects.
        let not_debug_call = a.label();
        a.cmp_imm(4, abi::Verb::Call as u8);
        a.bne(not_debug_call);
        a.movs_imm(5, 1);
        a.orrs(6, 5); // r6 |= 1 (Thumb bit for blx)
        a.ldrb_imm(0, 3, 9); // r0 = cdb[9] (single u8 register arg)
        a.blx(6);
        a.movs_imm(4, 0); // clobber verb byte before falling through to safe dispatch
        a.b(clr);
        a.bind(not_debug_call);

        // Verb::Poke → *(u8*)r6 = cdb[9]. Direct byte store; no thumb OR, no blx.
        let not_debug_poke = a.label();
        a.cmp_imm(4, abi::Verb::Poke as u8);
        a.bne(not_debug_poke);
        a.ldrb_imm(0, 3, 9); // r0 = value
        a.strb_imm(0, 6, 0); // *r6 = r0
        a.movs_imm(4, 0); // clobber verb byte (see Call arm comment above)
        a.b(clr);
        a.bind(not_debug_poke);

        // Verb::Reboot → invoke the firmware's boot function entry with r0=4 to
        // force the cold path (BSS clear + C-runtime data init + full post-init).
        // The target VA is BAKED at build time (per-image, resolved from the
        // boot-init signature = `boot_init_site - 0x10` for the modern MT1959
        // convergence-bl geometry). The literal is Thumb-tagged so `blx target`
        // jumps in Thumb mode. r0=4 makes the boot function's `ldr r0,[r0,#0x18];
        // lsls #0x18; bmi <warm>` take the cold arm on every start-up shape. The
        // drive resets the CPU inside the callee, so control never returns here.
        //
        // When boot_function_entry == 0 (Reboot unavailable: build path where the
        // boot-init site did not resolve OR non-modern-geometry callers like the
        // classic path where `site - 0x10` does not point at a valid function
        // entry), the arm is emitted as INERT: just `cmp/bne/clobber/b clr`,
        // no `blx`. The verb still returns a zeroed reply; it just doesn't reset.
        let not_debug_reboot = a.label();
        a.cmp_imm(4, abi::Verb::Reboot as u8);
        a.bne(not_debug_reboot);
        if boot_function_entry != 0 {
            a.ldr_lit(6, boot_function_entry | 1); // r6 = boot function entry | Thumb bit
            a.movs_imm(0, 4); // r0 = 4 (cold-path selector)
            a.blx(6);
        }
        a.movs_imm(4, 0); // clobber verb byte (see Call arm comment above)
        a.b(clr);
        a.bind(not_debug_reboot);

        // Unknown debug verb → zeroed reply. Verb byte must be clobbered before
        // falling through to `clr` so a safe-verb-id in cdb[4] under DEBUG_KNOCK
        // does not execute the safe verb (see Call arm comment above).
        a.movs_imm(4, 0);
        a.b(clr);

        // SAFE-KNOCK dispatch — reached when cdb[2..4] == KNOCK.
        // r7 = byte-writer, r4 = verb (cdb[4]).
        a.bind(knock_ok);
        a.push(0x01F0); // push {r4,r5,r6,r7,lr}
        a.ldr_lit(7, writer | 1);
        a.ldrb_imm(4, 3, abi::CDB_VERB as u16); // r4 = verb = cdb[4]

        // SET: flag[cdb[5]=feature] = cdb[6]=state. r3=CDB base, r4=verb preserved.
        a.cmp_imm(4, abi::Verb::Set as u8);
        a.bne(not_set);
        a.ldr_lit(0, flag_base); // r0 = flag-table base (SRAM)
        a.ldrb_imm(1, 3, abi::CDB_FEATURE as u16); // r1 = feature id (cdb[5])
                                                   // Bounds-clamp the feature id: valid ids are 1..=NUM_FEATURES — id 0 (the
                                                   // NV saved-marker slot) is rejected, and anything >= NUM_FEATURES+1 is
                                                   // rejected too (return a zeroed buffer, no write). Without the lower bound
                                                   // an id of 0 would corrupt the NV saved-marker cell; without the upper bound
                                                   // an id such as 0xC8 would `strb` into live SRAM past the flag hole.
        a.cmp_imm(1, 1);
        let set_lo_ok = a.label();
        a.bhs(set_lo_ok);
        a.b(clr); // id == 0 → refuse (slot-0 is the NV saved-marker)
        a.bind(set_lo_ok);
        a.cmp_imm(1, NUM_FEATURES + 1);
        // bhs(clr) is out of T1 range now that the bare-VID CDB build has grown
        // the SET body. Reroute via a local blo skip + T2 unconditional b(clr).
        let feature_ok = a.label();
        a.blo(feature_ok);
        a.b(clr);
        a.bind(feature_ok);
        a.adds_reg(0, 0, 1); // r0 = &flag[feature]
        a.ldrb_imm(1, 3, abi::CDB_STATE as u16); // r1 = state (cdb[6])
        a.strb_imm(1, 0, 0); // flag[feature] = state
                             // No rearm-on-SET. Image-wide BL scan (0.8.14) proved the OEM re-arms
                             // bus-encryption ONLY via its non-BL disc-insert path (a hardware/ISR
                             // event), never through a `bl <aacs_session_rearm>` — the sole caller
                             // of that wrapper is inside the cold-boot init at 0x0013d444, and there
                             // is no `blx <thumb-tagged>` dispatch either (the wrapper's VA is not
                             // present as a 32-bit literal anywhere in the image). Firing the
                             // wrapper from a vendor-CDB SET context couples its session_reset +
                             // subsystem re-init side-effects into the shared engine data path and
                             // wedges every subsequent vendor CDB, even when re-arming an already-
                             // armed engine (i.e. with no medium). The AKE detour handles both
                             // directions of `Feature::Encryption` in software on the next data
                             // read regardless of the hardware arm state, so SET only needs to
                             // record the flag — hardware re-arms bus-enc itself when the disc-insert
                             // ISR runs. The `find_aacs_session_rearm` finder stays (its KAT still
                             // exercises it) for the record; nothing bakes it into the handler.
        a.b(clr); // return a zeroed buffer
        a.bind(not_set);

        // RESET: mode rides in the state slot cdb[6]. Three modes:
        //   RESET_TO_OEM      (0xFF) → TRUE OEM: force every RAM flag to passthrough
        //                              (0xFF) AND blank the NV block (write it all
        //                              0xFF, marker included) so the drive is
        //                              byte-for-byte a never-saved drive — traceless.
        //   RESET_TO_DEFAULTS (0x01) → restore the baked create-time DEFAULT_FLAGS
        //                              (e.g. UHD/BD on) into RAM. RAM-only.
        //   RESET_TO_FLASH    (0x00) → reload the saved config (marker-gated); a
        //                              never-saved drive (marker 0xFF) falls back to
        //                              the image defaults.
        // All fall through to clear → zeroed buffer.
        a.cmp_imm(4, abi::Verb::Reset as u8);
        a.bne(not_reset);
        a.ldrb_imm(0, 3, abi::CDB_STATE as u16); // r0 = mode (cdb[6])
                                                 // RESET_TO_OEM (0xFF): RAM all-passthrough + blank NV (traceless).
        a.cmp_imm(0, abi::RESET_TO_OEM);
        a.bne(reset_defaults);
        a.ldr_lit(0, flag_base);
        a.movs_imm(1, abi::STATE_PASSTHROUGH); // 0xFF
        for off in 0..=NUM_FEATURES {
            a.strb_imm(1, 0, off as u16); // RAM flag[0..=6] = 0xFF (incl slot-0 marker)
        }
        // Persist the all-0xFF table to NV via the SAVE flash primitive (staging
        // source = the flag table we just filled). This clears the slot-0 marker to
        // 0xFF, so the NV is indistinguishable from never-saved; op=1 RMW preserves
        // the OEM region record at +0x4B0. Unlike SAVE, we do NOT stamp the marker.
        emit_flash_write(
            &mut a,
            nv_dram_base_ptr,
            save_home,
            flag_base,
            SAVE_LEN,
            flash_program,
        );
        a.b(clr);
        // RESET_TO_DEFAULTS (0x01): restore the baked DEFAULTS to RAM (slots 0..=7).
        a.bind(reset_defaults);
        a.cmp_imm(0, abi::RESET_TO_DEFAULTS);
        a.bne(reset_flash);
        a.bind(apply_defaults);
        a.ldr_lit(0, flag_base);
        for (off, &val) in defaults.flags().iter().enumerate() {
            a.movs_imm(1, val);
            a.strb_imm(1, 0, off as u16);
        }
        a.b(clr);
        // RESET_TO_FLASH (0x00, and the default for any other mode): marker-gated
        // reload, explicitly requested by the host. Slot-0 marker 0xFF = never saved → restore
        // DEFAULTS; else copy the saved feature bytes (1..=NUM_FEATURES) verbatim.
        a.bind(reset_flash);
        a.ldr_lit(6, flag_base); // r6 = flag-table base (SRAM), callee-saved
        a.ldr_lit(2, save_home); // r2 = flash source base (NV/SAVE home)
        a.ldrb_imm(1, 2, 0); // r1 = NV slot-0 saved marker
        a.cmp_imm(1, abi::STATE_PASSTHROUGH); // 0xFF == never saved
        a.bne(reset_flash_saved);
        // Both paths have identical default-restoration semantics. Share the
        // existing body rather than injecting a second copy into scarce flash.
        a.b(apply_defaults);
        a.bind(reset_flash_saved);
        for off in 1..SAVE_LEN {
            a.ldrb_imm(1, 2, off as u16); // r1 = saved flag[off]
            a.strb_imm(1, 6, off as u16); // flag[off] = saved value
        }
        a.b(clr);
        a.bind(not_reset);
        // fall through to clear → zeroed buffer.

        // Clear CLEAR_LEN bytes so no stale buffer data leaks (all data verbs
        // lead with their payload; the remainder stays zero).
        a.bind(clr);
        a.movs_imm(5, 0);
        a.bind(clr_loop);
        a.cmp_imm(5, CLEAR_LEN);
        a.bhs(clrd);
        a.mov_reg(0, 5);
        a.movs_imm(1, 0);
        a.blx(7);
        a.adds_imm(5, 1);
        a.b(clr_loop);
        a.bind(clrd);

        // FLASHWRITE (TEMPORARY diagnostic): program the byte cdb[9] to the 32-bit
        // flash offset packed big-endian in cdb[5..9], via the OEM PROGRAM routine
        // — but only after a HARD range-check against the compile-time safe-cell
        // allowlist. An out-of-allowlist offset refuses (PROGRAM NOT called) with a
        // distinct status word, so this verb can physically only write the erased
        // non-CMAC gap. Reply = offset echo (BE, [0..4]) + status word (BE, [4..8]).
        let scratch_cell = flag_base + FLASHWRITE_SCRATCH_OFF;
        a.cmp_imm(4, abi::Verb::FlashWrite as u8);
        a.bne(not_flash);
        // r6 = flash offset from cdb[5..9] (big-endian). r6 is callee-saved, so it
        // survives the OEM PROGRAM call and the byte-writer reply loop.
        a.ldrb_imm(6, 3, 5); // off[31:24]
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 6);
        a.adds_reg(6, 6, 0); // |= off[23:16]
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 7);
        a.adds_reg(6, 6, 0); // |= off[15:8]
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 8);
        a.adds_reg(6, 6, 0); // |= off[7:0]  → r6 = full 32-bit offset
                             // stage the source byte cdb[9] into the SRAM scratch cell (harmless if
                             // the range check then refuses — the PROGRAM routine is never reached).
        a.ldrb_imm(0, 3, 9); // r0 = value byte (cdb[9])
        a.ldr_lit(1, scratch_cell);
        a.strb_imm(0, 1, 0); // *scratch = value
                             // SAFETY range check: refuse unless LO <= off < HI. On refuse the OEM
                             // PROGRAM routine is NOT called — the probe can only ever touch the gap.
        a.ldr_lit(0, FLASHWRITE_ALLOW_LO);
        a.cmp_reg(6, 0);
        a.blo(flash_refuse); // off < LO → refuse
        a.ldr_lit(0, FLASHWRITE_ALLOW_HI);
        a.cmp_reg(6, 0);
        a.bhs(flash_refuse); // off >= HI → refuse
                             // armed: program(r0=&scratch, r1=off, r2=1, r3=1) — op=1 is the OEM
                             // erase-aligned read-modify-write. r3 (cdb base) is dead here (all cdb
                             // fields already read), so reusing it as the op arg is safe.
        a.ldr_lit(0, scratch_cell);
        a.mov_reg(1, 6);
        a.movs_imm(2, 1);
        a.movs_imm(3, 1);
        a.ldr_lit(5, flash_program | 1);
        a.blx(5); // r0 = PROGRAM status word (r4-r11 preserved → r6 offset survives)
        a.mov_reg(4, 0); // r4 = status word (callee-saved; survives the reply writes)
        a.b(flash_reply);
        a.bind(flash_refuse);
        a.ldr_lit(4, FLASHWRITE_REFUSE_STATUS); // r4 = "REFU" sentinel (PROGRAM not called)
        a.bind(flash_reply);
        // reply: offset echo at [0..4], status word at [4..8], both big-endian.
        emit_be_word_to_response(&mut a, 6, 0);
        emit_be_word_to_response(&mut a, 4, 4);
        a.b(docommit);
        a.bind(not_flash);

        // SAVE (0x0B): persist the live flag table to flash SAVE_HOME. The OEM PROGRAM
        // engine reads its program-source through the DRAM-window translation, so we
        // FIRST stage the 8 flag bytes SRAM->DRAM (dram_base + buf_off, both boot-set
        // globals read at runtime), then call PROGRAM with the WINDOW OFFSET as src.
        // op=1 RMW preserves the OEM region record at +0x4B0. Reply = status (BE) [0..4].
        a.cmp_imm(4, abi::Verb::Save as u8);
        a.bne(not_save);
        // Stamp the saved-marker into flag-table slot 0 BEFORE staging, so the
        // persisted NV block records "a config exists" (slot 0 != 0xFF). The boot
        // hook / RESET_TO_FLASH test this marker: 0xFF (erased) → baked DEFAULTS,
        // else → the saved feature bytes. Without the stamp, a deliberately-saved
        // all-0xFF config would be indistinguishable from never-saved and the boot
        // hook would wrongly re-apply DEFAULTS.
        a.ldr_lit(0, flag_base);
        a.movs_imm(1, NV_SAVED_MARKER);
        a.strb_imm(1, 0, 0); // flag[0] = saved marker (slot 0)
                             // Persist the live flag table to flash SAVE_HOME via the reusable flash-write
                             // primitive (stage SRAM->DRAM window, then OEM PROGRAM op=1 RMW).
        emit_flash_write(
            &mut a,
            nv_dram_base_ptr,
            save_home,
            flag_base,
            SAVE_LEN,
            flash_program,
        );
        a.mov_reg(4, 0); // r4 = status (callee-saved; survives the reply writes)
        emit_be_word_to_response(&mut a, 4, 0);
        a.b(docommit);
        a.bind(not_save);

        // GET: response byte 0 = flag[cdb[5]=feature].
        a.cmp_imm(4, abi::Verb::Get as u8);
        a.bne(not_get);
        a.ldr_lit(0, flag_base);
        a.ldrb_imm(1, 3, abi::CDB_FEATURE as u16); // r1 = feature id
                                                   // Bounds-clamp the feature id (same window as SET): valid ids are 1..=NUM_FEATURES —
                                                   // id 0 (the NV saved-marker slot) is rejected, and >= NUM_FEATURES+1 is rejected
                                                   // (else it would `ldrb` from live SRAM past the flag hole). Out of range → fall
                                                   // through to `not_get` (verb isn't DumpAll/Identity either, so it reaches
                                                   // `docommit` and returns the already-zeroed buffer).
        a.cmp_imm(1, 1);
        a.blo(not_get); // id == 0 → refuse (slot-0 is the NV saved-marker)
        a.cmp_imm(1, NUM_FEATURES + 1);
        a.bhs(not_get);
        a.adds_reg(0, 0, 1); // r0 = &flag[feature]
        a.ldrb_imm(1, 0, 0); // r1 = flag byte
        a.movs_imm(0, 0); // response offset 0
        a.blx(7);
        a.b(docommit);
        a.bind(not_get);

        // DUMPALL: peek CLEAR_LEN bytes at the 32-bit addr big-endian in cdb[5..9].
        a.cmp_imm(4, abi::Verb::DumpAll as u8);
        a.bne(not_dump);
        a.ldrb_imm(6, 3, 5); // addr[31:24]
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 6);
        a.adds_reg(6, 6, 0); // |= addr[23:16]
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 7);
        a.adds_reg(6, 6, 0); // |= addr[15:8]
        a.lsls_imm(6, 6, 8);
        a.ldrb_imm(0, 3, 8);
        a.adds_reg(6, 6, 0); // |= addr[7:0]  → r6 = full 32-bit address
        a.movs_imm(5, 0);
        a.bind(dump_loop);
        a.cmp_imm(5, CLEAR_LEN);
        a.bhs(docommit);
        a.mov_reg(0, 5);
        a.ldrb_reg(1, 6, 5);
        a.blx(7);
        a.adds_imm(5, 1);
        a.b(dump_loop);
        a.bind(not_dump);

        // IDENTITY: RESP_MAGIC + version, then the live feature-state table.
        // Any other (unknown) verb falls through to docommit → zeroed buffer.
        a.cmp_imm(4, abi::Verb::Identity as u8);
        a.bne(docommit);
        let blob = a.data_blob(identity);
        a.adr(6, blob);
        a.movs_imm(5, 0);
        a.bind(id_loop);
        a.cmp_imm(5, id_len);
        a.bhs(id_done);
        a.mov_reg(0, 5);
        a.ldrb_reg(1, 6, 5);
        a.blx(7);
        a.adds_imm(5, 1);
        a.b(id_loop);
        a.bind(id_done);
        // append flag[0x01..=0x06] at offsets id_len.. (r5 = dest offset, r2 = feature).
        a.ldr_lit(6, flag_base);
        a.movs_imm(5, id_len);
        a.movs_imm(2, 1);
        a.bind(tbl_loop);
        a.cmp_imm(2, NUM_FEATURES + 1); // stop after feature 0x06
        a.bhs(docommit);
        a.ldrb_reg(1, 6, 2); // r1 = flag[feature]
        a.mov_reg(0, 5); // dest offset
        a.blx(7);
        a.adds_imm(5, 1);
        a.adds_imm(2, 1);
        a.b(tbl_loop);

        // length + commit + return good.
        a.bind(docommit);
        a.movs_imm(0, CLEAR_LEN);
        a.ldr_lit(1, length_field);
        a.strh_imm(0, 1, 0);
        a.ldr_lit(0, commit_off);
        a.ldr_lit(2, commit | 1);
        a.blx(2);
        a.pop(0x01F0); // pop {r4,r5,r6,r7,pc}
        a.finish().map_err(anyhow::Error::from)
    }

    /// The Speed (0x02) flag-gated ceiling trampoline. Entered by a `bl` that
    /// replaces the OEM ramp gate's own `cmp r2,#0x32; bhi <exit>` (the ramp is
    /// otherwise UNTOUCHED). On entry `r2 = speed_index`; `r1`/`r4` are live and
    /// preserved; `r0` is live at the fall-through so it is saved/restored; `lr`
    /// is dead (the ramp saved it on its own stack). The stub reads the Speed
    /// flag byte and compares `speed_index` against `0xFF` (the drive's own
    /// unlimited sentinel) when set or `0x32` (OEM band) when clear, then
    /// replicates the OEM `bhi` and returns to the exact ramp instruction the OEM
    /// gate would have. `fallthrough`/`exit` are the two OEM continuation VAs.
    pub(crate) fn build_speed_stub(
        &self,
        flag_base: u32,
        fallthrough: u32,
        exit: u32,
        idx_reg: u8,
    ) -> Result<Vec<u8>> {
        // flag[Feature::Speed] tri-state: `STATE_PASSTHROUGH` (0xFF) = OEM (compare
        // against the OEM 0x32 band); `STATE_ON` (0x01) = unlimited (compare against
        // the drive's own `0xFF` sentinel); any OTHER value is an explicit speed-cap
        // byte (compare `speed_index` against it directly), so `STATE_OFF` (0x00) =
        // cap 0 = the floor (slowest / riplock fully engaged) — the genuine OFF,
        // reached through the same cap path. The boot hook guarantees `0xFF` at
        // power-on, so a gate never sees the `0x00` cap unless the host set it.
        let mut a = Asm::new();
        let patched = a.label();
        let oem = a.label();
        let decide = a.label();
        let go_exit = a.label();
        let flag_cell = flag_base + abi::Feature::Speed as u32;
        if idx_reg == 2 {
            // Original shape: speed_index in r2; r0 is live at the ramp fall-through
            // so it is saved/restored and doubles as the flag scratch.
            a.push(0x0001); // push {r0}          save r0 (live at ramp fall-through)
            a.ldr_lit(0, flag_cell); // r0 = &flag[Speed]
            a.ldrb_imm(0, 0, 0); // r0 = Speed flag byte
            a.cmp_imm(0, abi::STATE_ON); // 0x01 -> unlimited
            a.beq(patched);
            a.cmp_imm(0, abi::STATE_PASSTHROUGH); // 0xFF -> OEM
            a.beq(oem);
            a.cmp_reg(2, 0); // explicit cap (incl 0x00 OFF = floor): speed_index vs cap byte
            a.b(decide);
            a.bind(patched);
            a.cmp_imm(2, 0xFF); // unlimited: the drive's own 0xFF sentinel
            a.b(decide);
            a.bind(oem);
            a.cmp_imm(2, 0x32); // OEM ramp self-ceiling band
            a.bind(decide);
            a.pop(0x0001); // pop {r0}           restore r0 (POP preserves flags)
            a.bhi(go_exit); // replicate the OEM `bhi <ramp-exit>`
            a.ldr_lit(2, fallthrough | 1); // fall-through: r2 dead at the OEM target
            a.bx(2); // continue the OEM ramp
            a.bind(go_exit);
            a.ldr_lit(2, exit | 1); // taken: r2 dead at the OEM ramp-exit target
            a.bx(2); // jump to the OEM ramp exit
        } else {
            // r0 variant: speed_index in r0 (DEAD after the gate — the OEM ramp
            // redefines it), so r0 needs no saving; the flag byte lives in r1, which
            // is saved/restored around the compare (r1 = cell ptr, may be live).
            a.push(0x0002); // push {r1}          save r1 (cell ptr; may be live)
            a.ldr_lit(1, flag_cell); // r1 = &flag[Speed]
            a.ldrb_imm(1, 1, 0); // r1 = Speed flag byte
            a.cmp_imm(1, abi::STATE_ON); // 0x01 -> unlimited
            a.beq(patched);
            a.cmp_imm(1, abi::STATE_PASSTHROUGH); // 0xFF -> OEM
            a.beq(oem);
            a.cmp_reg(0, 1); // explicit cap (incl 0x00 OFF = floor): speed_index vs cap byte
            a.b(decide);
            a.bind(patched);
            a.cmp_imm(0, 0xFF); // unlimited: the drive's own 0xFF sentinel
            a.b(decide);
            a.bind(oem);
            a.cmp_imm(0, 0x32); // OEM ramp self-ceiling band
            a.bind(decide);
            a.pop(0x0002); // pop {r1}           restore r1 (POP preserves flags)
            a.bhi(go_exit); // replicate the OEM `bhi <ramp-exit>`
            a.ldr_lit(0, fallthrough | 1); // fall-through: r0 dead at the OEM target
            a.bx(0); // continue the OEM ramp
            a.bind(go_exit);
            a.ldr_lit(0, exit | 1); // taken: r0 dead at the OEM ramp-exit target
            a.bx(0); // jump to the OEM ramp exit
        }
        a.finish().map_err(anyhow::Error::from)
    }

    /// The Region-free (0x03) flag-gated RPC-emitter trampoline. Entered by a `bl`
    /// that replaces the OEM emitter's `frame[4]` store `strb r2,[r0,#8]` and the
    /// following `mov r3,sp` at `region_emitter+6`. On entry `r0 = FIFO data-port
    /// base`, `r1 == 0`, `r2 == frame[4]` (OEM TypeCode/reset/change counters),
    /// `r4 == 1`, and `sp[3]` is the RegionMask source (all per the OEM emitter).
    /// When the flag is set the stub zeroes `frame[4..6]` (TypeCode 0, RegionMask
    /// 0x00, RPCScheme 0 → RPC-1 — golden-MK parity) else it replicates the OEM
    /// `frame[4..6]`; both then emit reserved `frame[7]=0` and `pop {r3,r4,pc}`.
    pub(crate) fn build_region_stub(&self, flag_base: u32) -> Result<Vec<u8>> {
        // flag[Feature::Region] tri-state: `STATE_PASSTHROUGH` (0xFF) = OEM (stealth;
        // the boot hook guarantees this at power-on); `STATE_ON` (0x01) = RPC-1
        // region-free (zero frame[4..6]); `STATE_OFF` (0x00) = region-LOCKED (RPC-2,
        // RegionMask 0xFF → no region playable — the genuine OFF); `0x11..=0x18` =
        // force DVD region 1..8; `REGION_BD_A/B/C` (0x2A/2B/2C) = force BD region
        // A/B/C; anything else = OEM.
        //
        // Force-region writes a specific RegionMask into `frame[5]`:
        //   * DVD (RPC-2 state): the standard inverted bitmask `~(1<<(region-1))`
        //     (one region enabled) from a lookup table, RPCScheme (`r4`==1) kept.
        //   * BD: a region index (A=1/B=2/C=4) placeholder in `frame[5]`.
        // HARDWARE-KAT-GATED: the exact force-region mask encoding is a hypothesis;
        // the OEM and RPC-1 paths (the KAT-exercised ones) are structurally proven.
        // DVD region mask table: region N (1..8) enabled → 0xFF & ~(1<<(N-1)).
        const DVD_MASKS: [u8; 8] = [0xFE, 0xFD, 0xFB, 0xF7, 0xEF, 0xDF, 0xBF, 0x7F];
        // BD region A/B/C placeholder masks.
        const BD_MASKS: [u8; 3] = [0x01, 0x02, 0x04];

        let mut a = Asm::new();
        let region_free = a.label();
        let region_lock = a.label();
        let dvd_force = a.label();
        let bd_force = a.label();
        let oem = a.label();
        let tail = a.label();
        a.ldr_lit(3, flag_base + abi::Feature::Region as u32); // r3 = &flag[Region] (r3 popped)
        a.ldrb_imm(3, 3, 0); // r3 = Region flag byte
        a.cmp_imm(3, abi::STATE_ON); // 0x01 -> RPC-1 free
        a.beq(region_free);
        a.cmp_imm(3, abi::STATE_OFF); // 0x00 -> region-locked (genuine OFF)
        a.beq(region_lock);
        a.cmp_imm(3, 0x11);
        a.blo(oem); // 0x02..0x10 -> OEM (0x00/0x01/0xFF already handled)
        a.cmp_imm(3, 0x19);
        a.blo(dvd_force); // 0x11..=0x18 -> DVD force
        a.cmp_imm(3, abi::REGION_BD_A);
        a.blo(oem); // 0x19..0x29 -> OEM
        a.cmp_imm(3, abi::REGION_BD_C + 1);
        a.blo(bd_force); // 0x2A..=0x2C -> BD force
                         // fall through: >= 0x2D -> OEM

        a.bind(oem);
        a.strb_imm(2, 0, 8); // frame[4] = r2 (OEM TypeCode/#resets/#changes)
        a.mov_reg(3, 13); // mov r3,sp — re-read the RegionMask source from sp[3]
        a.ldrb_imm(2, 3, 3); // r2 = s3 (frame[4] already emitted, r2 free)
        a.strb_imm(2, 0, 8); // frame[5] = s3 (OEM RegionMask)
        a.strb_imm(4, 0, 8); // frame[6] = r4 (RPCScheme = 1, RPC-2)
        a.b(tail);

        a.bind(region_free);
        a.strb_imm(1, 0, 8); // frame[4] = 0 (TypeCode/resets/changes cleared)
        a.strb_imm(1, 0, 8); // frame[5] = 0 (RegionMask → all regions playable)
        a.strb_imm(1, 0, 8); // frame[6] = 0 (RPCScheme → RPC-1, region-free)
        a.b(tail);

        a.bind(region_lock);
        // Genuine OFF: force RPC-2 with RegionMask 0xFF (every region prohibited →
        // the disc plays in no region). HARDWARE-KAT-GATED: the all-set mask == fully
        // locked is the standard RPC-2 encoding but is not re-proven on this silicon.
        a.strb_imm(2, 0, 8); // frame[4] = r2 (OEM TypeCode/#resets/#changes)
        a.movs_imm(2, 0xFF); // r2 = 0xFF (all 8 regions prohibited)
        a.strb_imm(2, 0, 8); // frame[5] = 0xFF (no region playable)
        a.strb_imm(4, 0, 8); // frame[6] = r4 (RPCScheme = 1, RPC-2)
        a.b(tail);

        a.bind(dvd_force);
        let dvd = a.data_blob(DVD_MASKS.to_vec());
        a.strb_imm(2, 0, 8); // frame[4] = r2 (OEM TypeCode)
        a.subs_imm(3, 0x11); // r3 = region index 0..7
        a.adr(2, dvd);
        a.ldrb_reg(2, 2, 3); // r2 = DVD_MASKS[index]
        a.strb_imm(2, 0, 8); // frame[5] = forced DVD RegionMask
        a.strb_imm(4, 0, 8); // frame[6] = r4 (RPCScheme = 1, RPC-2)
        a.b(tail);

        a.bind(bd_force);
        let bd = a.data_blob(BD_MASKS.to_vec());
        a.strb_imm(2, 0, 8); // frame[4] = r2 (OEM TypeCode)
        a.subs_imm(3, abi::REGION_BD_A); // r3 = 0..2 (A/B/C)
        a.adr(2, bd);
        a.ldrb_reg(2, 2, 3); // r2 = BD_MASKS[index]
        a.strb_imm(2, 0, 8); // frame[5] = forced BD region mask
        a.strb_imm(4, 0, 8); // frame[6] = r4 (RPCScheme = 1)
        a.b(tail);

        a.bind(tail);
        a.strb_imm(1, 0, 8); // frame[7] = 0 (reserved, always)
        a.pop(0x0118); // pop {r3,r4,pc} — replicate the emitter epilogue
        a.finish().map_err(anyhow::Error::from)
    }

    /// The Raw Read (0x04) flag-gated AKE accept-gate trampoline. Entered by a
    /// Thumb-1 `BL` that replaces the OEM
    /// RESET writer's `movs r1,#1; b <back>` at [`AKE_GATE_SIG`]'s `match+12`
    /// after source-qualifying its native shared call join. On entry
    /// `r0 = AGID` (set by the preceding `ldrb/lsrs`), which is preserved. The
    /// stub picks the per-AGID state to write: `6` (AKE authenticated → VID
    /// gate open) when `flag[Ake]==STATE_OFF`, else the OEM `1` (auth failed →
    /// reset). It then jumps to `back` — the OEM `set_agid_state(r0, r1)` call
    /// the reset writer branched to — so the store happens through the OEM
    /// primitive unchanged. `back` is a native `BL` instruction, not the leaf
    /// setter itself: that call defines LR before the setter observes it. Its
    /// first CMP also replaces incoming flags, and r2 is defined before use.
    /// The caller's saved return frame is proven by `SavedLink`. Older comments
    /// incorrectly described this join as a direct tail call; the source-bound
    /// qualification below deliberately refuses such a layout.
    ///
    /// This is the `04 02` mode: "accept ANY host cert, revoked or not." The host
    /// still drives the real AKE (`0xA3`/`0xA4`) and may present a revoked (or any)
    /// cert; when the OEM verify FAILS and would reset to state 1, this stub forces
    /// state 6 instead, so the AKE completes and a bus-key `0xAD` read yields the
    /// VID. `04 01` does NOT act here (that mode is the bare-read Gate-A path).
    pub(crate) fn build_ake_stub(&self, flag_base: u32, back: u32, reset: u32) -> Result<Vec<u8>> {
        let mut a = Asm::new();
        let accept = a.label();
        let done = a.label();
        a.ldr_lit(2, flag_base + abi::Feature::Encryption as u32); // r2 = &flag[Encryption]
        a.ldrb_imm(2, 2, 0); // r2 = Encryption flag byte
        a.cmp_imm(2, abi::STATE_OFF); // 0x00 = null AKE / bypass (accept any/revoked host cert); ON/OEM = real handshake
        a.beq(accept);
        a.movs_imm(1, 1); // OEM (00/0xFF): reset to state 1 on a failed cert verify
        a.b(done);
        a.bind(accept);
        // ---- De-bus latch clear (0.9.1) --------------------------------
        // Forcing state 6 opens the VID gate, but the SAME "authenticated"
        // state also ARMS the drive's bus-encryption engine — and the forced
        // path never negotiates a bus key, so the drive wraps content with a
        // key the host does not have. No key can then decrypt the content, and
        // every rip fails after an exhaustive, hopeless key search.
        //
        // The latch is set by power-on AND by the OEM's disc-insert rearm ISR.
        // That is why a boot-time or SET-time clear is NOT enough: any disc
        // change re-arms it while `flag[Encryption]` still reads 0x00, which is
        // exactly the "ripped one disc fine, nothing since" report. Clearing it
        // HERE means it is cleared per-session, for the session about to read,
        // no matter how it came to be set.
        //
        // PROVEN ON HARDWARE (BU40N, fw 0.8.14) before this code was written:
        // cold boot or disc insert -> 0/16 units open; `Verb::Call` to
        // `aacs_session_reset` -> 16/16; 4/4 trials, drive alive each time,
        // the key service then returns the correct key in ~2.5s instead of 422
        // after ~55s.
        //
        // This is the LIGHT primitive deliberately: `aacs_session_reset` does a
        // gate-bit clear plus a mailbox reset and nothing else. The heavier
        // `aacs_session_rearm` wrapper (which also does the bit-20 arm and four
        // subsystem re-inits) is what wedged the engine when fired from a
        // vendor-CDB context in 0.8.14 — see the no-rearm-on-SET note in the
        // handler. Do not "upgrade" this call to the wrapper.
        //
        // Preserve this stub's incoming LR across the nested reset call. The
        // native join replaces it before the setter observes it; the caller's
        // actual return address remains in its source-proven saved frame.
        // Thumb POP cannot write LR, hence pop-into-r2 + MOV LR,r2. The reset
        // callee may clobber r0-r3, so preserve the AGID as well.
        a.push(0x0101); // push {r0, lr}
        a.ldr_lit(2, reset | 1); // r2 = aacs_session_reset (Thumb-tagged)
        a.blx(2); // clobbers lr and r0-r3
        a.pop(0x0005); // pop {r0, r2}    r0 = AGID, r2 = saved lr
        a.mov_reg(14, 2); // mov lr, r2      restore this stub's incoming LR
        a.movs_imm(1, 6); // forced: state 6 (AKE authenticated)
        a.bind(done);
        a.ldr_lit(2, back | 1); // -> OEM set_agid_state(r0=agid, r1=state) call
        a.bx(2);
        a.finish().map_err(anyhow::Error::from)
    }

    /// NB-class Raw Read (0x04) AKE accept-gate trampoline. Entered by a `bl` that
    /// replaces the **shared** `bl set_agid_state` at [`AKE_GATE_SIG_NB`]'s
    /// `anchor+12` — the join BOTH arms reach (`r0 = AGID`, `r1 = 6` on the accept
    /// arm or `1` on the reject arm). Because the accept arm passes through here
    /// too, the stub must **preserve `r1`** when the flag is off (unlike
    /// [`Self::build_ake_stub`], which sits only on the reject writer): it forces
    /// `r1 = 6` only when `flag[Ake]==STATE_OFF`, then tail-jumps to the OEM
    /// `set_agid_state` (`back`) so the store happens through the OEM primitive.
    /// `r2` is scratch (dead at `back`); `lr` is preserved by the outer `bl` and
    /// carries the OEM return, matching the `bl set_agid_state` this replaces.
    pub(crate) fn build_ake_stub_nb(
        &self,
        flag_base: u32,
        back: u32,
        reset: u32,
    ) -> Result<Vec<u8>> {
        let mut a = Asm::new();
        let force = a.label();
        let keep = a.label();
        a.ldr_lit(2, flag_base + abi::Feature::Encryption as u32); // r2 = &flag[Encryption]
        a.ldrb_imm(2, 2, 0); // r2 = Encryption flag byte
        a.cmp_imm(2, abi::STATE_OFF); // 0x00 = null AKE / bypass (accept any/revoked host cert); ON/OEM = real handshake
        a.beq(force);
        a.b(keep); // flag off: preserve r1 (accept arm = 6, reject arm = 1)
        a.bind(force);
        // De-bus latch clear — same rationale and the same hardware proof as
        // [`Self::build_ake_stub`]; see the long note there. Only the forced
        // arm clears, so an OEM/on drive is byte-behaviour-identical.
        //
        // `lr` here is the OEM return set by the `bl` this stub replaces (the
        // caller's `bx lr` needs it), so it is saved and restored across the
        // `blx` exactly as in the BU40N variant. `r1` is NOT saved: this arm
        // overwrites it with 6 immediately afterwards, so the callee clobbering
        // it is harmless — but `r0` (the AGID) is.
        a.push(0x0101); // push {r0, lr}
        a.ldr_lit(2, reset | 1); // r2 = aacs_session_reset (Thumb-tagged)
        a.blx(2); // clobbers lr and r0-r3
        a.pop(0x0005); // pop {r0, r2}   r0 = AGID, r2 = saved lr
        a.mov_reg(14, 2); // mov lr, r2     restore the return address
        a.movs_imm(1, 6); // forced: state 6 (AKE authenticated)
        a.bind(keep);
        a.ldr_lit(2, back | 1); // -> OEM set_agid_state(r0=agid, r1=state) call
        a.bx(2);
        a.finish().map_err(anyhow::Error::from)
    }

    // (Retired 0.8.9: `build_busenc_stub` + `build_debus_stub`. Hardware proved
    // the `Feature::Bus` datapath lever inert, so both stubs and their sigs were
    // removed together. The surviving `Feature::Encryption` de-busses content via
    // `build_ake_stub` alone — empirically verified on BU40N/MT1959.)

    /// The `Feature::Bd` **BD (AACS 1.0) capability-refuse** trampoline. Entered by a
    /// `bl` that replaces the REPORT KEY gate's mode-0 class check `ldrb r0,[r2,#7];
    /// cmp r0,#2` (4 bytes at `MediaGateVariant::Explicit`'s `anchor+16`). On entry `r2 = the
    /// per-disc class struct` (loaded by the gate's own `ldr r2,[pc]`, undisturbed by
    /// a `bl`) and `lr = anchor+20` (the OEM `beq <accept>`, which the gate reaches
    /// only for a mode-0 = BD disc). The stub replays the class load and returns to
    /// that `beq` with the compare flags it needs.
    ///
    /// # Register / frame contract
    /// A bare `bl` (no push), so `sp`/`r2` are unchanged — the replayed `ldrb
    /// r0,[r2,#7]` reads the same class byte the OEM load would. `r0` and `r3` are
    /// scratch: both continuation targets (`<accept>` at `anchor+20`'s branch and the
    /// `<deny>` block) recompute `r0` before use and never read `r3`, so clobbering
    /// them is invisible. `lr` is caller-saved (the enclosing function returns via its
    /// own `pop {…,pc}`), so the `bl`'s `lr` clobber is harmless.
    ///
    /// `flag[Bd]` tri-state at this site (uniform `0xFF`/`0x01`/`0x00`; the old
    /// distinct `0x02` sentinel is retired — the always-on boot hook writes `0xFF`
    /// into every flag at power-on, so `0x00` OFF is never seen at boot and BD can
    /// use the uniform value like every other feature):
    ///   * `!= STATE_OFF` (`0xFF` passthrough / `0x01` on): replay `ldrb r0,[r2,#7];
    ///     cmp r0,#2` verbatim, so the caller's `beq` sees the exact OEM flags — BD
    ///     acceptance is byte-behaviour-identical to OEM. Inert (stealth) until armed.
    ///   * `== STATE_OFF` (`0x00`): after the class replay, force a non-equal compare
    ///     (the already-zero flag compared with one) so the caller's `beq <accept>` is
    ///     NOT taken and control falls into the OEM deny block, which raises the
    ///     drive's own `6F` refusal sense — the drive REFUSES the BD disc.
    pub(crate) fn build_bd_stub(&self, flag_base: u32) -> Result<Vec<u8>> {
        let mut a = Asm::new();
        let refuse = a.label();
        a.ldrb_imm(0, 2, 7); // replay: ldrb r0,[r2,#7]  (r0 = disc class; r2 unchanged by the bl)
        a.ldr_lit(3, flag_base + abi::Feature::Unrestricted as u32); // shared runtime setting
        a.ldrb_imm(3, 3, 0); // r3 = Unrestricted flag byte
        a.cmp_imm(3, abi::STATE_OFF); // 0x00 = force BD refuse (0xFF passthrough / 0x01 on stay OEM; boot hook makes 0x00 unreachable at power-on)
        a.beq(refuse);
        a.cmp_imm(0, 2); // stealth: replay `cmp r0,#2` LAST so the caller's `beq` sees OEM flags
        a.bx(14); // bx lr -> caller's `beq <accept>` at anchor+20 (OEM acceptance)
        a.bind(refuse);
        a.cmp_imm(3, 1); // flag is zero here: Z=0 for every class byte, including 0xff
        a.bx(14);
        a.finish().map_err(anyhow::Error::from)
    }

    /// The `Feature::Unrestricted` **UHD (AACS 2.0) media accept/refuse** trampoline — the UHD
    /// sibling of [`Self::build_bd_stub`] on the SAME REPORT KEY accept gate. Entered
    /// by a `bl` that replaces the gate's UHD class check `ldrb r0,[r2,#7]; cmp r0,#3`
    /// (4 bytes at `MediaGateVariant::Explicit`'s `anchor+4`). On entry `r2 = the per-disc class
    /// struct` (loaded by the gate's own `ldr r2,[pc]`, undisturbed by a `bl`); the
    /// stub replays the class load and returns to `anchor+8` — the OEM `bne <deny>`
    /// that the gate reaches for a class-3 (UHD/AACS-2.0) disc.
    ///
    /// # Register / frame contract
    /// A bare `bl` (no push), so `sp`/`r2` are unchanged — the replayed `ldrb
    /// r0,[r2,#7]` reads the same class byte the OEM load would. `r0`/`r3` are scratch:
    /// the accept continuation (falls through past `anchor+8`) and the shared `<deny>`
    /// block both recompute `r0` before use and never read `r3`, so clobbering them is
    /// invisible. `lr` is caller-saved (the enclosing function returns via its own
    /// `pop {…,pc}`), so the `bl`'s `lr` clobber is harmless.
    ///
    /// `flag[Unrestricted]` tri-state at this site (uniform `0xFF`/`0x01`/`0x00`; the always-on
    /// boot hook writes `0xFF` at power-on, so `0x00` OFF is never seen at boot):
    ///   * `!= STATE_OFF` (`0xFF` passthrough / `0x01` on): replay `ldrb r0,[r2,#7];
    ///     cmp r0,#3` verbatim, so the caller's `bne` sees the exact OEM flags — UHD
    ///     acceptance is byte-behaviour-identical to OEM (this hook preserves the native class check; it does not
    ///     establish detection, reading or complete authentication support). Inert (stealth) until armed OFF.
    ///   * `== STATE_OFF` (`0x00`): after the class replay, force a non-equal compare
    ///     (the already-zero flag compared with one) so the caller's `bne <deny>` IS
    ///     taken and control jumps into the OEM `6F/05` deny block — the drive REFUSES
    ///     the UHD disc, symmetric with the BD arm.
    pub(crate) fn build_uhd_gate_stub(&self, flag_base: u32) -> Result<Vec<u8>> {
        let mut a = Asm::new();
        let refuse = a.label();
        a.ldrb_imm(0, 2, 7); // replay: ldrb r0,[r2,#7]  (r0 = disc class; r2 unchanged by the bl)
        a.ldr_lit(3, flag_base + abi::Feature::Unrestricted as u32); // r3 = &flag[Unrestricted]
        a.ldrb_imm(3, 3, 0); // r3 = Unrestricted flag byte
        a.cmp_imm(3, abi::STATE_OFF); // 0x00 = force UHD refuse (0xFF passthrough / 0x01 on stay OEM)
        a.beq(refuse);
        a.cmp_imm(0, 3); // stealth: replay `cmp r0,#3` LAST so the caller's `bne` sees OEM flags
        a.bx(14); // bx lr -> caller's `bne <deny>` at anchor+8 (class==3 -> Z=1 -> accept)
        a.bind(refuse);
        a.cmp_imm(3, 1); // flag is zero here: Z=0 for every class byte, including 0xff
        a.bx(14);
        a.finish().map_err(anyhow::Error::from)
    }

    /// Emit a native BD-control detour only from a role-validated contract.
    /// Descriptor-pattern candidates remain discoverable for analysis, but they
    /// do not authorize a BD hook on a different structure-response path.
    pub(crate) fn bd_detour(&self, image: &[u8], flag_base: u32) -> Result<(usize, Vec<u8>)> {
        let contract = mediatek_optical::image::analysis::MediaGate::inspect(image)
            .map_err(|error| anyhow!("BD layout: {error}"))?;
        let site = contract.bd_site().ok_or_else(|| anyhow!(
            "descriptor candidate has no proven native BD-control role; refusing to patch an unrelated structure-response path"
        ))?;
        ensure!(
            image.get(site..site + 4) == Some(&[0xd0, 0x79, 0x02, 0x28]),
            "BD displaced instructions do not match the selected contract"
        );
        Ok((site, self.build_bd_stub(flag_base)?))
    }

    /// Resolve the `Feature::Unrestricted` media-gate arm on the SAME AACS accept gate the BD
    /// arm hooks ([`Self::find_bd_gate`]). The explicit REPORT KEY gate carries a UHD
    /// class-3 check `ldrb r0,[r2,#7]; cmp r0,#3` at `anchor+4` (BU40N `0x1365c2`),
    /// paired with a `bne <deny>` at `anchor+8`. Returns `(detour_site, stub_bytes)`
    /// where a `bl` to [`Self::build_uhd_gate_stub`] is written at `anchor+4`, replacing
    /// those 4 bytes; the stub returns to the `bne` at `anchor+8`. Verifies the exact
    /// OEM bytes before returning, so a mis-anchored match refuses rather than patches.
    ///
    /// Only the explicit gate shape (`BD_GATE_SIG`, anchor head `cmp r0,#1` = 0x2801)
    /// exposes this class-3 UHD arm. The descriptor-classifier gate shape
    /// (`BD_GATE_SIG_VER`) buckets disc mode differently and has no class-3 check at a
    /// fixed offset, so UHD is UNAVAILABLE there — this returns an `Err` (the caller
    /// leaves `uhd_stub_va = 0`, feature not applied), never a guessed site.
    pub(crate) fn uhd_gate_detour(&self, image: &[u8], flag_base: u32) -> Result<(usize, Vec<u8>)> {
        let contract = mediatek_optical::image::analysis::MediaGate::inspect(image)
            .map_err(|error| anyhow!("UHD layout: {error}"))?;
        let site = contract.uhd_site().ok_or_else(|| {
            anyhow!("no role-validated native UHD discriminator in this instruction layout")
        })?;
        ensure!(
            image.get(site..site + 4) == Some(&[0xd0, 0x79, 0x03, 0x28]),
            "UHD displaced instructions do not match the selected contract"
        );
        Ok((site, self.build_uhd_gate_stub(flag_base)?))
    }

    /// Three-way auth decision at a role-validated CMP/BNE pair. OEM replays
    /// the displaced comparison, On follows acceptance, Off follows the native
    /// refusal continuation. The generic body preserves every live register.
    pub(crate) fn build_authcell_widen_stub(
        &self,
        flag_base: u32,
        deny_va: u32,
    ) -> Result<Vec<u8>> {
        self.build_authcell_widen_value_stub(flag_base, deny_va, 0)
    }

    /// r1 state-band variant. Preserve every GPR and replay the original flags;
    /// the failure path transfers through the stack without stealing a live scratch.
    pub(crate) fn build_authcell_widen_value_stub(
        &self,
        flag_base: u32,
        deny_va: u32,
        value_register: u8,
    ) -> Result<Vec<u8>> {
        self.build_authcell_widen_scoped_stub(flag_base, deny_va, value_register, None, None)
    }

    fn build_authcell_widen_scoped_stub(
        &self,
        flag_base: u32,
        deny_va: u32,
        value_register: u8,
        minimum_class: Option<u8>,
        scoped_refusal: Option<u32>,
    ) -> Result<Vec<u8>> {
        ensure!(value_register <= 1, "unsupported auth-cell register");
        ensure!(
            minimum_class.is_some() == scoped_refusal.is_some(),
            "incomplete scoped auth refusal contract"
        );
        let mut a = Asm::new();
        let widen = a.label();
        let original_comparison = a.label();
        let force_refusal = a.label();
        let deny = a.label();
        a.push(0x0008);
        a.ldr_lit(3, flag_base + abi::Feature::Unrestricted as u32);
        a.ldrb_imm(3, 3, 0);
        a.cmp_imm(3, abi::STATE_ON);
        a.beq(widen);
        a.cmp_imm(3, abi::STATE_OFF);
        a.beq(force_refusal);
        a.pop(0x0008);
        a.bind(original_comparison);
        a.cmp_imm(value_register.into(), 0xC);
        a.bne(deny);
        a.bx(14);
        a.bind(widen);
        a.pop(0x0008);
        if let Some(minimum) = minimum_class {
            a.cmp_imm(value_register.into(), minimum);
            a.blo(original_comparison);
        }
        a.cmp_imm(value_register.into(), 0xC);
        a.bx(14);
        a.bind(force_refusal);
        a.pop(0x0008);
        if let Some(minimum) = minimum_class {
            // Only the selected BD band is controlled here. Keep the distinct
            // DVD/nibble-4 implementation and every other OEM path untouched.
            a.cmp_imm(value_register.into(), minimum);
            a.blo(original_comparison);
        }
        // Keep the exact displaced CMP flags even on a forced refusal.
        a.cmp_imm(value_register.into(), 0xC);
        if let Some(refusal) = scoped_refusal {
            a.push(0x0108);
            a.ldr_lit(3, refusal | 1);
            a.str_sp(3, 4);
            a.pop(0x0108);
        }
        a.bind(deny);
        a.push(0x0108);
        a.ldr_lit(3, deny_va | 1);
        a.str_sp(3, 4); // str r3,[sp,#4]: replace stacked return with OEM failure continuation
        a.pop(0x0108);
        a.finish().map_err(anyhow::Error::from)
    }

    /// Classic C7/C8 already use native authentication class C. Preserve that
    /// comparison for OEM/On; Off refuses only class C through its proven exit.
    pub fn auth_cell_refusal_detour(
        &self,
        image: &[u8],
        flag_base: u32,
    ) -> Result<(usize, Vec<u8>)> {
        use mediatek_optical::image::analysis::{AuthCell, AuthCellVariant};
        let contract = AuthCell::detect(image)?;
        ensure!(
            contract.variant() == AuthCellVariant::R0StateR1Alternate,
            "unsupported refusal contract"
        );
        let mut a = Asm::new();
        let original = a.label();
        let deny = a.label();
        a.push(0x0008);
        a.ldr_lit(3, flag_base + abi::Feature::Unrestricted as u32);
        a.ldrb_imm(3, 3, 0);
        a.cmp_imm(3, abi::STATE_OFF);
        a.pop(0x0008);
        a.bne(original);
        a.cmp_imm(0, 0xC);
        a.bne(original);
        a.push(0x0108);
        a.ldr_lit(3, contract.refusal() as u32 | 1);
        a.str_sp(3, 4);
        a.pop(0x0108);
        a.bind(original);
        a.cmp_imm(0, 0xC);
        a.bne(deny);
        a.bx(14);
        a.bind(deny);
        a.push(0x0108);
        a.ldr_lit(3, contract.deny() as u32 | 1);
        a.str_sp(3, 4);
        a.pop(0x0108);
        Ok((contract.site(), a.finish()?))
    }

    /// Select the state-band implementation from the shared OEM VID-success
    /// contract. Its role and continuations are established before any emission.
    pub fn auth_cell_widen_detour(&self, image: &[u8], flag_base: u32) -> Result<(usize, Vec<u8>)> {
        use mediatek_optical::image::analysis::{AuthCell, AuthCellVariant};
        let contract = AuthCell::detect(image).map_err(|e| anyhow!("auth-cell layout: {e}"))?;
        let bytes = match contract.variant() {
            AuthCellVariant::R0StateR4 => {
                self.build_authcell_widen_stub(flag_base, contract.deny() as u32)?
            }
            AuthCellVariant::R1StateR1 | AuthCellVariant::R1StateR4 => {
                self.build_authcell_widen_value_stub(flag_base, contract.deny() as u32, 1)?
            }
            AuthCellVariant::R0StateR0 | AuthCellVariant::R0StateR5 => {
                self.build_authcell_widen_value_stub(flag_base, contract.deny() as u32, 0)?
            }
            AuthCellVariant::R0StateR1Alternate => {
                self.auth_cell_refusal_detour(image, flag_base)?.1
            }
        };
        Ok((contract.site(), bytes))
    }

    // (Retired 0.8.9: `find_aacs45_arm` — only used to wire the deleted
    // `Feature::Bus` bus-encryption trampoline.)

    /// Resolve the shared OEM media-control grammar. Ambiguous evidence fails;
    /// a model name or silicon label never grants a code-layout match.
    pub fn find_bd_gate(&self, image: &[u8]) -> Result<u32> {
        mediatek_optical::image::analysis::MediaGate::inspect(image)
            .map(|gate| gate.anchor() as u32)
            .map_err(|e| anyhow!("AACS media gate: {e}"))
    }

    /// The flash-resident HRL lookup routine, located by `HRL_LOOKUP_SIG` and
    /// proven unique image-wide. Returns its entry VA. The routine relocates
    /// between versions (`0x133666` … `0x139796` on the mainline, ~`0x146xxx` on the
    /// ~+0x2b000-shifted MT1939-modern block, ~`0x16axxx` on the far-shifted
    /// BC-12/CH12/UH12 DVD-combo drives), and the 12-halfword body signature is
    /// unique full-image (maxn==1 measured) on every AACS image and absent on the
    /// DVD/CD-only parts — so a bounded window only served to exclude the shifts.
    pub fn find_hrl_lookup(&self, image: &[u8]) -> Result<u32> {
        // Full-image scan: the 12-halfword body signature is unique image-wide
        // (maxn==1 measured). The old 0x130000..0x140000 window excluded the
        // ~+0x2b000-relocated MT1939-modern block (HRL routine lifted to ~0x146xxx).
        Ok(find_unique(image, HRL_LOOKUP_SIG, 0, image.len(), "HRL lookup routine")? as u32)
    }

    /// The cert-path HRL check sites and their shared revoke target.
    ///
    /// Grounded, not hardcoded: find the HRL lookup ([`Self::find_hrl_lookup`]),
    /// then every `bl <hrl_lookup>` in the cert region; each is followed within a
    /// few instructions by `cmp r0,#0; bne <T>`. ALL such sites must share the SAME
    /// revoke target `T` (any disagreement → refuse), and `T` must carry the OEM
    /// revoke HEAD `ldrb r0,[r4,#2]; cmp r0,#0; bne …` — so a mis-anchored match
    /// refuses rather than patches. Returns `(cmp_offsets, revoke_target)`;
    /// `cmp_offsets[k]` is where the 4-byte `cmp r0,#0; bne T` the detour replaces
    /// begins.
    ///
    /// The site COUNT is version-dependent, not fixed: newer desktop/UHD firmware
    /// (BU40N/BU50N/WH16NS60/BP60NB10 …) checks the HRL at 3 cert sub-paths, while
    /// the NS40/NS50/NU50 notebook lineage checks it at 1 consolidated site. Both
    /// are legitimate — the count is not asserted; ≥1 shared-target site is
    /// required. The 6F/00 sense-setup is NOT keyed on: its `movs r2,#0`/`movs
    /// r1,#0x6f` pair is inline on the older layout but split across basic blocks
    /// (reached via `b`) on the branch-away layout, so requiring it inline was the
    /// original BU40N over-fit that pinned availability to 1/118. Anchoring on the
    /// unique HRL-lookup BODY plus the invariant revoke HEAD lifts availability to
    /// parity with the peer AACS gates (91/118) with no wrong matches.
    pub fn find_hrl_skip_sites(&self, image: &[u8]) -> Result<(Vec<usize>, u32)> {
        let hrl = self.find_hrl_lookup(image)?;
        // Full-image scan: each candidate site is filtered by `decode_bl_target ==
        // hrl` (the already-resolved lookup) plus the trailing `cmp r0,#0; bne`, and
        // every site must agree on one revoke target carrying the OEM revoke HEAD —
        // so the match is strict regardless of window. The old 0x130000..0x13c000
        // window excluded the far-relocated MT1939-modern block (HRL cert path at
        // ~0x16axxx on the BC-12/CH12/UH12 DVD-combo drives).
        let (lo, hi) = (0usize, image.len());
        let hw = |o: usize| u16::from_le_bytes([image[o], image[o + 1]]);
        let bne_target = |o: usize| -> u32 {
            let b = hw(o) & 0xFF;
            let disp = if b >= 0x80 {
                b as i32 - 0x100
            } else {
                b as i32
            };
            (o as i32 + 4 + disp * 2) as u32
        };
        let mut sites = Vec::new();
        let mut target: Option<u32> = None;
        let mut o = lo;
        while o + 4 <= hi {
            if thumb::decode_bl(image, o) == Some(hrl) {
                // nearest following `cmp r0,#0; bne T` within 12 halfwords.
                let mut p = o + 4;
                let end = (o + 4 + 24).min(hi.saturating_sub(4));
                while p + 4 <= end {
                    if hw(p) == 0x2800 && (hw(p + 2) & 0xFF00) == 0xD100 {
                        let t = bne_target(p + 2);
                        match target {
                            None => target = Some(t),
                            Some(prev) if prev == t => {}
                            Some(_) => bail!("HRL check sites disagree on the revoke target"),
                        }
                        sites.push(p);
                        break;
                    }
                    p += 2;
                }
            }
            o += 2;
        }
        let target =
            target.ok_or_else(|| anyhow!("no HRL cert-path `cmp r0,#0; bne` sites found"))?;
        // Verify the shared revoke target's version-invariant OEM HEAD:
        // `ldrb r0,[r4,#2]; cmp r0,#0; bne`.
        let t = target as usize;
        let revoke_head = t + 6 <= image.len()
            && hw(t) == 0x78A0
            && hw(t + 2) == 0x2800
            && (hw(t + 4) & 0xFF00) == 0xD100;
        if !revoke_head {
            bail!("HRL revoke target 0x{target:x} lacks the OEM revoke HEAD shape — refusing");
        }
        Ok((sites, target))
    }

    /// The HRL-skip trampoline (`flag[Feature::Hrl]==STATE_OFF`). Shared by the three
    /// cert-path sites: each `bl` replaces `cmp r0,#0; bne <revoke>` (4 bytes) at a
    /// site, so on entry `lr` = that site's CLEAN fall-through and `r0` = the HRL
    /// lookup result (`1`=revoked, `2`=blank, `0`=clean). When `flag[Feature::Hrl]`
    /// is `STATE_OFF` the stub takes the clean path regardless of the result (revoked
    /// certs accepted, non-destructive); otherwise it replicates OEM exactly (clean
    /// iff `r0==0`, else jump to the `revoke` 6F/00 path). `r3` is saved/restored;
    /// `r0`/`lr` untouched on the clean path, so behaviour is OEM-identical when the
    /// flag is On or OEM (`0x01` / `0xFF`) — the stealth invariant. The
    /// crypto verify (`bl <ca7e4>`) and the success writer are on other paths and
    /// are left intact.
    pub(crate) fn build_hrl_skip_stub(&self, flag_base: u32, revoke: u32) -> Result<Vec<u8>> {
        let mut a = Asm::new();
        let clean = a.label();
        a.push(0x0008); // push {r3}   (r3 scratch; no inner call → SP alignment moot)
        a.ldr_lit(3, flag_base + abi::Feature::Hrl as u32); // r3 = &flag[Hrl]
        a.ldrb_imm(3, 3, 0); // r3 = HRL flag byte
        a.cmp_imm(3, abi::STATE_OFF); // 0x00 = skip HRL -> force clean; ON/OEM = enforce (OEM)
        a.beq(clean);
        a.cmp_imm(0, 0); // OEM: clean iff HRL result == 0
        a.beq(clean);
        // revoked / blank: replicate the OEM `bne <revoke>` (jump to the 6F/00 path).
        a.pop(0x0008); // restore r3 before the native continuation
                       // Preserve R3 on rejection too. Using it as the BX target after POP
                       // would replace the native value with the continuation address.
        a.push(0x0108); // r3, lr; replace only the stacked return
        a.ldr_lit(3, revoke | 1);
        a.str_sp(3, 4);
        a.pop(0x0108); // r3, pc; native R3, SP and comparison flags survive
        a.bind(clean);
        a.pop(0x0008); // restore r3
        a.bx(14); // bx lr -> the site's clean fall-through
        a.finish().map_err(anyhow::Error::from)
    }

    /// Resolve the HRL-skip detour: returns `(cmp_offsets, revoke, stub_bytes)`. A
    /// `bl` to the stub is written at each of the three `cmp_offsets`. Errors (→ HRL
    /// skip left unwired) on an image whose HRL cert path is not the known shape.
    pub(crate) fn hrl_skip_detour(
        &self,
        image: &[u8],
        flag_base: u32,
    ) -> Result<(Vec<usize>, u32, Vec<u8>)> {
        let (sites, revoke) = self.find_hrl_skip_sites(image)?;
        let bytes = self.build_hrl_skip_stub(flag_base, revoke)?;
        Ok((sites, revoke, bytes))
    }

    /// Resolve the AKE detour site + stub for whichever gate variant this image
    /// carries. Returns `(detour_site, stub_bytes, anchor, install_shape)`.
    /// Every supported shape uses Thumb-1 BL: NB replaces a native call, while
    /// the original writer requires proof of a saved caller frame and a native
    /// call join which replaces LR before it is observed. Unknown joins refuse.
    pub(crate) fn ake_detour(
        &self,
        image: &[u8],
        flag_base: u32,
    ) -> Result<(usize, Vec<u8>, u32, BranchKind)> {
        // The de-bus latch clear every AKE stub variant below bakes in. Resolved
        // once, here, so a failure to find it refuses the whole AKE lever rather
        // than shipping a stub that forces auth without clearing the latch —
        // which is precisely the 0.8.14/0.9.0 defect (drive wraps with a key the
        // host never negotiated, no key can decrypt, every rip fails).
        let (anchor, variant) = find_unique_variant(
            image,
            &[AKE_GATE_SIG, AKE_GATE_SIG_NB, AKE_GATE_SIG_NB_V5],
            0,
            image.len(),
            "AACS AKE accept gate",
        )?;
        let reset = self.find_aacs_session_reset(image)?;
        // Original (BU40N / BP60NB10 / desktop): detour the reject writer
        // `movs r1,#1; b <back>` (4 bytes at anchor+12).
        //
        // Historical B.W preserved LR unnecessarily on the reviewed source:
        // both arms branch to a native BL, not directly to the leaf setter.
        // Do not generalize that observation to an unqualified firmware.
        if variant == 0 {
            let ake_gate = anchor as u32;
            let reset_site = ake_gate as usize + 12;
            let movs_hw = u16::from_le_bytes([image[reset_site], image[reset_site + 1]]);
            if movs_hw != 0x2101 {
                bail!(
                    "AKE reset writer `movs r1,#1` not at 0x{reset_site:x} (got 0x{movs_hw:04x})"
                );
            }
            let b_at = reset_site + 2;
            let b_hw = u16::from_le_bytes([image[b_at], image[b_at + 1]]);
            if (b_hw & 0xF800) != 0xE000 {
                bail!("AKE reset writer `b` not at 0x{b_at:x} (got 0x{b_hw:04x})");
            }
            let mut disp = (b_hw & 0x7FF) as i32;
            if disp >= 0x400 {
                disp -= 0x800;
            }
            let ake_back = (b_at as i32 + 4 + disp * 2) as u32;
            let success = thumb::isa::decode_at(image, anchor + 6)
                .and_then(|instruction| instruction.branch_target())
                .ok_or_else(|| anyhow!("AKE success writer has no native B16 join"))?;
            ensure!(
                success == ake_back,
                "AKE writers do not share their native call join"
            );
            let setter = thumb::decode_bl(image, ake_back as usize)
                .ok_or_else(|| anyhow!("AKE writer join is not a native BL"))?;
            ensure!(
                setter == self.find_vid_gate_setter(image)?,
                "AKE join does not call the producer-derived AGID setter"
            );
            // Complete operand grammar: the setter overwrites incoming flags
            // and r2, consumes only the preserved AGID in r0 and state in r1,
            // then returns through the LR defined by the native call join.
            let common = [
                (0x2802, 0xffff),
                (0xd20c, 0xffff),
                (0x4a00, 0xff00),
                (0x1880, 0xffff),
                (0x4a00, 0xff00),
                (0x0400, 0xffff),
                (0x6812, 0xffff),
                (0x0c00, 0xffff),
                (0x1810, 0xffff),
                (0x4a00, 0xff00),
                (0x0200, 0xffff),
                (0x6812, 0xffff),
                (0x0a00, 0xffff),
                (0x1880, 0xffff),
                (0x7001, 0xffff),
                (0x4770, 0xffff),
            ];
            let short = [
                (0x2802, 0xffff),
                (0xd20a, 0xffff),
                (0x4a00, 0xff00),
                (0x1880, 0xffff),
                (0x4a00, 0xff00),
                (0x6812, 0xffff),
                (0x1810, 0xffff),
                (0x4a00, 0xff00),
                (0x0200, 0xffff),
                (0x6812, 0xffff),
                (0x0a00, 0xffff),
                (0x1880, 0xffff),
                (0x7001, 0xffff),
                (0x4770, 0xffff),
            ];
            let setter = setter as usize;
            let literals = if image.get(setter..setter + common.len() * 2).is_some()
                && matches_sig(image, &common, setter)
            {
                [4, 8, 18]
            } else if image.get(setter..setter + short.len() * 2).is_some()
                && matches_sig(image, &short, setter)
            {
                [4, 8, 14]
            } else {
                bail!("AKE native AGID setter operands are unqualified");
            };
            for offset in literals {
                ensure!(
                    pc_literal(image, setter + offset).is_some(),
                    "AKE setter literal is out of image"
                );
            }
            mediatek_optical::image::analysis::SavedLink::detect(image, reset_site)
                .context("AKE writer caller does not prove saved LR and balanced exits")?;
            let bytes = self.build_ake_stub(flag_base, ake_back, reset)?;
            return Ok((reset_site, bytes, ake_gate, BranchKind::Bl));
        }
        // NB-class: detour the shared `bl set_agid_state` at anchor+12. The
        // OEM already installs a `bl` here — installing our own `bl` is a
        // like-for-like replacement, `lr = bl_site+4` is exactly what the OEM
        // `bl set_agid_state` would have set, so `set_agid_state`'s `bx lr`
        // returns to the correct in-function continuation.
        if variant == 1 {
            let nb_gate = anchor as u32;
            let reject = nb_gate as usize + 10;
            let movs_hw = u16::from_le_bytes([image[reject], image[reject + 1]]);
            if movs_hw != 0x2101 {
                bail!(
                    "NB AKE reject writer `movs r1,#1` not at 0x{reject:x} (got 0x{movs_hw:04x})"
                );
            }
            let bl_site = nb_gate as usize + 12;
            let back = thumb::decode_bl(image, bl_site)
                .ok_or_else(|| anyhow!("NB AKE: no `bl set_agid_state` at 0x{bl_site:x}"))?;
            let bytes = self.build_ake_stub_nb(flag_base, back, reset)?;
            return Ok((bl_site, bytes, nb_gate, BranchKind::Bl));
        }
        // NB-class `1.V5`: reject arm re-reads the AGID byte, so the reject writer
        // is at anchor+12 and the shared `bl set_agid_state` at anchor+14. Both
        // arms converge on that shared `bl`, so the NB stub (which PRESERVES r1
        // when the flag is off) applies verbatim. Same install shape as NB.
        let v5_gate = anchor as u32;
        let reject = v5_gate as usize + 12;
        let movs_hw = u16::from_le_bytes([image[reject], image[reject + 1]]);
        if movs_hw != 0x2101 {
            bail!(
                "NB 1.V5 AKE reject writer `movs r1,#1` not at 0x{reject:x} (got 0x{movs_hw:04x})"
            );
        }
        let bl_site = v5_gate as usize + 14;
        let back = thumb::decode_bl(image, bl_site)
            .ok_or_else(|| anyhow!("NB 1.V5 AKE: no `bl set_agid_state` at 0x{bl_site:x}"))?;
        let bytes = self.build_ake_stub_nb(flag_base, back, reset)?;
        Ok((bl_site, bytes, v5_gate, BranchKind::Bl))
    }

    /// The Raw Read (0x04) flag-gated producer Gate-A trampoline. Entered by a `bl`
    /// that replaces the VID producer's OWN gate `cmp r0,#6; bne <deny>` (4 bytes at
    /// `VidGateVariant::Direct`'s `match+18`). On entry `r0 = the per-AGID auth byte` (from the
    /// preceding `ldrb r0,[r0]`), preserved. This gate is reached by a bare
    /// `READ DISC STRUCTURE` (`0xAD` fmt `0x80`) — NO AKE.
    ///
    /// This is the null-AKE bare-read mode (`flag[Ake]==STATE_OFF`): "the cert is
    /// valid" — the drive is told the host auth already succeeded, so an unlocker can
    /// just issue a bare `0xAD` fmt `0x80` and get the VID with NO cert and NO AKE.
    /// When `flag[Ake]==STATE_OFF` the stub jumps to `authed` (the fall-through that
    /// stages+emits VID) regardless of the auth byte; otherwise (`passthrough`/`off`)
    /// it replicates the OEM `cmp #6` (authed on `==6`, which is what the real-AKE
    /// accept path leaves in place). Native registers are restored before either
    /// continuation; R1/R2 remain the writer's source/count arguments. The drive
    /// runs its own producer in its own `0xAD`
    /// context — no inline call, so a missing-buffer failure is a recoverable CHECK
    /// CONDITION, never a wedge.
    pub(crate) fn build_gatea_stub(
        &self,
        flag_base: u32,
        agid_struct: u32,
        authed: u32,
        deny: u32,
        reset: u32,
    ) -> Result<Vec<u8>> {
        let mut a = Asm::new();
        let rearm = a.label();
        let authed_direct = a.label();
        // The native continuation passes R1/R2 to the response writer. They
        // are live arguments, not scratch, even though the comparison uses R0.
        // Save all low arguments and a target scratch, keeping an aligned call.
        a.push(0x011f); // r0-r4, lr: 24 bytes
        let tail = |a: &mut Asm, target: u32| {
            a.mov_reg(4, 13);
            a.ldr_imm(4, 4, 20); // original detour LR
            a.mov_reg(14, 4);
            a.ldr_lit(4, target | 1);
            a.str_sp(4, 20); // replace only the stacked return target
            a.pop(0x011f); // r0-r4, pc: restore the native arguments and SP
        };
        a.ldr_lit(2, flag_base + abi::Feature::Encryption as u32);
        a.ldrb_imm(2, 2, 0);
        a.cmp_imm(2, abi::STATE_OFF);
        a.beq(rearm);
        a.cmp_imm(0, 6);
        a.beq(authed_direct);
        tail(&mut a, deny);
        a.bind(rearm);
        // Preserve R12 too: the reset may clobber every caller-saved register.
        // Two extra words retain eight-byte alignment at its native entry.
        a.mov_reg(4, 12);
        a.push(0x0030); // r4 (saved r12), r5 (alignment)
        a.ldr_lit(2, reset | 1);
        a.blx(2);
        a.pop(0x0030);
        a.mov_reg(12, 4);
        a.ldr_lit(2, agid_struct);
        a.ldrb_imm(3, 2, 0xa);
        a.movs_imm(1, 0xc0);
        a.bics(3, 1);
        a.strb_imm(3, 2, 0xa);
        // Keep the native displaced comparison flags on the forced path too.
        a.mov_reg(4, 13);
        a.ldr_imm(0, 4, 0);
        a.cmp_imm(0, 6);
        a.bind(authed_direct);
        tail(&mut a, authed);
        a.finish().map_err(anyhow::Error::from)
    }

    /// The Raw Read (0x04) deny-path AACS-reset trampoline (Option C). Entered by a
    /// `bl` that replaces the VID producer deny block's sense-setup `movs r2,#2;
    /// movs r1,#0x6f` (the first 4 bytes at the deny target + 0x10). It calls the
    /// OEM `aacs_session_reset` to idle the AACS engine — so a failed-cert deny
    /// never leaves the engine non-idle (which would hang the next bare `0xAD` VID
    /// read) — then REPLAYS the two overwritten sense halfwords and returns to the
    /// OEM continuation (`movs r0,#5; b set_sense`). `aacs_session_reset` clobbers
    /// r0-r3 and preserves r4-r7; the deny continuation re-establishes r0 (=5)
    /// itself, and r2/r1 are replayed here, so nothing needs saving except lr.
    pub(crate) fn build_deny_reset_stub(&self, reset: u32) -> Result<Vec<u8>> {
        let mut a = Asm::new();
        a.push(0x0110); // push {r4, lr}  (r4 only to keep SP 8-byte aligned)
        a.ldr_lit(2, reset | 1); // r2 = &aacs_session_reset (thumb)
        a.blx(2); // aacs_session_reset()  (idle the engine)
        a.movs_imm(2, 2); // replay: movs r2,#2   (sense ASCQ)
        a.movs_imm(1, 0x6f); // replay: movs r1,#0x6f (sense ASC)
        a.pop(0x0110); // pop {r4, pc} -> OEM continuation (movs r0,#5; b set_sense)
        a.finish().map_err(anyhow::Error::from)
    }

    /// The **always-on boot-init** trampoline — the mechanism that makes the
    /// tri-state safe. Entered by a `bl` that replaces the cold/warm-boot
    /// convergence `bl <orig_init>` (the 4 bytes at
    /// [`boot_init_convergence`]'s `conv`, `0x13d428` on BU40N), i.e. the first
    /// instruction both boot paths reach AFTER the cold-boot bss/SRAM clear. Patching
    /// here (not the pre-clear reload at `anchor+4`) is what stops the clear from
    /// wiping the `0xFF` flag table this stub writes.
    ///
    /// Every boot writes the image’s selected settings after SRAM initialization.
    /// Saved configurations do not participate; runtime SET remains available,
    /// and explicit RESET_TO_FLASH can reload a saved session configuration.
    ///
    /// # Register / frame contract
    /// The stub replaces `bl <orig_init>` and preserves all four native arguments.
    /// It saves R0-R4 and LR, initializes the flags, puts the native target in
    /// call-clobbered R12, then restores R0-R3 and the caller's R4 before BLX.
    /// The remaining two stack words keep the native call eight-byte aligned.
    /// After that call, `pop {r4, pc}` restores the frame without changing the
    /// native return value or NZCV. The boot-status reload at the old anchor
    /// remains untouched.
    #[cfg(test)]
    pub(crate) fn build_boot_init(
        &self,
        flag_base: u32,
        orig_init: u32,
        _save_home: u32,
    ) -> Result<Vec<u8>> {
        self.build_boot_init_with_defaults(flag_base, orig_init, &BootSettings::standard())
    }

    pub(crate) fn build_boot_init_with_defaults(
        &self,
        flag_base: u32,
        orig_init: u32,
        defaults: &BootSettings,
    ) -> Result<Vec<u8>> {
        self.build_boot_init_with_private_identity(flag_base, orig_init, defaults, None)
    }

    /// Build the same native-call-preserving boot wrapper with an optional
    /// conversion-owned identity cache. Native images retain the old bytes.
    pub(crate) fn build_boot_init_with_private_identity(
        &self,
        flag_base: u32,
        orig_init: u32,
        defaults: &BootSettings,
        identity: Option<u32>,
    ) -> Result<Vec<u8>> {
        if let Some(identity) = identity {
            ensure!(
                flag_base.checked_add(UHD_IDENTITY_OFF) == Some(identity),
                "private UHD identity overlaps flags or scratch"
            );
        }
        let mut a = Asm::new();
        // Preserve all four native arguments and the caller's r4. Keep two
        // words on the stack across the call so its entry remains 8-byte aligned.
        a.push(0x011F); // push {r0-r4, lr}       6 words → sp 8-aligned
                        // Initialize every flag, including the otherwise-unused saved marker.
        a.ldr_lit(0, flag_base); // r0 = &flag table (SRAM)
        for (off, &val) in defaults.flags().iter().enumerate() {
            a.movs_imm(1, val); // selected boot value
            a.strb_imm(1, 0, off as u16); // flag[off] = default
        }
        if identity.is_some() {
            a.movs_imm(1, 0);
            a.strb_imm(1, 0, UHD_IDENTITY_OFF as u16);
        }
        // Boot choices are authoritative. Saved runtime settings are loaded only
        // by an explicit RESET_TO_FLASH, never implicitly during startup.
        // R12 is call-clobbered, unlike the four restored argument registers.
        // Load its target through the saved r4, then restore r4 before entry.
        a.ldr_lit(4, orig_init | 1);
        a.mov_reg(12, 4);
        a.pop(0x000F); // r0-r3 are exactly the native call's arguments
        a.mov_reg(4, 13);
        a.ldr_imm(4, 4, 0); // saved caller r4, without changing flags
        a.blx(12); // call at sp=S-8; retain the native result and return flags
        a.pop(0x0110); // pop {r4, pc}   restore r4 pad + return to conv+4
        a.finish().map_err(anyhow::Error::from)
    }

    /// Resolve the boot-init detour `(conv, orig_init)` pair WITHOUT writing
    /// anything — the single source of truth for callers that need the detour
    /// site (the `Verb::Reboot` boot-function-entry literal is `conv - 0x10`)
    /// and for `emit_boot_init`, which consumes the full pair. Threading the
    /// pre-resolved pair through eliminates the second `find_boot_init` scan
    /// that used to run inside `emit_boot_init`.
    ///
    /// Fail-closed rules:
    /// modern → follow the anchor's `bmi` to the cold/warm convergence `bl`;
    /// classic → the helper's unique caller `bl`.
    /// A [`None`] boot-init prologue bails: tri-state OFF is unsafe without the
    /// always-on 0xFF fill.
    pub(crate) fn resolve_boot_init_pair(&self, image: &[u8]) -> Result<(usize, u32)> {
        match self.find_boot_init(image)? {
            Some(BootInitSite::Modern(s)) => {
                boot_init_convergence(image, s as usize).ok_or_else(|| {
                    anyhow!(
                        "boot-init convergence `bl <orig_init>` not resolvable from anchor at \
                         0x{s:x} (the bmi target is not a 32-bit Thumb bl) — refusing to ship an \
                         unverified boot hook rather than mis-patch"
                    )
                })
            }
            Some(BootInitSite::ClassicUnconfirmed(s)) => {
                classic_boot_init_caller(image, s as usize).ok_or_else(|| {
                    anyhow!(
                        "classic boot-init: the helper at anchor 0x{:x} does not have exactly one \
                         `bl` caller image-wide (want 1) — refusing to ship an ambiguous detour",
                        s.saturating_sub(4)
                    )
                })
            }
            None => bail!(
                "tri-state OFF is unsafe without a boot-init site: no known boot-init prologue \
                 found on this image (unknown shape). Refusing to ship — a flag table that boots \
                 all-0x00 would disable every feature at power-on."
            ),
        }
    }

    /// Install the always-on boot-init hook: find the anchor, follow its `bmi` to the
    /// cold/warm-boot convergence `bl <orig_init>`, inject [`Self::build_boot_init_with_defaults`]
    /// into covered free space, and repoint that `bl` at the stub. Returns
    /// `(conv, stub_va)` — the convergence detour site (the reported `boot_init_site`)
    /// and the stub address.
    ///
    /// A missing boot site refuses emission. Modern sites follow the validated
    /// cold/warm convergence call; classic sites use the uniquely resolved helper
    /// caller. The resolver qualifies the pair before this emitter consumes it.
    pub(crate) fn emit_boot_init(
        &self,
        _image: &[u8],
        out: &mut [u8],
        flag_base: u32,
        boot_init_pair: (usize, u32),
        defaults: &BootSettings,
    ) -> Result<(u32, u32)> {
        self.emit_boot_init_with_private_identity(out, flag_base, boot_init_pair, defaults, None)
    }

    /// Replace the boot hook after installing a conversion that owns a private
    /// identity cache. Callers must obtain the address from that installed plan.
    pub(crate) fn emit_boot_init_with_private_identity(
        &self,
        out: &mut [u8],
        flag_base: u32,
        boot_init_pair: (usize, u32),
        defaults: &BootSettings,
        identity: Option<u32>,
    ) -> Result<(u32, u32)> {
        // Detour pair is pre-resolved by [`Self::resolve_boot_init_pair`]:
        // * Modern — the cold/warm-boot convergence `bl <orig_init>` (first
        //   instruction after the cold path rejoins, which runs AFTER the SRAM
        //   clear and on warm boot). Detouring here — not the pre-clear reload
        //   at `anchor+4` — keeps the stub's 0xFF fill alive.
        // * Classic — the helper's unique caller `bl` (only when blessed).
        let (conv, orig_init) = boot_init_pair;
        let bytes = match identity {
            Some(identity) => self.build_boot_init_with_private_identity(
                flag_base,
                orig_init,
                defaults,
                Some(identity),
            )?,
            None => self.build_boot_init_with_defaults(flag_base, orig_init, defaults)?,
        };
        let stub_va = self.free_space(out, bytes.len())?;
        thumb::write(out, stub_va as usize, &bytes);
        // Decode-back guarded like every other install site. This one was the
        // lone exception, which is backwards: it is the always-on power-on
        // hook, so a mis-encoded branch here misfires on every boot rather
        // than only when a feature is exercised.
        crate::install_guard::install_branch(out, conv, BranchKind::Bl, stub_va, "boot-init")?;
        Ok((conv as u32, stub_va))
    }

    /// Downgrade-enable lever. Family-agnostic: writes `0xDE` at the identity-page
    /// slot when a well-formed MTEK descriptor is present; idempotent.
    pub(crate) fn lever_de(&self, image: &[u8], out: &mut [u8], chip: &ChipInfo) -> LeverReport {
        if !chip.descriptor_present {
            return LeverReport::not_applicable(
                LeverId::DowngradeEnable,
                "no MTEK identity page in this image",
            );
        }
        match self.find_de_byte(image) {
            Ok(de_off) => {
                let off = de_off as usize;
                if out[off] == 0xDE {
                    LeverReport::already(LeverId::DowngradeEnable, vec![("de_off", de_off)])
                } else {
                    out[off] = 0xDE;
                    LeverReport::applied(LeverId::DowngradeEnable, vec![("de_off", de_off)])
                }
            }
            Err(e) => LeverReport::missed(LeverId::DowngradeEnable, format!("{e:#}")),
        }
    }

    /// Build an all-`AlreadyPresent` report for an image that is already
    /// freemkv-modified (idempotent re-entry). The image is returned
    /// **byte-identical** (it is already a valid, signed freemkv image), so
    /// `modify(modify(x)) == modify(x)`. Levers are marked `AlreadyPresent`
    /// (capability-gated ones `NotApplicable`) to mirror what a fresh modify
    /// produced.
    pub(crate) fn already_present_report(
        &self,
        image: &[u8],
        chip: &ChipInfo,
        cap: &Capability,
        engine: &'static str,
    ) -> ModifyReport {
        let mut levers = Vec::new();
        levers.push(LeverReport::already(LeverId::Identity, vec![]));
        levers.push(if cap.media_class >= MediaClass::Bd || cap.bd_aacs {
            LeverReport::already(LeverId::Speed, vec![])
        } else {
            LeverReport::not_applicable(LeverId::Speed, "no BD read-ramp on this model")
        });
        levers.push(if cap.region_lockable {
            LeverReport::already(LeverId::RegionFree, vec![])
        } else {
            LeverReport::not_applicable(LeverId::RegionFree, "no region lever on this model")
        });
        levers.push(if cap.bd_aacs {
            LeverReport::already(LeverId::RawRead, vec![])
        } else {
            LeverReport::not_applicable(LeverId::RawRead, "no AACS/BD on this model")
        });
        levers.push(if !chip.descriptor_present {
            LeverReport::not_applicable(
                LeverId::DowngradeEnable,
                "no MTEK identity page in this image",
            )
        } else {
            match self.find_de_byte(image) {
                Ok(de_off) => {
                    LeverReport::already(LeverId::DowngradeEnable, vec![("de_off", de_off)])
                }
                Err(e) => LeverReport::missed(LeverId::DowngradeEnable, format!("{e:#}")),
            }
        });
        ModifyReport {
            engine,
            family: chip.family.label().to_string(),
            vendor: chip.vendor.clone(),
            model: chip.model.clone(),
            rev: chip.rev.clone(),
            vendor_specific: chip.vendor_specific.clone(),
            media: cap.media_class.label().to_string(),
            levers,
            image: image.to_vec(),
            validation: Validation::StaticOnly,
        }
    }
}

/// True if `image` is already freemkv-modified. The Identity handler that every
/// successful modify injects carries the [`abi::RESP_MAGIC`] (`b"freemkv"`)
/// identity string, which never appears in a stock OEM image — so its presence
/// is a reliable, byte-stable "already patched by us" marker (used for
/// idempotent re-entry; see [`Mt1959Engine::build_modify`]).
pub fn is_freemkv_patched(image: &[u8]) -> bool {
    image
        .windows(abi::RESP_MAGIC.len())
        .any(|w| w == abi::RESP_MAGIC)
}

/// MT1939-classic analogue of [`boot_init_convergence`]. The classic reload site is a
/// called **leaf helper**: its internal `bmi` targets a `bx lr` (function return), so —
/// unlike modern — there is NO convergence `bl <orig_init>` inside it to detour. Rule
/// (RE-proven unique on all 17 classic images): the helper's function entry is
/// `anchor = site - 4`; detour the helper's **unique caller `bl`** instead. The stub
/// (`build_boot_init`) does its `0xFF`-fill + flash-load, then tail-calls the helper —
/// structurally identical to the modern detour, just anchored one call-frame up.
///
/// Returns `(caller_bl_site, helper_entry)`. Requires **exactly one** 32-bit Thumb `bl`
/// image-wide whose target is the helper (fail-closed / `None` on 0 or >1). Validated:
/// exactly one caller on every classic image, always inside a `push {…,lr}` function.
pub(crate) fn classic_boot_init_caller(image: &[u8], site: usize) -> Option<(usize, u32)> {
    let helper = site.checked_sub(4)? as u32; // helper leaf entry (anchor, `ldr r0,[pc]`)
    let end = image.len().saturating_sub(4);
    let mut caller: Option<usize> = None;
    let mut off = 0usize;
    while off + 4 <= end {
        if let Some(t) = thumb::decode_bl(image, off) {
            if t & !1 == helper & !1 {
                if caller.is_some() {
                    return None; // >1 caller — ambiguous, fail closed
                }
                caller = Some(off);
            }
        }
        off += 2;
    }
    caller.map(|c| (c, helper))
}

#[cfg(test)]
#[path = "mt1959_kat_tests.rs"]
mod kat_tests;
