//! MediaTek MT1939 engine.
//!
//! Classic firmware carries an MT1939 boot banner and uses its own command,
//! boot, speed and media contracts. The other MT1939 code generation delegates
//! to the MT1959 machinery while retaining the MT1939 family label.
//!
//! Both paths install only source-qualified hooks and derive advertised settings
//! from installed facts. If the base cannot be built, `modify` can fall back to
//! downgrade-enable alone. Complete media conversion requires its whole group;
//! bounded software validation does not establish physical reading behavior.
//! Both generations use the shared MediaTek CMAC implementation.

use crate::boot::BootSettings;
use anyhow::{anyhow, bail, Result};

use freemkv_flash::cmac;

use super::lever::{LeverId, LeverReport};
use super::mt1959::Mt1959Engine;
use super::{CreateReport, Engine, ModifyReport};
use crate::family;

/// Downgrade-enable byte offset within the MTEK identity page (`0x1EC056`).
const DE_OFF_IN_DESCRIPTOR: usize = 0x56;

/// Classic-generation VID producer raw-read gate (`cmp auth_state,#6; bne <deny>`).
///
/// Reversed from a classic image (`STOCK_LG_BH16NS40_1.01 @ 0x17f414`), masking the
/// pc-relative `imm8`s and the `bne` displacement; the gate `cmp`/`bne` sit at
/// `match+28`/`match+30`. **Proven UNIQUE on every classic image** (engine-scope
/// report §3a). Captured here for the classic Identity-base wiring block; not yet
/// used to emit (the classic detour needs the classic handler base first).
pub(crate) const VID_GATE_SIG_CLASSIC: &[(u16, u16)] = &[
    (0x7AA8, 0xFFFF), // ldrb r0,[r5,#0xa]
    (0x4900, 0xFF00), // ldr  r1,[pc,#imm8]   (scratch/table base)
    (0x0980, 0xFFFF), // lsrs r0,r0,#6
    (0x1840, 0xFFFF), // adds r0,r0,r1
    (0x4900, 0xFF00), // ldr  r1,[pc,#imm8]   (auth-state ptr A)
    (0x0400, 0xFFFF), // lsls r0,r0,#16
    (0x6809, 0xFFFF), // ldr  r1,[r1]
    (0x0C00, 0xFFFF), // lsrs r0,r0,#16
    (0x1808, 0xFFFF), // adds r0,r1,r0
    (0x4900, 0xFF00), // ldr  r1,[pc,#imm8]   (auth-state ptr B)
    (0x0200, 0xFFFF), // lsls r0,r0,#8
    (0x6809, 0xFFFF), // ldr  r1,[r1]
    (0x0A00, 0xFFFF), // lsrs r0,r0,#8
    (0x1840, 0xFFFF), // adds r0,r0,r1
    (0x7800, 0xFFFF), // ldrb r0,[r0]         (gate load, match+28)
    (0x2806, 0xFFFF), // cmp  r0,#6           (gate,      match+30)
    (0xD100, 0xFF00), // bne  <deny>          (detour anchor)
];

/// Classic-generation AKE accept/reject gate (writes auth-state 6/1 then
/// `bl set_agid_state`). Reversed from `STOCK_LG_BH16NS40_1.01 @ 0x17f2d4`; the
/// reject writer sits at `match+6`. **Proven UNIQUE on every classic image**
/// (engine-scope report §3b).
pub(crate) const AKE_GATE_SIG_CLASSIC: &[(u16, u16)] = &[
    (0x0980, 0xFFFF), // lsrs r0,r0,#6
    (0x2106, 0xFFFF), // movs r1,#6           (accept)
    (0xE000, 0xF800), // b    <skip reject>
    (0x0980, 0xFFFF), // lsrs r0,r0,#6        (detour site, match+6)
    (0x2101, 0xFFFF), // movs r1,#1           (reject)
    (0xF000, 0xF800), // bl   set_agid_state
];

/// Signature of the **classic**-generation flash-resident Host-Revocation-List
/// (HRL) lookup routine — the classic-codegen analogue of [`super::core::HRL_LOOKUP_SIG`].
///
/// The classic AACS cert path checks host revocation with the SAME algorithm as
/// modern (range-lookup over 8-byte HRL records; returns `1`=host revoked,
/// `2`=blank/`0xFFFF` sentinel, `0`=clean), and the routine's first **nine**
/// halfwords are byte-identical to the modern body (`push {r0,r1,r4-r7,lr}; sub
/// sp,#0xc; ldr r0,[sp,#0xc]; movs r4,r1; bl <count-reader>; movs r7,r0; movs
/// r0,r4; bl <helper>; str r0,[sp,#8]`). It then DIVERGES: where modern does `adds
/// r0,r4,#4; lsls r1,r0,#8; ldr r0,[pc,…]` the classic scheduler emits `ldr
/// r1,[pc,…]; adds r0,r4,#4; ldr r2,[r1]; lsls r0,r0,#8; …` — a different
/// flash-address-translate order — so [`super::core::HRL_LOOKUP_SIG`] (which pins
/// modern's 10th halfword `1D20`) matches **0×** on every classic image. This
/// signature carries the shared prologue plus that classic continuation through the
/// BE-16 count read (`ldr r2,[r1]; lsls r0,r0,#8; lsrs r0,r0,#8; adds r0,r0,r2;
/// ldrb r0,[r0]; mov r3,sp; strb r0,[r3,#5]`), masking only the two body `bl`
/// displacements and the `ldr r1,[pc]` `imm8`.
///
/// **Proven UNIQUE (n==1) on every one of the 17 classic images** and **0× on all
/// 98 non-classic corpus images** — reversed from `STOCK_LG_BH16NS40` and verified
/// against the capstone traces of BE14NU40 1.00/1.01, BH14NS40, BH16NS40-NS50,
/// BH40N and WH14/16NS40-NS50. The cert path calls it and tests `cmp r0,#0; bne
/// <revoke>`; the classic revoke target carries the OEM 6F-deny head `ldrb
/// r0,[r5,#2]; cmp r0,#0; bne …; movs r0,#0x6f` (register `r5`, i.e. `0x78A8` — the
/// modern head is `r4`/`0x78A0`). Consumed by [`Mt1959Engine::emit_hrl_classic`].
pub(crate) const HRL_LOOKUP_SIG_CLASSIC: &[(u16, u16)] = &[
    (0xB5F3, 0xFFFF), // push {r0,r1,r4,r5,r6,r7,lr}
    (0xB083, 0xFFFF), // sub  sp,#0xc
    (0x9803, 0xFFFF), // ldr  r0,[sp,#0xc]
    (0x000C, 0xFFFF), // movs r4,r1
    (0xF000, 0xF800), // bl   <count-reader>  hi
    (0xF800, 0xF800), //                      lo
    (0x0007, 0xFFFF), // movs r7,r0
    (0x0020, 0xFFFF), // movs r0,r4
    (0xF000, 0xF800), // bl   <helper>        hi
    (0xF800, 0xF800), //                      lo
    (0x9002, 0xFFFF), // str  r0,[sp,#8]
    (0x4900, 0xF800), // ldr  r1,[pc,#imm8]   (classic divergence: HRL base cell)
    (0x1D20, 0xFFFF), // adds r0,r4,#4
    (0x680A, 0xFFFF), // ldr  r2,[r1]
    (0x0200, 0xFFFF), // lsls r0,r0,#8
    (0x0A00, 0xFFFF), // lsrs r0,r0,#8
    (0x1880, 0xFFFF), // adds r0,r0,r2
    (0x7800, 0xFFFF), // ldrb r0,[r0]
    (0x466B, 0xFFFF), // mov  r3,sp
    (0x7158, 0xFFFF), // strb r0,[r3,#5]
];

/// The MT1939 platform engine.
pub struct Mt1939Engine;

/// True when this MT1939 image is the classic generation (banner `"MT1939 Boot
/// Code"` at `0x3000`). JB8/JBP6/JBC6 parts carry an `"MT1959 Boot …"` banner.
fn is_classic(image: &[u8]) -> bool {
    let banner = freemkv_chipset::BANNER_OFFSET;
    image
        .get(banner..banner + 16)
        .map(|b| b.starts_with(b"MT1939 Boot"))
        .unwrap_or(false)
}

/// File offsets where masked signature `sig` matches in `image[lo..hi]` (local
/// matcher so this module stays decoupled from `core`'s private one).
pub(crate) fn masked_matches(image: &[u8], sig: &[(u16, u16)], lo: usize, hi: usize) -> Vec<usize> {
    let hi = hi.min(image.len());
    let span = sig.len() * 2;
    let mut hits = Vec::new();
    if lo + span > hi {
        return hits;
    }
    let mut off = lo;
    while off + span <= hi {
        let ok = sig.iter().enumerate().all(|(i, &(val, mask))| {
            let hw = u16::from_le_bytes([image[off + i * 2], image[off + i * 2 + 1]]);
            hw & mask == val & mask
        });
        if ok {
            hits.push(off);
        }
        off += 2;
    }
    hits
}

/// Locate the classic-generation raw-read levers' anchors (VID gate + AKE gate),
/// each required unique. Returns the two offsets when both are cleanly present.
/// Full-image scan (de-hardcoded): the classic VID/AKE gates are unique image-wide
/// on all 17 classic images, but a fixed 0x170000..0x180000 window missed the ones
/// whose AACS block is relocated (BH16NS40 ~0x139k, BE14NU40 1.01 ~0x180640). The
/// unique-match guard below keeps it safe.
fn classic_rawread_anchors(image: &[u8]) -> Option<(u32, u32)> {
    let vid = masked_matches(image, VID_GATE_SIG_CLASSIC, 0, image.len());
    let ake = masked_matches(image, AKE_GATE_SIG_CLASSIC, 0, image.len());
    match (vid.as_slice(), ake.as_slice()) {
        ([v], [a]) => Some((*v as u32, *a as u32)),
        _ => None,
    }
}

impl Engine for Mt1939Engine {
    fn name(&self) -> &'static str {
        "MT1939"
    }

    fn create(&self, image: &[u8]) -> Result<CreateReport> {
        self.create_with_defaults(image, &BootSettings::standard())
    }

    fn create_with_defaults(&self, image: &[u8], defaults: &BootSettings) -> Result<CreateReport> {
        // Classic-generation MT1939 ("MT1939 Boot Code") has its own base shape
        // (dispatch-table window, SRAM flag base, inline sense). It builds through
        // build_report_classic; the modern monolith below covers JB8/JBP6/JBC6.
        if is_classic(image) {
            return Mt1959Engine
                .build_report_classic_with_defaults(image, defaults)
                .map_err(|e| anyhow!("MT1939 classic create: {e:#}"));
        }
        // JB8/MT1959-lineage images build via the shared modern machinery.
        Mt1959Engine
            .build_report_with_defaults(image, defaults)
            .map_err(|e| {
                anyhow!(
                    "MT1939 create: {e:#} (base build failed; use `modify` for the \
                 downgrade-enable lever)"
                )
            })
    }

    fn modify(&self, image: &[u8]) -> Result<ModifyReport> {
        self.modify_with_defaults(image, &BootSettings::standard())
    }

    fn modify_with_defaults(&self, image: &[u8], defaults: &BootSettings) -> Result<ModifyReport> {
        let chip = family::detect_chip(image)?;
        let cap = family::capability_for(&chip.model, chip.family);

        // JB8 / JBP6 / JBC6 (MT1959-lineage): the full MT1959 lever machinery
        // applies verbatim — the base finders, VID/AKE/Speed/Region signatures and
        // detours all transfer. Delegate and relabel the family. Any lever whose
        // signature misses (e.g. a JB8-base image whose VID uses classic
        // scheduling) is reported SignatureNotFound by the never-abort driver, so
        // the image still partial-applies.
        if !is_classic(image) {
            if let Ok(mut report) =
                Mt1959Engine.build_modify_with_defaults(image, &chip, &cap, defaults)
            {
                report.engine = "MT1939";
                return Ok(report);
            }
            // Fall through to the DE-only path if the shared build unexpectedly
            // fails on a non-classic image (degrade, never refuse).
        }

        // Classic generation uses its own source-qualified feature and conversion
        // builders. A missing base falls back to downgrade-enable below.
        if is_classic(image) {
            if let Ok(report) =
                Mt1959Engine.build_modify_classic_with_defaults(image, &chip, &cap, defaults)
            {
                return Ok(report);
            }
        }

        // Family-agnostic downgrade-enable remains available when the base fails.
        // No absent feature hook becomes an advertised setting.
        let mut out = image.to_vec();
        let mut levers = Vec::new();

        let de = if chip.descriptor_present {
            let off = family::DESCRIPTOR_OFFSET + DE_OFF_IN_DESCRIPTOR;
            if off >= out.len() {
                LeverReport::not_applicable(LeverId::DowngradeEnable, "identity page truncated")
            } else if out[off] == 0xDE {
                LeverReport::already(LeverId::DowngradeEnable, vec![("de_off", off as u32)])
            } else {
                out[off] = 0xDE;
                LeverReport::applied(LeverId::DowngradeEnable, vec![("de_off", off as u32)])
            }
        } else {
            LeverReport::not_applicable(LeverId::DowngradeEnable, "no MTEK identity page")
        };
        levers.push(de);

        // In scope for these BD-writer parts, but the classic-generation emit is
        // pending its Identity base — report precisely (never-abort partial).
        levers.push(LeverReport::missed(
            LeverId::RegionFree,
            "MT1939 classic generation — RPC emitter transfers but the flag-gated \
             detour needs the classic Identity base (sense-setter + injected handler)",
        ));
        // Raw read: the classic VID + AKE gates are reversed and proven-unique; when
        // both are located we report their offsets so the image is auditably
        // wireable, with only the classic Identity base + detour still pending.
        levers.push(match classic_rawread_anchors(image) {
            Some((vid_gate, ake_gate)) => LeverReport {
                id: LeverId::RawRead,
                outcome: super::lever::LeverOutcome::SignatureNotFound {
                    detail: "classic VID + AKE gates located (reversed, proven-unique); full \
                             raw-read detour pending the classic Identity base"
                        .to_string(),
                },
                hooks: vec![],
                facts: vec![
                    ("vid_gate_classic", vid_gate),
                    ("ake_gate_classic", ake_gate),
                ],
            },
            None => LeverReport::missed(
                LeverId::RawRead,
                "MT1939 classic generation — VID/AKE gate anchors not located in this image",
            ),
        });
        levers.push(LeverReport::missed(
            LeverId::Speed,
            "Read-speed control requires the classic CDB base and boot hook; this image did not establish that complete contract",
        ));

        if !levers.iter().any(|l| l.outcome.is_effective()) {
            bail!(
                "{} (MT1939: no identity page for the DE byte)",
                super::lever::NOT_MODIFIABLE
            );
        }

        let signed = cmac::resign(&out).map_err(|e| anyhow!("re-sign failed: {e}"))?;

        Ok(ModifyReport {
            engine: "MT1939",
            family: chip.family.label().to_string(),
            vendor: chip.vendor.clone(),
            model: chip.model.clone(),
            rev: chip.rev.clone(),
            vendor_specific: chip.vendor_specific.clone(),
            media: cap.media_class.label().to_string(),
            levers,
            image: signed,
            validation: super::lever::Validation::StaticOnly,
        })
    }
}

#[cfg(test)]
#[path = "mt1939_tests.rs"]
mod tests;
