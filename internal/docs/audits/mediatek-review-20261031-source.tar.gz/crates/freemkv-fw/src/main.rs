//! freemkv-fw command-line interface.
//!
//! A firmware *authoring* tool: it verifies and re-signs the integrity
//! structures embedded in optical-drive firmware images, and can probe a live
//! drive over SCSI to check whether it is already running freemkv firmware.
//! Everything except `verify <device>` only reads and rewrites `.bin` images
//! on disk — it never touches a device.
//!
//! * `freemkv-fw modify <input.bin> [output.bin]` — build freemkv firmware from
//!   an MTK image (inject the built mods and re-sign).
//! * `freemkv-fw verify <path>` — dual mode: a regular file gets the on-disk
//!   integrity-region verify (below); a device node (`/dev/...`, or a
//!   character/block special file) gets a live IDENTITY probe instead.
//!
//! The tool is chipset-agnostic: it auto-selects an [`IntegrityScheme`] for the
//! image (or accepts `--family` to force one). Only the MediaTek MT19xx AES-CMAC
//! scheme is implemented today; the CLI layer hardcodes no chipset.

macro_rules! println {
    () => { freemkv_flash::output::emit(format_args!(""), true, false) };
    ($($arg:tt)*) => { freemkv_flash::output::emit(format_args!($($arg)*), true, false) };
}
macro_rules! eprintln {
    ($($arg:tt)*) => { freemkv_flash::output::emit(format_args!($($arg)*), true, true) };
}

use std::path::{Path, PathBuf};
use std::process::ExitCode;

use anyhow::{bail, Context, Result};
use clap::{Parser, Subcommand};

// The authoring engine and its integrity schemes now live in the `freemkv_fw`
// *library* (see `src/lib.rs`), so this CLI and the desktop GUI share one code
// path and cannot drift.
use freemkv_flash::{platform, style};
use freemkv_fw::boot::{BootFeature, BootSettings, BootSupport};
use freemkv_fw::scheme::{select_scheme, Family, IntegrityScheme, MtkCmac, RegionVerdict};
use freemkv_fw::{abi, api, diagnostics, engine, family};

/// freemkv firmware authoring tool (modify / verify).
#[derive(Parser, Debug)]
#[command(name = "freemkv-fw", version, about, long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand, Debug)]
enum Command {
    /// Query exact-image capabilities as JSON using the real Modify preview.
    /// Reports unsupported inputs explicitly; never saves generated firmware.
    Capabilities {
        /// Firmware image or MediaTek release package.
        input: PathBuf,
    },
    /// Create freemkv firmware from an OEM image: hijack the `READ BUFFER`
    /// (`0x3C`) handler via the platform engine and re-sign.
    #[command(name = "modify", alias = "create")]
    Create {
        /// Boot setting (repeatable): unrestricted/hrl/encryption=on|off|oem,
        /// speed=oem|uncapped, region=oem|free. Applied on every boot.
        #[arg(long = "default", value_name = "FEATURE=VALUE")]
        defaults: Vec<String>,
        /// Build and validate the requested settings without writing an output file.
        #[arg(long)]
        dry_run: bool,
        /// Source OEM firmware image (.bin) or release package (.tar).
        input: PathBuf,
        /// Output path (default preserves the input BIN/TAR format).
        output: Option<PathBuf>,
        /// Rewrite the input image in place.
        #[arg(long)]
        in_place: bool,
        /// Emit a machine-readable JSON report instead of the human table.
        #[arg(long)]
        json: bool,
        /// STRICT base build: run the all-or-nothing `api::create` (the KAT's
        /// `build_report`) instead of the never-abort MODIFY path. Refuses (exits
        /// non-zero) unless the image has a real freemkv BASE — vendor-command
        /// handler + Save/Reset + boot-init — and, with `--json`, emits base facts
        /// plus per-feature availability derived from the resolved gates (not the
        /// modify levers). This is the truthful gate the publish pipeline uses.
        #[arg(long)]
        base: bool,
        /// After building, run the structural detour audit (prove each Applied
        /// lever's `bl` and stub actually landed, the record was repointed, the
        /// DE byte is set, and CMAC verifies) and print PASS/FAIL per check.
        /// Exits non-zero if any check fails.
        #[arg(long)]
        audit: bool,
    },
    /// Verify a firmware image (file) or probe a live drive (device) for
    /// freemkv firmware.
    ///
    /// A regular file gets the read-only on-disk integrity-region verify
    /// (per-region match/mismatch table). A device node (a path starting
    /// with `/dev/`, or one that is a character/block special file) instead
    /// gets a live IDENTITY probe over SCSI: no data is written.
    Verify {
        /// Firmware image (.bin) to verify, or a device node (e.g. `/dev/sg1`)
        /// to probe.
        path: PathBuf,
        /// Force a chipset family instead of auto-detecting (file mode only).
        #[arg(long, value_enum)]
        family: Option<Family>,
    },
    /// Probe a live freemkv drive over the vendor command:
    /// identity, or a memory read via [`abi::Verb::DumpAll`].
    ///
    /// With no dump flags: prints the drive's freemkv identity.
    /// `--dump <hex-addr> --len <hex-len> --out <file>`: read an explicit range.
    /// `--full --out <prefix>`: capture the entire decrypted image (flash + RAM
    /// banks) with auto-stop at the end of each readable region — one file per
    /// captured region, named `<prefix>-<startVA>.bin`.
    Info {
        /// Device node, e.g. `/dev/sg0`.
        device: PathBuf,
        /// Memory-read start address (hex, e.g. `0x1f80000`).
        #[arg(long)]
        dump: Option<String>,
        /// Memory-read length (hex). Required with `--dump`.
        #[arg(long)]
        len: Option<String>,
        /// Capture the entire decrypted image (flash + RAM banks), auto-stop.
        #[arg(long)]
        full: bool,
        /// Output file (with `--dump`) or filename prefix (with `--full`).
        #[arg(short, long)]
        out: Option<PathBuf>,
    },
}

fn main() -> ExitCode {
    let cli = match freemkv_flash::cli::parse::<Cli>() {
        Ok(cli) => cli,
        Err(code) => return code,
    };
    let operation = match &cli.command {
        Command::Create { .. } => "create",
        Command::Capabilities { .. } => "capabilities",
        Command::Verify { .. } => "verify",
        Command::Info { .. } => "info",
    };
    let verification_refusal = match &cli.command {
        Command::Verify { path, .. } if classify_verify_target(path) == VerifyTarget::File => {
            freemkv_flash::user_error::IssueCode::FirmwareInvalid
        }
        _ => freemkv_flash::user_error::IssueCode::FirmwareNotDetected,
    };
    let result = diagnostics::run(operation, || {
        let code = match cli.command {
            Command::Capabilities { input } => {
                let artifact = freemkv_fw::artifact::Artifact::parse(diagnostics::read(&input)?)?;
                println!(
                    "{}",
                    freemkv_fw::capabilities::report_json(artifact.image())
                );
                Ok(ExitCode::SUCCESS)
            }
            Command::Create {
                input,
                output,
                in_place,
                json,
                base,
                audit,
                defaults,
                dry_run,
            } => BootSettings::parse(&defaults)
                .map_err(|e| e.context(freemkv_flash::user_error::IssueCode::CommandOptions))
                .and_then(|defaults| {
                    cmd_create_configured(
                        &input,
                        output,
                        in_place,
                        json,
                        base,
                        audit,
                        &CreateSettings { defaults, dry_run },
                    )
                }),
            Command::Verify { path, family } => cmd_verify(&path, family),
            Command::Info {
                device,
                dump,
                len,
                full,
                out,
            } => cmd_info(
                &device,
                dump.as_deref(),
                len.as_deref(),
                full,
                out.as_deref(),
            ),
        }?;
        diagnostics::record(format!("CLI exit: {code:?}"));
        if code != ExitCode::SUCCESS {
            return Err(
                anyhow::anyhow!("{operation} reported failure; see diagnostic details")
                    .context(verification_refusal),
            );
        }
        Ok(code)
    });
    match result {
        Ok(code) => code,
        Err(e) => {
            freemkv_flash::cli::print_error(&e);
            ExitCode::FAILURE
        }
    }
}

/// Short hex preview of a digest (first 4 bytes) for compact tables.
fn short_hex(d: &[u8; 16]) -> String {
    format!("{:02x}{:02x}{:02x}{:02x}", d[0], d[1], d[2], d[3])
}

// ---------------------------------------------------------------------------
// verify
// ---------------------------------------------------------------------------

/// Pure core: select a scheme and verify. Returns the scheme name + verdicts.
fn verify_image(
    image: &[u8],
    family: Option<Family>,
) -> Result<(&'static str, Vec<RegionVerdict>)> {
    let scheme = select_scheme(image, family)?;
    diagnostics::record(format!(
        "verify: scheme={} forced={family:?}",
        scheme.name()
    ));
    let verdicts = scheme.verify(image)?;
    for verdict in &verdicts {
        diagnostics::record(format!("integrity verdict: {verdict:?}"));
    }
    Ok((scheme.name(), verdicts))
}

/// What kind of target `verify`'s argument names.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum VerifyTarget {
    /// A regular firmware image on disk — verify its integrity table(s).
    File,
    /// A live device node — probe it over SCSI for freemkv firmware.
    Device,
}

/// Classify `path` for `verify`'s dual-mode dispatch.
///
/// A path is treated as a device if it looks like a device path (starts with
/// `/dev/`, which also covers `/dev/sg*`) or — when it already exists on
/// disk — its filesystem metadata says it is a character or block special
/// file. Anything else, including a plain path that doesn't exist yet, is
/// treated as a file, so the ordinary "no such file" error still fires for a
/// typo'd image path instead of being swallowed by device-probe logic.
fn classify_verify_target(path: &Path) -> VerifyTarget {
    if path.starts_with("/dev/") {
        return VerifyTarget::Device;
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::FileTypeExt;
        if let Ok(meta) = std::fs::symlink_metadata(path) {
            let ft = meta.file_type();
            if ft.is_char_device() || ft.is_block_device() {
                return VerifyTarget::Device;
            }
        }
    }
    VerifyTarget::File
}

fn cmd_verify(path: &Path, family: Option<Family>) -> Result<ExitCode> {
    match classify_verify_target(path) {
        VerifyTarget::Device => cmd_verify_device(path),
        VerifyTarget::File => cmd_verify_file(path, family),
    }
}

fn cmd_verify_file(path: &Path, family: Option<Family>) -> Result<ExitCode> {
    let image = diagnostics::read(path).with_context(|| format!("reading {}", path.display()))?;
    let artifact = freemkv_fw::artifact::Artifact::parse(image)?;
    let image = artifact.image().to_vec();
    let (scheme_name, verdicts) = verify_image(&image, family)?;

    println!("{}", style::kv("scheme", scheme_name));
    print_verdicts(&verdicts);

    let mismatches = verdicts.iter().filter(|v| !v.ok).count();
    if verdicts.is_empty() {
        println!(
            "{}",
            style::status_line("summary", "no active regions", style::Status::Warn)
        );
        Ok(ExitCode::FAILURE)
    } else if mismatches == 0 {
        println!(
            "{}",
            style::status_line(
                "summary",
                &format!("{} region(s) OK", verdicts.len()),
                style::Status::Ok
            )
        );
        Ok(ExitCode::SUCCESS)
    } else {
        println!(
            "{}",
            style::status_line(
                "summary",
                &format!("{mismatches} of {} region(s) MISMATCH", verdicts.len()),
                style::Status::Fail
            )
        );
        Ok(ExitCode::FAILURE)
    }
}

// ---------------------------------------------------------------------------
// verify (live drive)
// ---------------------------------------------------------------------------

/// Probe a live drive for freemkv firmware by sending the Identity command
/// built by [`abi::build_identity_cdb`].
///
/// Opens the device read-only (never writes anything) via [`platform::open`].
///
/// The injected Identity handler (engine `build_handler`, IDENTITY arm) returns
/// [`abi::RESP_MAGIC`] + version + the live feature-state table through the
/// normal data-in path, so [`abi::verify_response`] on the returned buffer is
/// the authoritative live check. (The unused [`abi::SENSE_IDENTITY`] constant is
/// a vestige of an earlier sense-based design and is never emitted.) This never
/// writes and never crashes.
fn cmd_verify_device(path: &Path) -> Result<ExitCode> {
    let path_str = path.to_string_lossy();
    let mut dev =
        platform::open(&path_str, false).with_context(|| format!("opening {path_str}"))?;

    const ALLOC_LEN: usize = 96;
    let cdb = abi::build_identity_cdb(ALLOC_LEN as u16);

    match dev.command_in(&cdb, ALLOC_LEN) {
        Ok(resp) if abi::verify_response(&resp) => {
            let detail = match resp.get(abi::RESP_MAGIC.len()) {
                Some(&v) => format!(
                    "DETECTED on {path_str} {}",
                    style::dim(&format!("(version 0x{v:02x})"))
                ),
                None => format!("DETECTED on {path_str}"),
            };
            println!(
                "{}",
                style::status_line("freemkv firmware", &detail, style::Status::Ok)
            );
            Ok(ExitCode::SUCCESS)
        }
        // Either a well-formed non-freemkv response (e.g. a plain INQUIRY
        // reply on stock firmware) or a SCSI-level error from a drive that
        // doesn't recognize the knock at all — both mean "not freemkv".
        Ok(_) | Err(_) => {
            println!(
                "{}",
                style::status_line(
                    "freemkv firmware",
                    &format!(
                        "NOT DETECTED on {path_str} {}",
                        style::dim("(stock/OEM or other firmware)")
                    ),
                    style::Status::Warn
                )
            );
            Ok(ExitCode::FAILURE)
        }
    }
}

// ---------------------------------------------------------------------------
// info (live drive: identity + subfn-07 memory read)
// ---------------------------------------------------------------------------

/// Parse a hex (or decimal) integer that may carry a `0x` prefix.
fn parse_u32(s: &str) -> Result<u32> {
    let t = s.trim();
    let v = t
        .strip_prefix("0x")
        .or_else(|| t.strip_prefix("0X"))
        .map(|h| u32::from_str_radix(h, 16))
        .unwrap_or_else(|| t.parse::<u32>())
        .with_context(|| format!("invalid number: {s}"))
        .context(freemkv_flash::user_error::IssueCode::CommandOptions)?;
    Ok(v)
}

/// Read `len` bytes starting at `start` via [`abi::Verb::DumpAll`], in
/// [`abi::MEMREAD_LEN`]-byte windows. When `auto_stop`, a run of consecutive
/// unreadable windows (transport/sense error) ends the read early — the natural
/// "end of mapped memory" signal. Unreadable windows before the run are
/// zero-filled to keep byte offsets aligned to `start`. Returns the bytes read.
fn mem_read(dev: &mut dyn platform::ScsiDevice, start: u32, len: u64, auto_stop: bool) -> Vec<u8> {
    const STOP_AFTER: u32 = 16; // consecutive faults = end of region
                                // Cap the up-front reservation: `--dump --len` is user-supplied and can be up
                                // to 4 GiB, which would abort the process on `with_capacity` before a single
                                // SCSI command issues. The Vec still grows to the full length as it reads.
    const RESERVE_CAP: u64 = 0x0400_0000; // 64 MiB
    let mut out = Vec::with_capacity(len.min(RESERVE_CAP) as usize);
    let mut faults = 0u32;
    let mut addr = start as u64;
    let end = start as u64 + len;
    while addr < end {
        let cdb = abi::build_memread_cdb(addr as u32);
        match dev.command_in(&cdb, abi::MEMREAD_LEN) {
            Ok(mut d) => {
                faults = 0;
                d.resize(abi::MEMREAD_LEN, 0);
                out.extend_from_slice(&d);
            }
            Err(_) => {
                faults += 1;
                if auto_stop && faults >= STOP_AFTER {
                    // drop the trailing all-fault fill and stop
                    out.truncate(
                        out.len()
                            .saturating_sub(((faults - 1) as usize) * abi::MEMREAD_LEN),
                    );
                    break;
                }
                out.extend_from_slice(&[0u8; abi::MEMREAD_LEN]);
            }
        }
        addr += abi::MEMREAD_LEN as u64;
    }
    out
}

/// The decrypted-image regions captured by `--full`: flash + the RAM banks the
/// runtime (boot block, OTFAD overlay, resident lib, SRAM state) decrypts into.
/// Each is read with auto-stop, so the caps are generous upper bounds.
const FULL_REGIONS: &[(u32, u64)] = &[
    (0x0000_0000, 0x0020_0000), // flash (plaintext + in-place-decrypted boot block)
    (0x01c0_0000, 0x0044_0000), // firmware RAM: data bank, overlay, resident lib, SRAM
];

fn cmd_info(
    device: &Path,
    dump: Option<&str>,
    len: Option<&str>,
    full: bool,
    out: Option<&Path>,
) -> Result<ExitCode> {
    let path_str = device.to_string_lossy();

    if full {
        let prefix = out
            .ok_or_else(|| anyhow::anyhow!("--full requires --out <prefix>"))
            .context(freemkv_flash::user_error::IssueCode::CommandOptions)?;
        let mut dev =
            platform::open(&path_str, false).with_context(|| format!("opening {path_str}"))?;
        for &(start, cap) in FULL_REGIONS {
            eprintln!(
                "{}",
                style::status_line(
                    "capture",
                    &format!("region 0x{start:08x} (cap 0x{cap:x}) …"),
                    style::Status::Ok
                )
            );
            let data = mem_read(dev.as_mut(), start, cap, true);
            let file = prefix.with_file_name(format!(
                "{}-{start:08x}.bin",
                prefix
                    .file_name()
                    .and_then(|s| s.to_str())
                    .unwrap_or("dump")
            ));
            diagnostics::write(&file, &data)
                .with_context(|| format!("writing {}", file.display()))?;
            println!(
                "{}",
                style::status_line(
                    "captured",
                    &format!(
                        "0x{start:08x}..0x{:08x} ({} bytes) -> {}",
                        start as u64 + data.len() as u64,
                        data.len(),
                        file.display()
                    ),
                    style::Status::Ok
                )
            );
        }
        return Ok(ExitCode::SUCCESS);
    }

    if let Some(d) = dump {
        let start = parse_u32(d)?;
        let length = parse_u32(
            len.ok_or_else(|| anyhow::anyhow!("--dump requires --len"))
                .context(freemkv_flash::user_error::IssueCode::CommandOptions)?,
        )? as u64;
        let mut dev =
            platform::open(&path_str, false).with_context(|| format!("opening {path_str}"))?;
        let data = mem_read(dev.as_mut(), start, length, false);
        match out {
            Some(o) => {
                diagnostics::write(o, &data).with_context(|| format!("writing {}", o.display()))?;
                println!(
                    "{}",
                    style::status_line(
                        "dump",
                        &format!(
                            "0x{start:08x} +0x{length:x} -> {} ({} bytes)",
                            o.display(),
                            data.len()
                        ),
                        style::Status::Ok
                    )
                );
            }
            None => {
                for (i, chunk) in data.chunks(16).enumerate() {
                    let hex: String = chunk.iter().map(|b| format!("{b:02x} ")).collect();
                    println!("{:08x}  {hex}", start as usize + i * 16);
                }
            }
        }
        return Ok(ExitCode::SUCCESS);
    }

    // No dump flags: identity probe (reuse the verify-device path).
    cmd_verify_device(device)
}

/// Print the per-region verdict table.
fn print_verdicts(verdicts: &[RegionVerdict]) {
    if verdicts.is_empty() {
        return;
    }
    println!(
        "{}",
        style::dim(&format!(
            "{:>3}  {:<21}  {:>9}  {:<8}  {:<8}  {:<8}",
            "idx", "range", "size", "status", "stored", "computed"
        ))
    );
    for v in verdicts {
        let size = (v.end as u64).saturating_sub(v.start as u64) + 1;
        let status_plain = if v.ok { "MATCH   " } else { "MISMATCH" };
        let status = if v.ok {
            style::green(status_plain)
        } else {
            style::red(status_plain)
        };
        println!(
            "{:>3}  {}  {}  {}  {}  {}",
            v.index,
            style::dim(&format!("{:<21}", format!("0x{:x}-0x{:x}", v.start, v.end))),
            style::dim(&format!("{:>9}", format!("0x{size:x}"))),
            status,
            style::dim(&short_hex(&v.stored)),
            style::dim(&short_hex(&v.computed)),
        );
    }
}

// ---------------------------------------------------------------------------
// sign
// ---------------------------------------------------------------------------

/// Pure core: select a scheme, re-sign, and self-verify the produced image.
///
/// Returns the scheme name, the new image bytes, and the list of changed
/// regions. Errors if the produced image fails to self-verify.
#[cfg(test)]
fn sign_image(
    image: &[u8],
    family: Option<Family>,
) -> Result<(&'static str, Vec<u8>, Vec<freemkv_fw::scheme::RegionChange>)> {
    let scheme = select_scheme(image, family)?;
    let (signed, changes) = scheme.sign(image)?;

    // Refuse to hand back an image that does not verify under its own scheme.
    diagnostics::record(format!("sign: scheme={} forced={family:?}", scheme.name()));
    let verdicts = scheme.verify(&signed)?;
    for verdict in &verdicts {
        diagnostics::record(format!("post-sign integrity: {verdict:?}"));
    }
    if verdicts.is_empty() || verdicts.iter().any(|v| !v.ok) {
        bail!("internal error: re-signed image does not self-verify");
    }
    Ok((scheme.name(), signed, changes))
}

// ---------------------------------------------------------------------------
// create
// ---------------------------------------------------------------------------

/// Default freemkv-output path: `<stem>.freemkv.bin` next to the input.
fn default_created_path(input: &Path) -> PathBuf {
    let stem = input
        .file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| "image".to_string());
    input.with_file_name(format!(
        "{stem}.freemkv.{}",
        input.extension().and_then(|e| e.to_str()).unwrap_or("bin")
    ))
}

struct CreateSettings {
    defaults: BootSettings,
    dry_run: bool,
}

#[cfg(test)]
fn cmd_create(
    path: &Path,
    out: Option<PathBuf>,
    in_place: bool,
    json: bool,
    base: bool,
    audit: bool,
) -> Result<ExitCode> {
    cmd_create_configured(
        path,
        out,
        in_place,
        json,
        base,
        audit,
        &CreateSettings {
            defaults: BootSettings::standard(),
            dry_run: false,
        },
    )
}

fn cmd_create_configured(
    path: &Path,
    out: Option<PathBuf>,
    in_place: bool,
    json: bool,
    base: bool,
    audit: bool,
    settings: &CreateSettings,
) -> Result<ExitCode> {
    let image = diagnostics::read(path).with_context(|| format!("reading {}", path.display()))?;

    let artifact = freemkv_fw::artifact::Artifact::parse(image)?;
    let image = artifact.image().to_vec();

    // Resolve the output path up front so we fail fast on conflicts.
    let out_path = if in_place {
        if out.is_some() {
            return Err(
                anyhow::anyhow!("--in-place conflicts with an explicit output path")
                    .context(freemkv_flash::user_error::IssueCode::CommandOptions),
            );
        }
        path.to_path_buf()
    } else {
        let dest = out.unwrap_or_else(|| default_created_path(path));
        if dest == path {
            return Err(anyhow::anyhow!(
                "refusing to overwrite the input ({}); pass --in-place or a different output path",
                path.display()
            )
            .context(freemkv_flash::user_error::IssueCode::CommandOptions));
        }
        dest
    };

    // STRICT base build: the all-or-nothing `api::create`. It bails (→ non-zero
    // exit) unless a real freemkv BASE was forged, which is exactly the truthful
    // publish gate. On success the report's grounded facts tell us which feature
    // gates actually resolved for THIS image.
    if base {
        let outcome = api::create_with_defaults(&image, &settings.defaults)
            .context("building freemkv BASE firmware")?;
        let support = BootSupport::from_create(&outcome.report);
        let report_json = settings
            .defaults
            .report_json(&support, &base_report_json(&outcome));
        diagnostics::record(&report_json);
        if !settings.dry_run {
            diagnostics::write(&out_path, &artifact.output(outcome.image().to_vec())?)
                .with_context(|| format!("writing {}", out_path.display()))?;
        }
        if json {
            println!("{report_json}");
        } else {
            if !settings.dry_run {
                print_base_report(&outcome, &out_path);
            }
            print_boot_settings(&settings.defaults, &support);
            if settings.dry_run {
                println!("Dry run: no output written");
            }
        }
        return Ok(ExitCode::SUCCESS);
    }

    // Pick the platform engine (a clean refusal only on an unidentified/garbage
    // image), then MODIFY: apply every lever this image supports and report each
    // one. A missing signature skips that lever, it does not abort the build.
    let engine = engine::detect(&image).context("selecting a platform engine for this image")?;
    diagnostics::record(format!(
        "modify: engine={} audit={audit} base={base} json={json} output={out_path:?}",
        engine.name()
    ));
    let (report, support) = api::modify_with_defaults(&image, &settings.defaults)
        .context("building freemkv firmware")?;
    let report_json = settings.defaults.report_json(&support, &report.to_json());
    diagnostics::record(&report_json);

    // Zero levers Applied: refuse and write nothing. `--json` still emits the
    // report so tooling can read why; the human report shows the per-lever table.
    if let Some(why) = report
        .refusal()
        .filter(|_| freemkv_fw::boot::inspect(&image).ok().flatten().is_none())
    {
        if json {
            println!("{report_json}");
        } else {
            print_modify_report(&report, None, 0);
            if why == engine::lever::NOT_MODIFIABLE {
                println!();
                println!("The stock image can still be flashed as-is with freemkv-flash.");
            }
        }
        return Err(anyhow::anyhow!("{why}")
            .context(freemkv_flash::user_error::IssueCode::UnsupportedFirmware));
    }

    // Never write an image that does not re-verify.
    let verdicts = MtkCmac.verify(&report.image)?;
    for verdict in &verdicts {
        diagnostics::record(format!("post-modify integrity: {verdict:?}"));
    }
    if verdicts.is_empty() || verdicts.iter().any(|v| !v.ok) {
        bail!("internal error: modified image does not re-verify");
    }

    // Structural detour audit: prove every Applied lever actually landed.
    if audit {
        let result = engine::audit::audit_image(&image, &report);
        for check in &result.checks {
            diagnostics::record(format!(
                "structural audit: lever={} what={} ok={} detail={}",
                check.lever, check.what, check.ok, check.detail
            ));
        }
        if !json {
            println!("structural audit:");
            for c in &result.checks {
                let mark = if c.ok { "PASS" } else { "FAIL" };
                println!("  [{mark}] {:<14} {} — {}", c.lever, c.what, c.detail);
            }
        }
        if !result.ok() {
            bail!(
                "structural audit FAILED: {} check(s) did not pass — refusing to write",
                result.failures().count()
            );
        }
    }

    if !settings.dry_run {
        diagnostics::write(&out_path, &artifact.output(report.image.clone())?)
            .with_context(|| format!("writing {}", out_path.display()))?;
    }

    if json {
        println!("{report_json}");
    } else {
        print_modify_report(
            &report,
            if settings.dry_run {
                None
            } else {
                Some(&out_path)
            },
            verdicts.len(),
        );
        print_boot_settings(&settings.defaults, &support);
        if settings.dry_run {
            println!("Dry run: no output written");
        }
    }

    Ok(ExitCode::SUCCESS)
}

fn print_boot_settings(defaults: &BootSettings, support: &BootSupport) {
    println!("Boot settings (applied each time the drive starts):");
    for feature in BootFeature::ALL {
        let value = if support.supports(feature) {
            defaults.label(feature)
        } else {
            "Not supported by this firmware"
        };
        println!("  {:<22} {value}", feature.label());
    }
}

/// The truthful per-feature availability for a STRICT base build, derived from
/// the resolved gate facts in the [`engine::CreateReport`] (NOT the never-abort
/// modify levers). Each `(display-name, resolved?)` pair says whether that
/// feature's gate actually landed for THIS image. Order is stable.
fn base_features(report: &engine::CreateReport) -> Vec<(&'static str, bool)> {
    // The 6 firmware feature FLAGS (flag-table bytes 1..=6), each "available" when its
    // OEM gate resolved AND the detour stub was actually emitted. Deliberately NOT
    // listed: "Raw Read" (a host composition — not a fw feature) and "Downgrade
    // Enable" (a fixed base identity-page byte, not a tri-state flag).
    vec![
        ("Speed", report.speed_stub_va != 0),
        ("Region", report.region_stub_va != 0),
        ("UHD", report.uhd_stub_va != 0),
        ("BD", report.bd_stub_va != 0),
        ("HRL", report.hrl_stub_va != 0),
        ("Encryption", report.ake_stub_va != 0),
    ]
}

/// Minimal JSON string escaping for the hand-rolled base report.
fn json_str(s: &str) -> String {
    let mut o = String::with_capacity(s.len() + 2);
    o.push('"');
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            '\r' => o.push_str("\\r"),
            '\t' => o.push_str("\\t"),
            c if (c as u32) < 0x20 => o.push_str(&format!("\\u{:04x}", c as u32)),
            c => o.push(c),
        }
    }
    o.push('"');
    o
}

/// Machine-readable STRICT base report: identity + grounded base facts + the
/// per-feature availability the publish pipeline advertises. `base` is always
/// `true` here (this path only runs when `api::create` succeeded), so a caller
/// can gate purely on the process exit code and read `features[]` for the rest.
fn base_report_json(outcome: &api::CreateOutcome) -> String {
    let r = &outcome.report;
    // Identity: from the detected chip (present whenever create succeeded). Media
    // class is derived the same way the engine's own report derives it.
    let (vendor, model, rev, vspec, family_label, media) = match &outcome.chip {
        Some(c) => {
            let media = family::capability_for(&c.model, c.family)
                .media_class
                .label();
            (
                c.vendor.clone(),
                c.model.clone(),
                c.rev.clone(),
                c.vendor_specific.clone(),
                c.family.label(),
                media,
            )
        }
        None => (
            String::new(),
            String::new(),
            String::new(),
            String::new(),
            outcome.engine,
            "",
        ),
    };

    let mut s = String::new();
    s.push('{');
    s.push_str("\"base\":true,");
    s.push_str(&format!("\"engine\":{},", json_str(outcome.engine)));
    s.push_str(&format!("\"family\":{},", json_str(family_label)));
    s.push_str(&format!("\"vendor\":{},", json_str(&vendor)));
    s.push_str(&format!("\"model\":{},", json_str(&model)));
    s.push_str(&format!("\"rev\":{},", json_str(&rev)));
    s.push_str(&format!("\"vendor_specific\":{},", json_str(&vspec)));
    s.push_str(&format!("\"media\":{},", json_str(media)));
    // Grounded base facts: the addresses that PROVE a real base (handler +
    // boot-init trampoline that reloads the persisted flag table = Save/Reset).
    s.push_str("\"base_facts\":{");
    s.push_str(&format!("\"handler_va\":{},", r.handler_va));
    s.push_str(&format!("\"boot_stub_va\":{},", r.boot_stub_va));
    s.push_str(&format!("\"boot_init_site\":{},", r.boot_init_site));
    s.push_str(&format!("\"de_off\":{},", r.de_off));
    s.push_str(&format!("\"speed_gate\":{},", r.speed_gate));
    s.push_str(&format!("\"speed_tail_site\":{},", r.speed_tail_site));
    s.push_str(&format!("\"region_emitter\":{},", r.region_emitter));
    s.push_str(&format!("\"ake_gate\":{},", r.ake_gate));
    s.push_str(&format!("\"uhd_stub_va\":{},", r.uhd_stub_va));
    s.push_str(&format!("\"bd_stub_va\":{},", r.bd_stub_va));
    s.push_str(&format!("\"hrl_sites\":{}", r.hrl_sites.len()));
    s.push('}');
    s.push(',');
    // Per-feature availability derived from the resolved gates.
    s.push_str("\"features\":[");
    for (i, (name, ok)) in base_features(r).into_iter().enumerate() {
        if i > 0 {
            s.push(',');
        }
        s.push_str(&format!("{{\"name\":{},\"ok\":{ok}}}", json_str(name)));
    }
    s.push_str("]}");
    s
}

/// Human-readable summary for `create --base` (no `--json`): identity, the base
/// facts, and which feature gates resolved.
fn print_base_report(outcome: &api::CreateOutcome, out_path: &Path) {
    let r = &outcome.report;
    let id = outcome
        .chip
        .as_ref()
        .map(|c| format!("{} {} · rev {}", c.vendor, c.model, c.rev))
        .unwrap_or_else(|| outcome.engine.to_string());
    println!();
    println!(
        "{} — {} · {} [STRICT base]",
        style::header(&format!("freemkv-fw {}", env!("CARGO_PKG_VERSION"))),
        outcome.engine,
        id,
    );
    println!(
        "  {}",
        style::dim(&format!(
            "handler 0x{:x} · boot-init stub 0x{:x} · DE 0x{:x}",
            r.handler_va, r.boot_stub_va, r.de_off
        ))
    );
    println!();
    for (name, ok) in base_features(r) {
        println!(
            "{}",
            style::status_line(
                name,
                if ok { "available" } else { "unavailable" },
                if ok {
                    style::Status::Ok
                } else {
                    style::Status::Warn
                },
            )
        );
    }
    println!();
    println!(
        "Wrote {} {}",
        out_path.display(),
        style::dim(&format!("({} bytes)", outcome.image().len())),
    );
}

/// Print the per-lever MODIFY report: a summary line + one row per lever with its
/// outcome (applied / already set / n/a / skipped) and grounded facts, all
/// derived from the real [`engine::ModifyReport`] so the output can never drift
/// from what was emitted.
fn print_modify_report(
    report: &engine::ModifyReport,
    out_path: Option<&Path>,
    cmac_regions: usize,
) {
    use engine::lever::LeverOutcome;

    println!();
    println!(
        "{} — {} · {} {} · rev {}  [{}]",
        style::header(&format!("freemkv-fw {}", env!("CARGO_PKG_VERSION"))),
        report.engine,
        report.vendor,
        report.model,
        report.rev,
        report.media,
    );
    println!("  {}", style::bold(&report.summary()));
    if let Some(partial) = partial_note(report) {
        println!("  {partial}");
    }
    println!();

    for l in &report.levers {
        let sty = match &l.outcome {
            LeverOutcome::Applied | LeverOutcome::AlreadyPresent => style::Status::Ok,
            LeverOutcome::NotApplicable { .. } | LeverOutcome::SignatureNotFound { .. } => {
                style::Status::Warn
            }
        };
        println!(
            "{}",
            style::status_line(l.id.label(), l.outcome.word(), sty)
        );
        match &l.outcome {
            LeverOutcome::NotApplicable { reason } => {
                println!("{}", style::dim_line(&format!("      {reason}")))
            }
            LeverOutcome::SignatureNotFound { detail } => {
                println!("{}", style::dim_line(&format!("      {detail}")))
            }
            LeverOutcome::Applied | LeverOutcome::AlreadyPresent if !l.facts.is_empty() => {
                let facts: Vec<String> = l
                    .facts
                    .iter()
                    .map(|(k, v)| format!("{k} 0x{v:x}"))
                    .collect();
                println!(
                    "{}",
                    style::dim_line(&format!("      {}", facts.join(" · ")))
                );
            }
            _ => {}
        }
    }

    println!();
    println!(
        "{}",
        style::status_line(
            "validation",
            report.validation.note(),
            match report.validation {
                engine::lever::Validation::HardwareConfirmed => style::Status::Ok,
                engine::lever::Validation::StaticOnly => style::Status::Warn,
            },
        )
    );

    if let Some(out_path) = out_path {
        println!();
        println!(
            "Wrote {} {}",
            out_path.display(),
            style::dim(&format!(
                "({} bytes, {cmac_regions} CMAC region(s) OK)",
                report.image.len(),
            )),
        );
    }
}

/// The "Applied N of M changes; not supported on this image: ..." line for a
/// partial result (some levers Applied, some not). `None` when every lever
/// applied or nothing did (the zero case is refused, not summarised).
fn partial_note(report: &engine::ModifyReport) -> Option<String> {
    use engine::lever::LeverOutcome;

    let applied = report.applied_count();
    let unsupported: Vec<String> = report
        .levers
        .iter()
        .filter_map(|l| match &l.outcome {
            LeverOutcome::NotApplicable { reason } => Some(format!("{} ({reason})", l.id.label())),
            LeverOutcome::SignatureNotFound { detail } => {
                Some(format!("{} ({detail})", l.id.label()))
            }
            _ => None,
        })
        .collect();
    if applied == 0 || unsupported.is_empty() {
        return None;
    }
    Some(format!(
        "Applied {applied} of {} changes; not supported on this image: {}",
        report.levers.len(),
        unsupported.join(", ")
    ))
}

#[cfg(test)]
#[path = "main_tests.rs"]
mod tests;
