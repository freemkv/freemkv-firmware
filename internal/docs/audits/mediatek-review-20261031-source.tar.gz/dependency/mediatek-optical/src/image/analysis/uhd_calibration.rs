//! Source-bound startup calibration lookup paired with its native getter.
use super::{matches, ClassicParameter, ClassicParameterVariant, Error, SavedLink};
/// Complete native startup routine and its calibration lookup.
#[derive(Debug, Clone)]
pub struct ClassicCalibration {
    /// Native startup routine entry and saved frame.
    pub caller: SavedLink,
    /// First displaced LDR/ADDS/LDRH instruction.
    pub site: usize,
    /// Original table literal, before the native address adjustment. A detour
    /// is emitted only for the media-selected +0x58 implementation.
    pub original_base: u32,
    /// Signed native adjustment between the literal base and OEM coefficients.
    pub base_adjustment: i16,
    /// Native C8 coefficients; absent for state-independent getter layouts.
    pub c7_coefficients: Option<u32>,
}
const PATTERN: &[(u16, u16)] = &[
    (0xb5f8, 0xffff),
    (0x2500, 0xffff),
    (0x2803, 0xffff),
    (0xd801, 0xffff),
    (0x2400, 0xffff),
    (0xe010, 0xffff),
    (0x2804, 0xffff),
    (0xd801, 0xffff),
    (0x2401, 0xffff),
    (0xe00c, 0xffff),
    (0x2806, 0xffff),
    (0xd801, 0xffff),
    (0x2402, 0xffff),
    (0xe008, 0xffff),
    (0x2808, 0xffff),
    (0xd801, 0xffff),
    (0x2403, 0xffff),
    (0xe004, 0xffff),
    (0x280a, 0xffff),
    (0xd801, 0xffff),
    (0x2404, 0xffff),
    (0xe000, 0xffff),
    (0x2405, 0xffff),
    (0x4e00, 0xff00),
    (0x7831, 0xffff),
    (0x4288, 0xffff),
    (0xd900, 0xffff),
    (0x2501, 0xffff),
    (0x2808, 0xffff),
    (0xd301, 0xffff),
    (0x2002, 0xffff),
    (0xe000, 0xffff),
    (0x2001, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x4800, 0xff00),
    (0x4900, 0xff00),
    (0x5d00, 0xffff),
    (0x7008, 0xffff),
    (0x0037, 0xffff),
    (0x7030, 0xffff),
    (0x4900, 0xff00),
    (0x2002, 0xffff),
    (0x7008, 0xffff),
    (0x4a00, 0xff00),
    (0x69d0, 0xffff),
    (0x4900, 0xff00),
    (0x0066, 0xffff),
    (0x3176, 0xffff),
    (0x5b89, 0xffff),
    (0x0a00, 0xffff),
    (0x0200, 0xffff),
    (0x0609, 0xffff),
    (0x0e09, 0xffff),
    (0x4308, 0xffff),
    (0x61d0, 0xffff),
    (0x4a00, 0xff00),
    (0x6b10, 0xffff),
    (0x4900, 0xff00),
    (0x0c00, 0xffff),
    (0x310c, 0xffff),
    (0x5d09, 0xffff),
    (0x0400, 0xffff),
    (0x0209, 0xffff),
    (0x4308, 0xffff),
    (0x4900, 0xff00),
    (0x1d89, 0xffff),
    (0x5d09, 0xffff),
    (0x4308, 0xffff),
    (0x6310, 0xffff),
    (0x6bd1, 0xffff),
    (0x4800, 0xff00),
    (0x4001, 0xffff),
    (0x4800, 0xff00),
    (0x3012, 0xffff),
    (0x5d00, 0xffff),
    (0x0640, 0xffff),
    (0x0e40, 0xffff),
    (0x4301, 0xffff),
    (0x0200, 0xffff),
    (0x4308, 0xffff),
    (0x63d0, 0xffff),
    (0x4800, 0xff00),
    (0x303c, 0xffff),
    (0x5d00, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x7838, 0xffff),
    (0x4900, 0xff00),
    (0x2317, 0xffff),
    (0x7a09, 0xffff),
    (0x4358, 0xffff),
    (0x0649, 0xffff),
    (0x0f49, 0xffff),
    (0x4088, 0xffff),
    (0x0400, 0xffff),
    (0x0c00, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x20a1, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x2d01, 0xffff),
    (0xd101, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x4b00, 0xff00),
    (0x0018, 0xffff),
    (0x3040, 0xffff),
    (0x2c00, 0xffff),
    (0xd111, 0xffff),
    (0x6b19, 0xffff),
    (0x220f, 0xffff),
    (0x0412, 0xffff),
    (0x4391, 0xffff),
    (0x2201, 0xffff),
    (0x04d2, 0xffff),
    (0x1889, 0xffff),
    (0x6319, 0xffff),
    (0x6a81, 0xffff),
    (0x4a00, 0xff00),
    (0x4011, 0xffff),
    (0x3108, 0xffff),
    (0x6281, 0xffff),
    (0x6981, 0xffff),
    (0x2203, 0xffff),
    (0x06d2, 0xffff),
    (0x4391, 0xffff),
    (0x6181, 0xffff),
    (0x6b19, 0xffff),
    (0x223f, 0xffff),
    (0x0612, 0xffff),
    (0x4391, 0xffff),
    (0x4a00, 0xff00),
    (0x3218, 0xffff),
    (0x5d12, 0xffff),
    (0x0692, 0xffff),
    (0x0892, 0xffff),
    (0x4311, 0xffff),
    (0x6319, 0xffff),
    (0x4900, 0xff00),
    (0x7809, 0xffff),
    (0x07ca, 0xffff),
    (0x6802, 0xffff),
    (0x4900, 0xff00),
    (0x4f00, 0xff00),
    (0xd00c, 0xffff),
    (0x5d09, 0xffff),
    (0x0b12, 0xffff),
    (0x0312, 0xffff),
    (0x0709, 0xffff),
    (0x0e09, 0xffff),
    (0x4311, 0xffff),
    (0x5d3a, 0xffff),
    (0x0712, 0xffff),
    (0x0f12, 0xffff),
    (0x4311, 0xffff),
    (0x003a, 0xffff),
    (0x3a2e, 0xffff),
    (0xe00b, 0xffff),
    (0x5d09, 0xffff),
    (0x0b12, 0xffff),
    (0x0312, 0xffff),
    (0x0709, 0xffff),
    (0x0e09, 0xffff),
    (0x4311, 0xffff),
    (0x5d3a, 0xffff),
    (0x0712, 0xffff),
    (0x0f12, 0xffff),
    (0x4311, 0xffff),
    (0x4a00, 0xff00),
    (0x1f92, 0xffff),
    (0x5d12, 0xffff),
    (0x0712, 0xffff),
    (0x0d12, 0xffff),
    (0x4311, 0xffff),
    (0x6001, 0xffff),
    (0x6841, 0xffff),
    (0x0909, 0xffff),
    (0x0109, 0xffff),
    (0x6041, 0xffff),
    (0x6a18, 0xffff),
    (0x2101, 0xffff),
    (0x0489, 0xffff),
    (0x4308, 0xffff),
    (0x6218, 0xffff),
    (0x6a98, 0xffff),
    (0x4900, 0xff00),
    (0x0a00, 0xffff),
    (0x0200, 0xffff),
    (0x1d89, 0xffff),
    (0x5d09, 0xffff),
    (0x4308, 0xffff),
    (0x6298, 0xffff),
    (0x6a58, 0xffff),
    (0x21ff, 0xffff),
    (0x1c49, 0xffff),
    (0x4308, 0xffff),
    (0x6258, 0xffff),
    (0x4800, 0xff00),
    (0x3058, 0xffff),
    (0x5b80, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x4a00, 0xff00),
    (0x6b10, 0xffff),
    (0x4900, 0xff00),
    (0x0c00, 0xffff),
    (0x0400, 0xffff),
    (0x1840, 0xffff),
    (0x6310, 0xffff),
    (0x2d00, 0xffff),
    (0xd101, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x2107, 0xffff),
    (0x4800, 0xff00),
    (0x02c9, 0xffff),
    (0x000a, 0xffff),
    (0x38bc, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x4d00, 0xff00),
    (0x4800, 0xff00),
    (0x350c, 0xffff),
    (0x5d29, 0xffff),
    (0x7001, 0xffff),
    (0x7801, 0xffff),
    (0x4800, 0xff00),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x5d28, 0xffff),
    (0x0841, 0xffff),
    (0x4800, 0xff00),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0xbdf8, 0xffff),
];
// Early four-rate native startup. Includes all index thresholds, the rate
// store and the saved R6 doubled-index producer; addresses are provenance only.
const FOUR_RATE_PREFIX: &[(u16, u16)] = &[
    (0xb5f8, 0xffff),
    (0x2500, 0xffff),
    (0x2803, 0xffff),
    (0xd801, 0xffff),
    (0x2400, 0xffff),
    (0xe008, 0xffff),
    (0x2804, 0xffff),
    (0xd801, 0xffff),
    (0x2401, 0xffff),
    (0xe004, 0xffff),
    (0x2806, 0xffff),
    (0xd801, 0xffff),
    (0x2402, 0xffff),
    (0xe000, 0xffff),
    (0x2403, 0xffff),
    (0x4e00, 0xff00),
    (0x7831, 0xffff),
    (0x4288, 0xffff),
    (0xd900, 0xffff),
    (0x2501, 0xffff),
    (0x2808, 0xffff),
    (0xd301, 0xffff),
    (0x2002, 0xffff),
    (0xe000, 0xffff),
    (0x2001, 0xffff),
    (0xf000, 0xf800),
    (0xd000, 0xd000),
    (0x4800, 0xff00),
    (0x385e, 0xffff),
    (0x5d00, 0xffff),
    (0x0037, 0xffff),
    (0x7030, 0xffff),
    (0x4900, 0xff00),
    (0x2002, 0xffff),
    (0x7008, 0xffff),
    (0x4a00, 0xff00),
    (0x69d0, 0xffff),
    (0x4900, 0xff00),
    (0x0066, 0xffff),
    (0x3910, 0xffff),
    (0x5b89, 0xffff),
];
fn literal(image: &[u8], at: usize) -> Result<u32, Error> {
    let op = u16::from_le_bytes(
        image
            .get(at..at + 2)
            .ok_or(Error::Truncated)?
            .try_into()
            .unwrap(),
    );
    let pool = ((at + 4) & !3) + usize::from(op & 255) * 4;
    Ok(u32::from_le_bytes(
        image
            .get(pool..pool + 4)
            .ok_or(Error::Truncated)?
            .try_into()
            .unwrap(),
    ))
}
impl ClassicCalibration {
    /// Bind all six speed thresholds, their doubled index, the startup lookup
    /// and its coefficient/rate identity with the independently matched getter.
    /// Other code layouts refuse; no numeric calibration is transplanted.
    pub fn detect(image: &[u8], state: u32) -> Result<Self, Error> {
        let parameter = ClassicParameter::detect(image, state)?;
        let length = PATTERN.len() * 2;
        if image.len() < length {
            return Err(Error::Truncated);
        }
        let mut result = None;
        for entry in (0..=image.len() - length).step_by(2) {
            if !matches(image, entry, PATTERN) {
                continue;
            }
            let site = entry + 0x196;
            let original_base = literal(image, site)?;
            if literal(image, entry + 0x46)? as usize != parameter.rates
                || (original_base as usize).checked_add(0x58) != Some(parameter.oem_coefficients)
            {
                return Err(Error::InvalidContract);
            }
            let c7_coefficients = match parameter.variant {
                ClassicParameterVariant::MediaSelected => Some(
                    u32::try_from(parameter.coefficients).map_err(|_| Error::InvalidContract)?,
                ),
                ClassicParameterVariant::StateIndependent => None,
            };
            let bound = Self {
                caller: SavedLink::bind(image, entry, site)?,
                site,
                original_base,
                base_adjustment: 0x58,
                c7_coefficients,
            };
            if result.replace(bound).is_some() {
                return Err(Error::Ambiguous);
            }
        }
        // This native startup variant uses the same state-independent getter
        // table. Bind its threshold/index producer, rate store, coefficient
        // lookup and saved-frame flow; no C7 replacement is required.
        if parameter.variant == ClassicParameterVariant::StateIndependent {
            for entry in (0..image.len().saturating_sub(0x1a0)).step_by(2) {
                if !matches(image, entry, &PATTERN[..37])
                    || !matches(
                        image,
                        entry + 0x4a,
                        &[(0x388e, 0xffff), (0x5d00, 0xffff), (0x7008, 0xffff)],
                    )
                    || !matches(
                        image,
                        entry + 0x5e,
                        &[
                            (0x4900, 0xff00),
                            (0x0066, 0xffff),
                            (0x3918, 0xffff),
                            (0x5b89, 0xffff),
                        ],
                    )
                    || !matches(
                        image,
                        entry + 0x198,
                        &[(0x4800, 0xff00), (0x380c, 0xffff), (0x5b80, 0xffff)],
                    )
                {
                    continue;
                }
                let site = entry + 0x198;
                let original_base = literal(image, site)?;
                if literal(image, entry + 0x46)?.checked_sub(0x8e)
                    != u32::try_from(parameter.rates).ok()
                    || original_base.checked_sub(0xc)
                        != u32::try_from(parameter.oem_coefficients).ok()
                    || literal(image, entry + 0x5e)?.checked_sub(0x18)
                        != u32::try_from(parameter.rates + 0x76).ok()
                {
                    return Err(Error::InvalidContract);
                }
                let caller = SavedLink::bind(image, entry, site)?;
                caller.require_register_definition(image, entry + 0x60, entry + 0x62, 6)?;
                if result
                    .replace(Self {
                        caller,
                        site,
                        original_base,
                        base_adjustment: -0xc,
                        c7_coefficients: None,
                    })
                    .is_some()
                {
                    return Err(Error::Ambiguous);
                }
            }
        }
        if parameter.rate_count == 4 && parameter.coefficients_are_runtime {
            for entry in (0..image.len().saturating_sub(0x300)).step_by(2) {
                if !matches(image, entry, FOUR_RATE_PREFIX) {
                    continue;
                }
                if literal(image, entry + 0x36)?.checked_sub(0x5e)
                    != u32::try_from(parameter.rates).ok()
                    || literal(image, entry + 0x4a)?.checked_sub(0x10)
                        != u32::try_from(parameter.rates + 0x4e).ok()
                {
                    return Err(Error::InvalidContract);
                }
                for site in (entry + 0x100..entry + 0x300).step_by(2) {
                    if !matches(
                        image,
                        site,
                        &[
                            (0x4800, 0xff00),
                            (0x3808, 0xffff),
                            (0x5b80, 0xffff),
                            (0xf000, 0xf800),
                            (0xd000, 0xd000),
                            (0x4a00, 0xff00),
                            (0x6b10, 0xffff),
                        ],
                    ) {
                        continue;
                    }
                    let original_base = literal(image, site)?;
                    if original_base.checked_sub(8)
                        != u32::try_from(parameter.oem_coefficients).ok()
                        || literal(image, entry + 0x36)? != original_base
                    {
                        return Err(Error::InvalidContract);
                    }
                    let caller = SavedLink::bind(image, entry, site)?;
                    caller.require_register_definition(image, entry + 0x4c, entry + 0x4e, 6)?;
                    if result
                        .replace(Self {
                            caller,
                            site,
                            original_base,
                            base_adjustment: -8,
                            c7_coefficients: Some(
                                u32::try_from(parameter.coefficients)
                                    .map_err(|_| Error::InvalidContract)?,
                            ),
                        })
                        .is_some()
                    {
                        return Err(Error::Ambiguous);
                    }
                }
            }
        }
        result.ok_or(Error::UnknownLayout)
    }
}
