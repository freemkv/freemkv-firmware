//! Immutable application receiver evidence collected from one code snapshot.
//!
//! Discovery is deliberately separate from an executable transfer contract.
//! A scratch decoder and direct plaintext comparison do not, by themselves,
//! prove the complete integrity/programming path or authorize a write.
use super::{
    decoding::{self, Call, Value},
    programming::{self, IntegritySelection, PlainSignature, Selection},
};

/// Range selection and the immediately following direct signature comparison.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SelectedRange {
    /// Operand-bound range selection.
    pub selection: Selection,
    /// Present only if the uninterrupted direct comparison grammar matches.
    pub signature: Option<PlainSignature>,
    /// Unique checked acceptance tail using these selection cells. Reachability
    /// from the signature loop and helper semantics are separate obligations.
    pub acceptance: Option<programming::AcceptanceTail>,
    /// Save/restore slot paired with this tail and the command frame, when bound.
    pub state_slot: Option<programming::StateSlotEvidence>,
}

#[cfg(test)]
mod bulk_acceptance_tests {
    use super::*;
    const BASE: u32 = 0xa5288;
    const HELD: &[u8] = include_bytes!("../../tests/fixtures/analysis/uh12-application.bin");

    #[test]
    fn acceptance_records_decoded_constant_results_without_inventing_a_call() {
        use programming::ResultCheck;
        let baseline = ApplicationAnalysis::inspect(HELD, BASE).unwrap();
        let original = baseline.ranges()[0].acceptance.unwrap();
        assert!(matches!(original.marker_check, ResultCheck::Call(_)));
        let at = (0xa7910 - BASE) as usize;
        for (first, second, expected) in [
            (0x2001u16, 0x2001u16, Some(1)),
            (0x2002, 0xbf00, Some(2)),
            (0x2000, 0x2001, Some(1)),
            (0x2001, 0x2000, None),
            (0x2101, 0x2001, None),
            (0x2001, 0x6001, None),
            (0xe000, 0x2001, None),
        ] {
            let mut changed = HELD.to_vec();
            changed[at..at + 2].copy_from_slice(&first.to_le_bytes());
            changed[at + 2..at + 4].copy_from_slice(&second.to_le_bytes());
            let result = ApplicationAnalysis::inspect(&changed, BASE).unwrap();
            match expected {
                Some(value) => {
                    let tail = result.ranges()[0].acceptance.unwrap();
                    assert_eq!(tail.marker_check, ResultCheck::ConstantNonzero(value));
                    assert_eq!(tail.program_target, original.program_target);
                    assert_eq!(tail.continuation, original.continuation);
                    assert!(result.ranges()[0].state_slot.is_some());
                }
                None => assert!(result.ranges()[0].acceptance.is_none()),
            }
        }
    }

    #[test]
    fn bulk_decoder_and_integrity_bind_the_selected_programming_tail() {
        let analysis = ApplicationAnalysis::inspect(HELD, BASE).unwrap();
        assert_eq!(analysis.ranges().len(), 1);
        assert_eq!(analysis.bulk_decoders().len(), 1);
        assert_eq!(analysis.integrity_selections().len(), 1);
        let tail = analysis.ranges()[0].acceptance.unwrap();
        assert_eq!(tail.program_target, 0x17c44e);
        assert_eq!(tail.program_call, 0xa7942);
        let frame = analysis.ranges()[0].state_slot.as_ref().unwrap();
        assert_eq!(frame.stack_bytes, 60);
        assert_eq!(frame.slot, 52);
        assert_eq!(frame.save_call, 0xa7736);
        assert_eq!(frame.restore_call, 0xa7948);
        assert_eq!(frame.return_path, [0xa794c, 0xa7280]);
        let mut looping = HELD.to_vec();
        let branch = (frame.return_path[0] - BASE) as usize;
        looping[branch..branch + 2].copy_from_slice(&0xe7feu16.to_le_bytes());
        assert!(ApplicationAnalysis::inspect(&looping, BASE)
            .unwrap()
            .ranges()[0]
            .state_slot
            .is_none());
        for address in [
            frame.save_call,
            frame.store,
            frame.restore_call,
            frame.epilogue,
        ] {
            let mut changed = HELD.to_vec();
            changed[(address - BASE) as usize] ^= 1;
            let analysis = ApplicationAnalysis::inspect(&changed, BASE).unwrap();
            assert!(analysis.ranges()[0].state_slot.is_none(), "{address:#x}");
        }
        for address in [0xa77ea, 0xa78ca, 0xa78f4, 0xa7938, 0xa7940] {
            let mut changed = HELD.to_vec();
            changed[(address - BASE) as usize] ^= 1;
            let analysis = ApplicationAnalysis::inspect(&changed, BASE).unwrap();
            assert!(analysis.ranges()[0].acceptance.is_none(), "{address:#x}");
        }
        let mut changed = HELD.to_vec();
        changed[(0xa7942 - BASE) as usize] ^= 1;
        let changed = ApplicationAnalysis::inspect(&changed, BASE).unwrap();
        assert_ne!(changed.ranges()[0].acceptance, Some(tail));
    }

    #[test]
    fn tail_binds_register_allocation_and_cleanup_across_literal_islands() {
        for (bytes, base, target, failure_register, continuation, saved_offset) in [
            (
                include_bytes!("../../tests/fixtures/analysis/wp50-application.bin").as_slice(),
                0x9a2e0,
                0x13b522,
                7,
                0x9c9c0,
                60,
            ),
            (
                include_bytes!("../../tests/fixtures/analysis/bu40-a103-application.bin")
                    .as_slice(),
                0x9b520,
                0x13e9d2,
                6,
                0x9dc9c,
                60,
            ),
            (
                include_bytes!("../../tests/fixtures/analysis/be16-application.bin").as_slice(),
                0x9b1d0,
                0x140dd6,
                7,
                0x9d93c,
                52,
            ),
        ] {
            let analysis = ApplicationAnalysis::inspect(bytes, base).unwrap();
            assert_eq!(analysis.bulk_decoders().len(), 1);
            let tail = analysis.ranges()[0].acceptance.unwrap();
            assert_eq!(tail.program_target, target);
            assert_eq!(tail.source_pointer_register, 4);
            assert_eq!(tail.failure_pointer_register, failure_register);
            assert_eq!(tail.continuation, continuation);
            assert_eq!(tail.saved_state_offset, saved_offset);
            let frame = analysis.ranges()[0].state_slot.as_ref().unwrap();
            assert_eq!(frame.slot, saved_offset);
            assert_eq!(frame.stack_bytes, saved_offset + 8);
            for relative in [77, 81, 84, 86] {
                let mut changed = bytes.to_vec();
                changed[(tail.address + relative - base) as usize] ^= 1;
                let analysis = ApplicationAnalysis::inspect(&changed, base).unwrap();
                assert!(
                    analysis.ranges()[0].acceptance.is_none(),
                    "{base:#x}+{relative}"
                );
            }
        }
    }
}

/// A scratch header call and in-place body call sharing the same pointer cell
/// and AES routine. Both selected-start policies are traced independently.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BulkDecode {
    /// Range-selection block whose two starts supplied these decode calls.
    pub selection_address: u32,
    /// Scratch header input/output evidence.
    pub header: Call,
    /// Body call when the selected start is zero.
    pub from_zero: Call,
    /// Body call when boot is preserved. Its footprint may exceed image size;
    /// consumers must not silently clip it to uploaded bytes.
    pub preserving_boot: Call,
}

/// Read-only evidence retained by the loaded application receiver.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ApplicationAnalysis {
    ranges: Vec<SelectedRange>,
    integrity: Vec<IntegritySelection>,
    scratch: Vec<Call>,
    bulk: Vec<BulkDecode>,
    conflicting_arguments: bool,
}

impl ApplicationAnalysis {
    /// Analyze a bounded application code snapshot once. No firmware target,
    /// filename, model or version string contributes to the result.
    pub fn inspect(bytes: &[u8], base: u32) -> Option<Self> {
        if base & 1 != 0 {
            return None;
        }
        let end = base.checked_add(u32::try_from(bytes.len()).ok()?)?;
        let mut ranges = Vec::new();
        let mut integrity = Vec::new();
        for address in (base..end).step_by(2) {
            if let Some(selection) = programming::inspect_selection(bytes, base, address) {
                let signature = programming::inspect_plain_signature(bytes, base, &selection);
                ranges.push(SelectedRange {
                    selection,
                    signature,
                    acceptance: None,
                    state_slot: None,
                });
            }
            if let Some(proof) = programming::inspect_legacy_integrity(bytes, base, address) {
                integrity.push(proof);
            }
        }
        let mut scratch: Vec<Call> = Vec::new();
        let mut conflicting_arguments = false;
        for range in &mut ranges {
            let Some(signature) = range.signature else {
                continue;
            };
            let mut candidates = integrity.iter().filter_map(|checks| {
                if checks.address < signature.success
                    || checks.address.checked_sub(signature.success)? > 1024
                {
                    return None;
                }
                programming::inspect_acceptance_tail(
                    bytes,
                    base,
                    &range.selection,
                    &signature,
                    checks,
                )
            });
            let first = candidates.next();
            if candidates.next().is_some() {
                conflicting_arguments = true;
            } else {
                range.acceptance = first;
            }
        }
        for range in &ranges {
            let Some(signature) = range.signature else {
                continue;
            };
            // The signature grammar independently establishes which RAM cell
            // holds staged bytes. Trace candidate setups without treating every
            // RAM load as a staging pointer. Reachability remains unproven here.
            let first = range.selection.address.saturating_sub(512).max(base);
            for start in (first..range.selection.address).step_by(2) {
                let Some(call) =
                    decoding::trace_call(bytes, base, start, [Value::Unknown; 8], |a| {
                        (a == Value::Constant(signature.staging_cell)).then_some(Value::Staging(0))
                    })
                else {
                    continue;
                };
                if call.address >= range.selection.address
                    || call.length != 16
                    || call.source != Value::Staging(0x3000)
                    || !matches!(call.destination, Value::Stack(_))
                {
                    continue;
                }
                let Some(offset) = call
                    .target
                    .checked_sub(base)
                    .and_then(|x| usize::try_from(x).ok())
                else {
                    continue;
                };
                let Some(routine) = bytes.get(offset..) else {
                    continue;
                };
                if !super::matches(routine, super::AES) {
                    continue;
                }
                if let Some(previous) = scratch.iter().find(|c| c.address == call.address) {
                    // r3 is not an AES argument. Different tracing start points
                    // can establish different irrelevant r3 facts.
                    conflicting_arguments |= previous.target != call.target
                        || previous.source != call.source
                        || previous.destination != call.destination
                        || previous.length != call.length;
                } else {
                    scratch.push(call);
                }
            }
        }
        scratch.sort_by_key(|c| c.address);
        let mut bulk = Vec::new();
        for range in &ranges {
            let trace = |start| {
                decoding::trace_call(bytes, base, range.selection.end, [Value::Unknown; 8], |a| {
                    match a {
                        Value::Constant(cell) if cell == range.selection.start_cell => {
                            Some(Value::Constant(start))
                        }
                        Value::Constant(cell)
                            if cell & 3 == 0 && (0x02000000..0x02010000).contains(&cell) =>
                        {
                            Some(Value::Loaded { cell, offset: 0 })
                        }
                        _ => None,
                    }
                })
            };
            let (Some(from_zero), Some(preserving_boot)) = (trace(0), trace(0x10000)) else {
                continue;
            };
            let Value::Loaded { cell, offset: 0 } = from_zero.source else {
                continue;
            };
            if from_zero.destination != from_zero.source
                || from_zero.length != 0x200000
                || preserving_boot.address != from_zero.address
                || preserving_boot.target != from_zero.target
                || preserving_boot.length != from_zero.length
                || preserving_boot.source
                    != (Value::Loaded {
                        cell,
                        offset: 0x10000,
                    })
                || preserving_boot.destination != preserving_boot.source
            {
                continue;
            }
            let Some(offset) = from_zero
                .target
                .checked_sub(base)
                .and_then(|x| usize::try_from(x).ok())
            else {
                continue;
            };
            if !bytes
                .get(offset..)
                .is_some_and(|routine| super::matches(routine, super::AES))
            {
                continue;
            }
            let first = range.selection.address.saturating_sub(512).max(base);
            let mut header: Option<Call> = None;
            let mut ambiguous = false;
            for start in (first..range.selection.address).step_by(2) {
                let Some(call) =
                    decoding::trace_call(bytes, base, start, [Value::Unknown; 8], |a| {
                        (a == Value::Constant(cell)).then_some(Value::Loaded { cell, offset: 0 })
                    })
                else {
                    continue;
                };
                if call.address >= range.selection.address
                    || call.target != from_zero.target
                    || call.source
                        != (Value::Loaded {
                            cell,
                            offset: 0x3000,
                        })
                    || call.length != 16
                    || !matches!(call.destination, Value::Stack(_))
                {
                    continue;
                }
                if let Some(previous) = header {
                    ambiguous |= previous.address != call.address
                        || previous.destination != call.destination;
                } else {
                    header = Some(call);
                }
            }
            if ambiguous {
                conflicting_arguments = true;
            } else if let Some(header) = header {
                bulk.push(BulkDecode {
                    selection_address: range.selection.address,
                    header,
                    from_zero,
                    preserving_boot,
                });
            }
        }
        for range in &mut ranges {
            if range.signature.is_some() {
                continue;
            }
            let mut candidates = bulk
                .iter()
                .filter(|decode| decode.selection_address == range.selection.address)
                .flat_map(|decode| {
                    let cell = match decode.from_zero.source {
                        Value::Loaded { cell, offset: 0 } => cell,
                        _ => return Vec::new(),
                    };
                    integrity
                        .iter()
                        .filter_map(|checks| {
                            if checks.address <= decode.from_zero.address
                                || checks.address.checked_sub(decode.from_zero.address)? > 1024
                            {
                                return None;
                            }
                            programming::inspect_acceptance_with_staging(
                                bytes,
                                base,
                                &range.selection,
                                cell,
                                checks,
                            )
                        })
                        .collect::<Vec<_>>()
                });
            let first = candidates.next();
            if candidates.next().is_some() {
                conflicting_arguments = true;
            } else {
                range.acceptance = first;
            }
        }
        for range in &mut ranges {
            range.state_slot = range.acceptance.as_ref().and_then(|tail| {
                programming::inspect_state_slot(bytes, base, &range.selection, tail)
            });
        }
        Some(Self {
            ranges,
            integrity,
            scratch,
            bulk,
            conflicting_arguments,
        })
    }

    /// All matched range selections, retaining missing signature evidence.
    pub fn ranges(&self) -> &[SelectedRange] {
        &self.ranges
    }
    /// Matched integrity-selection blocks; checker semantics remain separate.
    pub fn integrity_selections(&self) -> &[IntegritySelection] {
        &self.integrity
    }
    /// Argument-traced scratch header decoder calls, not whole-image decoders.
    pub fn scratch_decoders(&self) -> &[Call] {
        &self.scratch
    }
    /// Whether candidate traces disagree about a decoder's actual arguments.
    pub fn conflicting_arguments(&self) -> bool {
        self.conflicting_arguments
    }
    /// Positive header/body call evidence. An empty result never means that
    /// the receiver accepts plaintext; incomplete grammars remain unknown.
    pub fn bulk_decoders(&self) -> &[BulkDecode] {
        &self.bulk
    }
}
