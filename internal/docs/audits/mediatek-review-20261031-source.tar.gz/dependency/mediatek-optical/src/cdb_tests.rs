use super::*;

#[test]
fn ten_byte_buffer_commands() {
    assert_eq!(
        read_buffer(0x06, 0x00, 0x1E_C000, 0x100),
        [0x3C, 0x06, 0x00, 0x1E, 0xC0, 0x00, 0x00, 0x01, 0x00, 0x00]
    );
    assert_eq!(
        read_memory(0x3000, 0x20),
        read_buffer(MODE_DATA, BUFFER_ID, 0x3000, 0x20)
    );
    assert_eq!(
        write_buffer(0x26, 0x00, 0x1F_0000, 0x1_0000),
        [0x3B, 0x06, 0x00, 0x1F, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00]
    );
    assert_eq!(
        get_configuration(FEATURE_FIRMWARE_DATE, 28),
        [0x46, 0x02, 0x01, 0x0C, 0, 0, 0, 0x00, 28, 0]
    );
    assert_eq!(inquiry(96), [0x12, 0, 0, 0, 96, 0]);
}

#[test]
fn oem_flash_sequence_bytes() {
    assert_eq!(
        probe(),
        [0x3C, 0x06, 0x00, 0x1E, 0xC0, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00]
    );
    assert_eq!(test_unit_ready(), [0u8; 12]);
    assert_eq!(
        enter_update(),
        [0x3B, 0x01, 0, 0, 0, 0, 0, 0, 0, 0x0B, 0, 0]
    );
    assert_eq!(
        transfer(0x1F_C000, CHUNK as u16),
        [0x3B, 0x06, 0x00, 0x1F, 0xC0, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00]
    );
    assert_eq!(finish(), [0x3B, 0x07, 0, 0, 0, 0, 0, 0, 0, 0, 0x1B, 0x12]);
    // The LG v1.081 and ASUS updaters: `03 00 00 00 10 80`, padded to 12.
    assert_eq!(
        request_sense(),
        [0x03, 0, 0, 0, 0x10, 0x80, 0, 0, 0, 0, 0, 0]
    );
}

#[test]
fn preserving_boot_clears_only_the_receiver_range_selection_bit() {
    for (normal, preserving) in [
        (Prepare::ModeOne, Prepare::ModeOnePreserveBoot),
        (Prepare::ModeSix67, Prepare::ModeSix67PreserveBoot),
    ] {
        let mut expected = normal.command();
        assert_eq!(expected[9], 0x0b);
        expected[9] = 0x0a;
        assert_eq!(preserving.command(), expected);
    }
}
